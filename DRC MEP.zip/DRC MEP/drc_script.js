// ─────────────────────────────────────────────────────────────────────────────
// DRC MARKET ENTRY PACK — SCRIPT
// Replace SUPABASE_URL and SUPABASE_ANON_KEY with your project credentials.
// ─────────────────────────────────────────────────────────────────────────────

const SUPABASE_URL = 'https://YOUR_PROJECT_REF.supabase.co';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const db = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

let currentRating = 0;
let packRating = 0;

function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(item => item.classList.remove('active'));

  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');

  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
}

function showSector(id) {
  const panel = document.getElementById('sector-' + id);
  const order = ['fintech', 'agritech', 'healthtech', 'climatetech'];
  const idx = order.indexOf(id);
  const tabs = document.querySelectorAll('.sector-tab');
  if (!panel || idx < 0 || !tabs[idx]) return;

  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  tabs.forEach(t => t.classList.remove('active'));
  panel.classList.add('active');
  tabs[idx].classList.add('active');
}

function setRating(n) {
  currentRating = n;
  document.querySelectorAll('#stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });
}

async function setPackRating(n) {
  packRating = n;
  document.querySelectorAll('#pack-stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });

  const result = await insertRow('pack_ratings', {
    rating: packRating,
    page_url: window.location.href,
    user_agent: navigator.userAgent
  });

  if (result.ok) {
    showThanks('pack-rating-thanks');
  } else {
    showFormMessage('pack-stars', result.message, 'error');
  }
}

function getValue(id) {
  return document.getElementById(id)?.value.trim() || '';
}

function showThanks(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'block';
}

function setBusy(button, isBusy) {
  if (!button) return;
  button.disabled = isBusy;
  button.dataset.originalText ||= button.textContent;
  button.textContent = isBusy ? 'Submitting' : button.dataset.originalText;
  button.classList.toggle('btn-loading', isBusy);
  button.setAttribute('aria-label', isBusy ? 'Submitting…' : button.dataset.originalText);
}

function showFormMessage(anchorId, message, type = 'error') {
  const anchor = document.getElementById(anchorId);
  if (!anchor) return;

  const existing = anchor.parentElement.querySelector('.form-message');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = `form-message ${type}`;
  note.textContent = message;
  anchor.insertAdjacentElement('afterend', note);
}

function clearFormMessage(anchorId) {
  const anchor = document.getElementById(anchorId);
  const existing = anchor?.parentElement.querySelector('.form-message');
  if (existing) existing.remove();
}

function showTemporaryFormError(button, message) {
  if (!button?.parentElement) return;

  const existing = button.parentElement.querySelector('.form-error');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = 'form-error';
  note.textContent = message;
  button.insertAdjacentElement('afterend', note);
}

// ── DATABASE ──

async function insertRow(table, payload) {
  if (!db) {
    return {
      ok: false,
      message: 'Supabase is not configured yet. Add your project URL and anon key in drc_script.js.'
    };
  }

  const { error } = await db.from(table).insert(payload);
  if (error) {
    const rawMessage = error.message || 'Submission failed. Please try again.';
    if (rawMessage.includes(`Could not find the table 'public.${table}'`)) {
      return {
        ok: false,
        message: 'This form backend is not live yet. The Supabase schema still needs to be run for this project.'
      };
    }
    return { ok: false, message: error.message || 'Submission failed. Please try again.' };
  }

  return { ok: true };
}

// ── FORM HANDLERS ──

async function submitInsight(event) {
  const button = event?.currentTarget;
  const text = getValue('insight-text');
  clearFormMessage('insight-form');

  if (!text) {
    showFormMessage('insight-form', 'Please add your insight before submitting.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('market_insights', {
      sector: getValue('insight-sector') || null,
      insight_text: text,
      contributor_name: getValue('insight-name') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _if = document.getElementById('insight-form'); if (_if) _if.style.display = 'none';
    showThanks('insight-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitRating(event) {
  const button = event?.currentTarget;
  const agencyName = getValue('agency-name');
  clearFormMessage('rating-form');

  if (!agencyName || currentRating === 0) {
    showFormMessage('rating-form', 'Please add a provider name and choose a star rating.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('service_provider_ratings', {
      provider_name: agencyName,
      rating: currentRating,
      comment: getValue('agency-comment') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _rf = document.getElementById('rating-form'); if (_rf) _rf.style.display = 'none';
    showThanks('rating-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitIntro(event) {
  const button = event?.currentTarget;
  const lookingFor = getValue('intro-looking');
  const context = getValue('intro-context');
  const email = getValue('intro-email');
  clearFormMessage('intro-form');

  if (!lookingFor || !context || !email) {
    showFormMessage('intro-form', 'Please fill out all intro request fields.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('intro_requests', {
      looking_for: lookingFor,
      company_context: context,
      email,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _intf = document.getElementById('intro-form'); if (_intf) _intf.style.display = 'none';
    showThanks('intro-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

function bindInteractions() {
  document.querySelectorAll('[data-panel]').forEach(button => {
    if (button.classList.contains('bookmark-btn')) return;
    button.addEventListener('click', () => showPanel(button.dataset.panel));
  });

  document.querySelectorAll('.bookmark-btn').forEach(button => {
    button.addEventListener('click', () => setBookmark(button.dataset.panel));
  });

  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });

  document.querySelectorAll('[data-rating]').forEach(star => {
    star.addEventListener('click', () => setRating(Number(star.dataset.rating)));
  });

  document.querySelectorAll('[data-pack-rating]').forEach(star => {
    star.addEventListener('click', () => setPackRating(Number(star.dataset.packRating)));
  });

  document.querySelector('[data-action="submit-insight"]')?.addEventListener('click', submitInsight);
  document.querySelector('[data-action="submit-rating"]')?.addEventListener('click', submitRating);
  document.querySelector('[data-action="submit-intro"]')?.addEventListener('click', submitIntro);
}

document.addEventListener('DOMContentLoaded', () => {
  bindInteractions();
  loadPackContent().finally(initFeatures);

  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }
});

// ── PACK CONTENT (ADMIN-EDITABLE) ──

async function loadPackContent() {
  if (!db) return;

  try {
    const { data, error } = await db.from('pack_content').select('content_id, content_html');
    if (error || !data || data.length === 0) return;

    for (const row of data) {
      const els = document.querySelectorAll(`[data-content-id="${row.content_id}"]`);
      if (!els.length) continue;

      const isHtml = /^\s*</.test(row.content_html);
      for (const el of els) {
        if (isHtml) {
          el.innerHTML = row.content_html;
          el.querySelectorAll('a').forEach(a => {
            if (!a.getAttribute('target')) a.setAttribute('target', '_blank');
            a.setAttribute('rel', 'noopener noreferrer');
          });
        } else {
          el.textContent = row.content_html;
        }
      }
    }
  } catch {
    // Supabase not available or table does not exist — keep hardcoded content
  }
}

// ── STATE ──

const SECTION_ORDER = ['front', 's1', 's2', 's3', 's4', 's5', 's6', 'feedback', 'glossary'];

const ACRONYMS = {
  'BCC':      'Banque Centrale du Congo — DRC central bank and financial sector regulator',
  'ANAPI':    'Agence Nationale pour la Promotion des Investissements — DRC investment promotion agency; issues Investment Certificates',
  'ARPTC':    'Autorité de Régulation de la Poste et des Télécommunications du Congo — DRC telecom and postal regulator',
  'ANSER':    'Agence Nationale des Services Energétiques Ruraux — regulator for rural electrification and mini-grid concessions',
  'DGI':      'Direction Générale des Impôts — DRC primary national tax authority',
  'DGRAD':    'Direction Générale des Recettes Administratives, Domaniales, Judiciaires et de Participations — administrative fees authority',
  'FEC':      'Fédération des Entreprises du Congo — DRC primary private sector federation',
  'RCCM':     'Registre du Commerce et du Crédit Mobilier — DRC commercial registry number',
  'OHADA':    'Organisation pour l\'Harmonisation en Afrique du Droit des Affaires — uniform commercial law across 17 francophone African countries',
  'SARL':     'Société à Responsabilité Limitée — limited liability company; standard DRC entry vehicle',
  'SADC':     'Southern African Development Community — regional bloc including DRC',
  'CEPGL':    'Communauté Économique des Pays des Grands Lacs — Great Lakes Economic Community (DRC, Rwanda, Burundi)',
  'CEMAC':    'Communauté Économique et Monétaire de l\'Afrique Centrale — Central African Economic and Monetary Community',
  'AfCFTA':   'African Continental Free Trade Area — pan-continental free trade agreement',
  'CENAREF':  'Cellule Nationale des Renseignements Financiers — DRC national AML and counter-terrorism financing authority',
  'FATF':     'Financial Action Task Force — international AML standard-setting body; DRC grey-listed 2024',
  'AML':      'Anti-Money Laundering — compliance requirement for all DRC financial services; administered by CENAREF',
  'CFT':      'Counter-Financing of Terrorism — compliance requirement companion to AML',
  'KYC':      'Know Your Customer — mandatory identity verification for banking and financial services in DRC',
  'EME':      'Établissement de Monnaie Électronique — BCC licence for mobile money and e-wallet operators',
  'EP':       'Établissement de Paiement — BCC licence for payment service providers',
  'EUDR':     'EU Deforestation Regulation — supply chain traceability to farm level for DRC export commodities',
  'SNEL':     'Société Nationale d\'Electricité — DRC state electricity utility; chronically poor grid quality',
  'PAYG':     'Pay-As-You-Go — metered financing model; primary model for off-grid solar operators in DRC',
  'REDD+':    'Reducing Emissions from Deforestation and forest Degradation — carbon credit mechanism; DRC is major potential supplier',
  'SEZ':      'Special Economic Zone — Maluku SEZ (Kinshasa) and N\'Sele zone; managed by ANAPI; tax holidays up to 10 years',
  'IBP':      'Impôt sur les Bénéfices et Profits — DRC corporate income tax; standard rate 30%',
  'TVA':      'Taxe sur la Valeur Ajoutée — DRC VAT; standard rate 16%; mandatory above CDF 80M annual turnover',
  'CDF':      'Congolese Franc — official currency; ~CDF 2,800–3,000 per USD; most commercial transactions USD-denominated',
  'USD':      'United States Dollar — de facto operating currency; ~85–90% of DRC banking transactions are USD-denominated',
  'DFI':      'Development Finance Institution — IFC, Proparco, BII, AfDB, and DFC are the most active DRC DFIs',
  'IFC':      'International Finance Corporation — World Bank Group private sector arm; active DRC portfolio',
  'BII':      'British International Investment — UK development finance institution with DRC investment portfolio',
  'DFC':      'US International Development Finance Corporation — active DRC energy access investment portfolio',
  'AfDB':     'African Development Bank — pan-African multilateral development bank with active DRC portfolio',
  'FDI':      'Foreign Direct Investment — DRC received ~USD 2.5B in 2023, predominantly mining sector',
  'GDP':      'Gross Domestic Product — DRC ~USD 66B nominal (2025); 6.1% real growth projected',
  'IMF':      'International Monetary Fund — DRC Extended Credit Facility provides macro-stability anchor',
  'UNCTAD':   'United Nations Conference on Trade and Development — authoritative DRC trade and FDI statistics',
  'M23':      'Mouvement du 23-Mars — armed group in eastern DRC; 2024–2025 escalation significantly disrupted Goma',
  'B2B':      'Business-to-Business — sales model targeting companies; dominant model for DRC enterprise market entry',
  'B2G':      'Business-to-Government — sales model where government is primary customer',
  'C&I':      'Commercial and Industrial — solar segment targeting businesses and manufacturers',
  'KYC':      'Know Your Customer — mandatory identity verification for banking and financial services onboarding in DRC',
  'MoU':      'Memorandum of Understanding — non-binding agreement between parties',
  'USAID':    'US Agency for International Development — active DRC grant and development programmes',
};

let visitedSections = new Set();
let bookmarkedSection = null;
let darkModeEnabled = false;
let tooltipEl = null;

const initialDarkMode = localStorage.getItem('mep-darkmode-drc') === '1';
if (initialDarkMode) {
  document.body.classList.add('dark');
  darkModeEnabled = true;
}

function persistVisited() {
  localStorage.setItem('mep-visited-drc', JSON.stringify([...visitedSections]));
}

function hydrateVisited() {
  const raw = localStorage.getItem('mep-visited-drc');
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (Array.isArray(list)) {
      visitedSections = new Set(list);
      updateVisitedChecks();
    }
  } catch {
    visitedSections = new Set();
  }
}

function updateVisitedChecks() {
  visitedSections.forEach(id => {
    const button = document.querySelector(`.nav-btn[data-panel="${id}"]`);
    if (!button || button.querySelector('.nav-check')) return;
    const mark = document.createElement('span');
    mark.className = 'nav-check';
    mark.textContent = '✓';
    button.appendChild(mark);
  });
}

function markVisited(id) {
  if (visitedSections.has(id)) return;
  visitedSections.add(id);
  persistVisited();
  updateVisitedChecks();
}

function updateProgressBar(index) {
  const fill = document.querySelector('.pack-progress-fill');
  if (!fill) return;
  fill.style.width = `${Math.round(((index + 1) / SECTION_ORDER.length) * 100)}%`;
}

function hydrateBookmark() {
  const raw = localStorage.getItem('mep-bookmark-drc');
  bookmarkedSection = raw || null;
  updateBookmarkIndicators();
}

function updateBookmarkIndicators() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const isBookmarked = btn.dataset.panel === bookmarkedSection;
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (isBookmarked) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.title = 'Bookmarked';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else if (indicator) {
      indicator.remove();
    }
  });

  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.style.opacity = btn.dataset.panel === bookmarkedSection ? '1' : '0.35';
  });
}

function setBookmark(panelId) {
  if (panelId === bookmarkedSection) {
    bookmarkedSection = null;
    localStorage.removeItem('mep-bookmark-drc');
  } else {
    bookmarkedSection = panelId;
    localStorage.setItem('mep-bookmark-drc', panelId);
  }
  updateBookmarkIndicators();
}

function initFeatures() {
  hydrateVisited();
  hydrateBookmark();
  hydrateDarkMode();
  initializeProseCards();
  wrapAcronyms();
  createTooltip();
  document.getElementById('pack-search')?.addEventListener('input', onSearchInput);
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);

  document.querySelector('.pack-root')?.addEventListener('click', event => {
    const proseToggle = event.target.closest('.prose-toggle');
    if (proseToggle) {
      event.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;

      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
      return;
    }

    const fundingToggle = event.target.closest('.funding-toggle');
    if (fundingToggle) {
      event.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;

      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
    }
  });

  if (bookmarkedSection) {
    showPanel(bookmarkedSection);
  } else {
    const current = document.querySelector('.nav-btn.active')?.dataset.panel || SECTION_ORDER[0];
    showPanel(current);
  }
}

function hydrateDarkMode() {
  darkModeEnabled = localStorage.getItem('mep-darkmode-drc') === '1';
  document.body.classList.toggle('dark', darkModeEnabled);
  updateDarkToggleLabel();
}

function updateDarkToggleLabel() {
  const button = document.getElementById('darkmode-toggle');
  if (!button) return;
  button.textContent = darkModeEnabled ? '☀️' : '🌙';
}

function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode-drc', darkModeEnabled ? '1' : '0');
  updateDarkToggleLabel();
}

function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  window.setTimeout(() => {
    document.body.classList.remove('print-mode');
  }, 100);
}

function onSearchInput(event) {
  const query = event.target.value.trim();
  clearSearchHighlights();
  if (!query) return;
  highlightSearch(query);
}

function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, .pack-progress-bar, .mep-tooltip')) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;

    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  }

  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) {
      const panelId = panel.id.replace('panel-', '');
      showPanel(panelId);
    }
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
}

function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.createElement('div');
  tooltipEl.id = 'mep-tooltip';
  tooltipEl.className = 'mep-tooltip';
  document.body.appendChild(tooltipEl);
  document.querySelector('.pack-root')?.addEventListener('pointerover', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('pointerout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
  document.querySelector('.pack-root')?.addEventListener('focusin', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('focusout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
}

function showTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || target.title || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 240, Math.max(8, rect.left));
  const top = rect.bottom + 10;
  tooltipEl.style.top = `${top}px`;
  tooltipEl.style.left = `${left}px`;
}

function hideTooltip() {
  if (tooltipEl) tooltipEl.style.opacity = '0';
}

function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, script, .mep-abbr, .search-highlight')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    acronymRegex.lastIndex = 0;
    if (!acronymRegex.test(text)) continue;
    replacements.push(node);
  }

  replacements.forEach(node => {
    const text = node.nodeValue;
    acronymRegex.lastIndex = 0;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.textContent = match[0];
      abbr.setAttribute('tabindex', '0');
      fragment.appendChild(abbr);
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  });
}

// ── PANEL ANIMATION REPLAY ──
(function patchShowPanel() {
  const _prev = window.showPanel;
  if (!_prev) return;
  window.showPanel = function(id) {
    _prev(id);
    const panel = document.getElementById('panel-' + id);
    if (panel) {
      panel.querySelectorAll('.stat-card, .how-card, .how-card-link').forEach(el => {
        el.style.animation = 'none';
        void el.offsetHeight;
        el.style.animation = '';
      });
    }
  };
})();

// ── DARK MODE LABEL ON LOAD ──
(function initDarkLabelOnLoad() {
  const apply = () => {
    const btn = document.getElementById('darkmode-toggle');
    if (!btn) return;
    const isDark = document.body.classList.contains('dark');
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }
})();

// ── FUNDING ACCORDION DEFAULT OPEN ──
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    if (!btn.hasAttribute('aria-expanded')) {
      btn.setAttribute('aria-expanded', 'true');
    }
    if (btn.getAttribute('aria-expanded') === 'true') {
      body.style.maxHeight = body.scrollHeight + 'px';
    } else {
      body.style.maxHeight = '0';
    }
  });
});
