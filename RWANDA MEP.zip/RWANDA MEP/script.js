const SUPABASE_URL = 'https://uauzozmlzgpgmurngqxu.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Octlx2Juh2XMWMVvCUTdJQ_GV9E8U89';

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const db = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

let currentRating = 0;
let packRating = 0;

function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(item => item.classList.remove('active'));

  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');

  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
}

function showSector(id) {
  const panel = document.getElementById('sector-' + id);
  const order = ['fintech', 'agritech', 'healthtech', 'edtech'];
  const idx = order.indexOf(id);
  const tabs = document.querySelectorAll('.sector-tab');
  if (!panel || idx < 0 || !tabs[idx]) return;

  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  tabs.forEach(t => t.classList.remove('active'));
  panel.classList.add('active');
  tabs[idx].classList.add('active');
}

function setRating(n) {
  currentRating = n;
  document.querySelectorAll('#stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });
}

async function setPackRating(n) {
  packRating = n;
  document.querySelectorAll('#pack-stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });

  const result = await insertRow('pack_ratings', {
    rating: packRating,
    page_url: window.location.href,
    user_agent: navigator.userAgent
  });

  if (result.ok) {
    showThanks('pack-rating-thanks');
  } else {
    showFormMessage('pack-stars', result.message, 'error');
  }
}

function getValue(id) {
  return document.getElementById(id)?.value.trim() || '';
}

function showThanks(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'block';
}

function setBusy(button, isBusy) {
  if (!button) return;
  button.disabled = isBusy;
  button.dataset.originalText ||= button.textContent;
  button.textContent = isBusy ? 'Submitting' : button.dataset.originalText;
  button.classList.toggle('btn-loading', isBusy);
  button.setAttribute('aria-label', isBusy ? 'Submitting…' : button.dataset.originalText);
}

function showFormMessage(anchorId, message, type = 'error') {
  const anchor = document.getElementById(anchorId);
  if (!anchor) return;

  const existing = anchor.parentElement.querySelector('.form-message');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = `form-message ${type}`;
  note.textContent = message;
  anchor.insertAdjacentElement('afterend', note);
}

function clearFormMessage(anchorId) {
  const anchor = document.getElementById(anchorId);
  const existing = anchor?.parentElement.querySelector('.form-message');
  if (existing) existing.remove();
}

function showTemporaryFormError(button, message) {
  if (!button?.parentElement) return;

  const existing = button.parentElement.querySelector('.form-error');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = 'form-error';
  note.textContent = message;
  button.insertAdjacentElement('afterend', note);

  window.setTimeout(() => {
    if (note.isConnected) note.remove();
  }, 5000);
}

async function insertRow(table, payload) {
  if (!db) {
    return {
      ok: false,
      message: 'Supabase is not configured yet. Add your project URL and anon key in script.js.'
    };
  }

  const { error } = await db.from(table).insert(payload);
  if (error) {
    const rawMessage = error.message || 'Submission failed. Please try again.';
    if (rawMessage.includes(`Could not find the table 'public.${table}'`)) {
      return {
        ok: false,
        message: 'This form backend is not live yet. The Supabase schema still needs to be run for this project.'
      };
    }

    return { ok: false, message: error.message || 'Submission failed. Please try again.' };
  }

  return { ok: true };
}

async function submitInsight(event) {
  const button = event?.currentTarget;
  const text = getValue('insight-text');
  clearFormMessage('insight-form');

  if (!text) {
    showFormMessage('insight-form', 'Please add your insight before submitting.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('market_insights', {
      sector: getValue('insight-sector') || null,
      insight_text: text,
      contributor_name: getValue('insight-name') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _if = document.getElementById('insight-form'); if (_if) _if.style.display = 'none';
    showThanks('insight-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitRating(event) {
  const button = event?.currentTarget;
  const agencyName = getValue('agency-name');
  clearFormMessage('rating-form');

  if (!agencyName || currentRating === 0) {
    showFormMessage('rating-form', 'Please add a provider name and choose a star rating.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('service_provider_ratings', {
      provider_name: agencyName,
      rating: currentRating,
      comment: getValue('agency-comment') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _rf = document.getElementById('rating-form'); if (_rf) _rf.style.display = 'none';
    showThanks('rating-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitIntro(event) {
  const button = event?.currentTarget;
  const lookingFor = getValue('intro-looking');
  const context = getValue('intro-context');
  const email = getValue('intro-email');
  clearFormMessage('intro-form');

  if (!lookingFor || !context || !email) {
    showFormMessage('intro-form', 'Please fill out all intro request fields.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('intro_requests', {
      looking_for: lookingFor,
      company_context: context,
      email,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _intf = document.getElementById('intro-form'); if (_intf) _intf.style.display = 'none';
    showThanks('intro-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

function bindInteractions() {
  document.querySelectorAll('[data-panel]').forEach(button => {
    if (button.classList.contains('bookmark-btn')) return;
    button.addEventListener('click', () => showPanel(button.dataset.panel));
  });

  document.querySelectorAll('.bookmark-btn').forEach(button => {
    button.addEventListener('click', () => setBookmark(button.dataset.panel));
  });

  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });

  document.querySelectorAll('[data-rating]').forEach(star => {
    star.addEventListener('click', () => setRating(Number(star.dataset.rating)));
  });

  document.querySelectorAll('[data-pack-rating]').forEach(star => {
    star.addEventListener('click', () => setPackRating(Number(star.dataset.packRating)));
  });

  document.querySelector('[data-action="submit-insight"]')?.addEventListener('click', submitInsight);
  document.querySelector('[data-action="submit-rating"]')?.addEventListener('click', submitRating);
  document.querySelector('[data-action="submit-intro"]')?.addEventListener('click', submitIntro);
}

document.addEventListener('DOMContentLoaded', () => {
  bindInteractions();
  loadPackContent().finally(initFeatures);

  // Sticky nav shadow on scroll
  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }
});

/**
 * Load editable content from the pack_content table (anon SELECT).
 * Falls back to hardcoded HTML if Supabase is not configured or the table is empty.
 */
async function loadPackContent() {
  if (!db) return;

  try {
    const { data, error } = await db.from('pack_content').select('content_id, content_html');
    if (error || !data || data.length === 0) return;

    for (const row of data) {
      const els = document.querySelectorAll(`[data-content-id="${row.content_id}"]`);
      if (!els.length) continue;

      // Auto-detect HTML: if stored content starts with an HTML tag, render
      // as innerHTML (supports rich text written via the Quill editor in admin).
      // All other values are set as textContent for safety.
      const isHtml = /^\s*</.test(row.content_html);
      for (const el of els) {
        if (isHtml) {
          el.innerHTML = row.content_html;
          // Ensure all embedded links open in new tab
          el.querySelectorAll('a').forEach(a => {
            if (!a.getAttribute('target')) a.setAttribute('target', '_blank');
            a.setAttribute('rel', 'noopener noreferrer');
          });
        } else {
          el.textContent = row.content_html;
        }
      }
    }
  } catch {
    // Supabase not available or table doesn't exist — keep hardcoded content
  }
}

// ── FEATURE ADDITIONS ──

const SECTION_ORDER = ['front', 's1', 's2', 's3', 's4', 's5', 'feedback', 'glossary'];
const ACRONYMS = {
  'RDB':    'Rwanda Development Board — one-stop investment facilitation agency',
  'NBR':    'National Bank of Rwanda — central bank and financial sector regulator',
  'RISA':   'Rwanda Information Society Authority — ICT policy and data protection enforcement',
  'KIFC':   'Kigali International Financial Centre — Rwanda\'s financial services hub (0% CIT for qualifying HQ)',
  'KIC':    'Kigali Innovation City — USD 2B smart city, East Africa\'s premier tech district',
  'MINICT': 'Ministry of ICT and Innovation — digital economy policy ministry',
  'MINICOM':'Ministry of Trade and Industry — trade licences and industrial policy',
  'MINAGRI':'Ministry of Agriculture and Animal Resources — agricultural sector policy',
  'NAEB':   'National Agricultural Export Development Board — coffee, tea, horticulture export standards',
  'RAB':    'Rwanda Agriculture and Animal Resources Board — seeds, fertilisers, agrochemical regulation',
  'REMA':   'Rwanda Environment Management Authority — environmental compliance and climate policy',
  'RURA':   'Rwanda Utilities Regulatory Authority — energy, telecoms, and EV charging licences',
  'RBC':    'Rwanda Biomedical Centre — national blood transfusion, HIV programme, biomedical research',
  'MoH':    'Ministry of Health Rwanda — health sector policy and HSSP V implementation',
  'BRD':    'Rwanda Development Bank — primary DFI and long-term lender for priority sectors',
  'RRA':    'Rwanda Revenue Authority — national tax authority (VAT, CIT, customs)',
  'RSSB':   'Rwanda Social Security Board — mandatory employer/employee social security contributions',
  'RCAA':   'Rwanda Civil Aviation Authority — drone operations and air transport regulation',
  'EAC':    'East African Community — regional bloc of 7 member states (~670M people)',
  'COMESA': 'Common Market for Eastern and Southern Africa — 21-country regional trade bloc',
  'AfCFTA': 'African Continental Free Trade Area — pan-continental free trade agreement',
  'CBHI':   'Community-Based Health Insurance (Mutuelle de Santé) — 90%+ population coverage',
  'MMIP':   'Mobile Money Interoperability Platform — enables cross-network MTN/Airtel transfers (live 2021)',
  'NST2':   'National Strategy for Transformation 2 (2024–2029) — Rwanda\'s 5-year development plan',
  'PSTA':   'Strategic Plan for the Transformation of Agriculture — MINAGRI sector plan',
  'EUDR':   'EU Deforestation Regulation — requires supply chain traceability for coffee, cocoa, and other commodities',
  'DFI':    'Development Finance Institution — government-backed lender (IFC, BII, Proparco, AfDB, BRD)',
  'PAYD':   'Pay-As-You-Drive — financing model converting upfront hardware cost to daily operational subscription',
  'BVLOS':  'Beyond Visual Line of Sight — drone operation mode; Rwanda has world\'s first BVLOS medical delivery framework',
  'SACCO':  'Savings and Credit Cooperative — embedded financial intermediaries for Rwanda\'s smallholder and informal sector',
  'CIT':    'Corporate Income Tax — 30% standard; 0% for qualifying regional HQ; 15% for ICT companies',
  'VAT':    'Value Added Tax — 18% standard rate; registration threshold RWF 20M annual turnover',
  'RWF':    'Rwandan Franc — official currency; ~RWF 1,350–1,400 per USD (mid-2025); ~8–12% annual depreciation vs USD',
  'DST':    'Digital Services Tax — Rwanda 2026 tax on qualifying digital service providers',
  'TIN':    'Tax Identification Number — auto-issued alongside company code at RDB registration',
  'KYC':    'Know Your Customer — mandatory identity verification for banking and financial services onboarding',
  'AML':    'Anti-Money Laundering — compliance requirement for all financial services and banking in Rwanda',
  'SEZ':    'Special Economic Zone — designated zone with enhanced tax and operational incentives',
  'EIB':    'European Investment Bank — EUR 100M active agriculture facility for Rwanda (2024–2025)',
  'USAID':  'US Agency for International Development — active Rwanda grant and co-investment programmes',
  'IFC':    'International Finance Corporation — World Bank Group private sector arm, active Rwanda portfolio',
  'BII':    'British International Investment — UK DFI with active East Africa portfolio',
  'PPH':    'Postpartum Haemorrhage — leading cause of maternal mortality; 88% reduction in Zipline-served Rwanda areas',
  'EHR':    'Electronic Health Record — Rwanda executing national EHR rollout under HSSP V',
  'CHW':    'Community Health Worker — 45,000+ active in Rwanda; ready distribution network for digital health tools',
  'HSSP':   'Health Sector Strategic Plan — Rwanda\'s 5-year health sector plan (HSSP V: 2025–2030)',
  'C&I':    'Commercial and Industrial — solar segment targeting businesses and manufacturers',
  'mRNA':   'Messenger RNA — vaccine technology; BioNTech established Rwanda\'s first mRNA manufacturing facility (2023–2024)',
  'OECD':   'Organisation for Economic Co-operation and Development — BEPS compliance required for multinationals in KIFC',
  'BEPS':   'Base Erosion and Profit Shifting — OECD framework; compliance required for multinationals using Rwanda\'s 0% CIT HQ regime',
  'DPIA':   'Data Protection Impact Assessment — required under Rwanda\'s Data Protection Act for high-risk processing',
  'DPO':    'Data Protection Officer — required appointment under Rwanda\'s Data Protection Act for entities processing sensitive data',
  'FCPA':   'Foreign Corrupt Practices Act — US anti-bribery law; applies to US-connected companies operating in Rwanda',
  'MoU':    'Memorandum of Understanding — non-binding agreement; KIFC has signed MoUs for licence passporting with African financial regulators',
  'HQ':     'Headquarters — 0% CIT available for companies establishing genuine regional HQ in Rwanda via RDB/KIFC',
  'SLA':    'Service Level Agreement — contract term specifying delivery performance metrics; Zipline\'s Rwanda model uses SLA-based B2G contracts',
  'B2G':    'Business-to-Government — sales model where government is the primary customer (Zipline\'s Rwanda model)',
  'B2B':    'Business-to-Business — sales model targeting companies, not consumers; dominant model for Rwanda market entry',
  'EOR':    'Employer of Record — HR/payroll service that enables companies to hire without local entity; Raenest\'s original business model',
  'IMTO':   'International Money Transfer Operator — licence category from Central Bank of Nigeria; held by Raenest',
  'MSB':    'Money Services Business — Canadian financial services licence; held by Raenest for North American operations',
  'PSP':    'Payment Service Provider — NBR licence category for companies processing payments in Rwanda',
  'EMI':    'Electronic Money Issuer — NBR licence category for companies issuing e-money in Rwanda',
  'MFI':    'Microfinance Institution — NBR-regulated entity providing small loans to underserved populations',
  'FDI':    'Foreign Direct Investment — USD 872.9M inflow to Rwanda in 2024 (+21.8% YoY, RDB)',
  'GDP':    'Gross Domestic Product — Rwanda ~USD 17.8B nominal (2025); 9.4% real growth in 2025',
  'PPP':    'Purchasing Power Parity — Rwanda GDP ~USD 72B PPP-adjusted (World Economics 2025)',
  'CPI':    'Consumer Price Index — inflation measure; Rwanda CPI 4.8% end-2024; 5.6% projected 2026 (IMF)',
};

let visitedSections = new Set();
let bookmarkedSection = null;
let darkModeEnabled = false;
let tooltipEl = null;

const initialDarkMode = localStorage.getItem('mep-darkmode-rw') === '1';
if (initialDarkMode) {
  document.body.classList.add('dark');
  darkModeEnabled = true;
}

function persistVisited() {
  localStorage.setItem('mep-visited-rw', JSON.stringify([...visitedSections]));
}

function hydrateVisited() {
  const raw = localStorage.getItem('mep-visited-rw');
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (Array.isArray(list)) {
      visitedSections = new Set(list);
      updateVisitedChecks();
    }
  } catch {
    visitedSections = new Set();
  }
}

function updateVisitedChecks() {
  visitedSections.forEach(id => {
    const button = document.querySelector(`.nav-btn[data-panel="${id}"]`);
    if (!button || button.querySelector('.nav-check')) return;
    const mark = document.createElement('span');
    mark.className = 'nav-check';
    mark.textContent = '✓';
    button.appendChild(mark);
  });
}

function markVisited(id) {
  if (visitedSections.has(id)) return;
  visitedSections.add(id);
  persistVisited();
  updateVisitedChecks();
}

function updateProgressBar(index) {
  const fill = document.querySelector('.pack-progress-fill');
  if (!fill) return;
  fill.style.width = `${Math.round(((index + 1) / SECTION_ORDER.length) * 100)}%`;
}

function hydrateBookmark() {
  const raw = localStorage.getItem('mep-bookmark-rw');
  bookmarkedSection = raw || null;
  updateBookmarkIndicators();
}

function updateBookmarkIndicators() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const isBookmarked = btn.dataset.panel === bookmarkedSection;
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (isBookmarked) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.title = 'Bookmarked';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else if (indicator) {
      indicator.remove();
    }
  });

  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.style.opacity = btn.dataset.panel === bookmarkedSection ? '1' : '0.35';
  });
}

function setBookmark(panelId) {
  if (panelId === bookmarkedSection) {
    bookmarkedSection = null;
    localStorage.removeItem('mep-bookmark-rw');
  } else {
    bookmarkedSection = panelId;
    localStorage.setItem('mep-bookmark-rw', panelId);
  }
  updateBookmarkIndicators();
}

function initFeatures() {
  hydrateVisited();
  hydrateBookmark();
  hydrateDarkMode();
  initializeProseCards();
  wrapAcronyms();
  createTooltip();
  document.getElementById('pack-search')?.addEventListener('input', onSearchInput);
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);

  document.querySelector('.pack-root')?.addEventListener('click', event => {
    const proseToggle = event.target.closest('.prose-toggle');
    if (proseToggle) {
      event.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;

      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
      return;
    }

    const fundingToggle = event.target.closest('.funding-toggle');
    if (fundingToggle) {
      event.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;

      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
    }
  });

  if (bookmarkedSection) {
    showPanel(bookmarkedSection);
  } else {
    const current = document.querySelector('.nav-btn.active')?.dataset.panel || SECTION_ORDER[0];
    showPanel(current);
  }
}

function hydrateDarkMode() {
  darkModeEnabled = localStorage.getItem('mep-darkmode-rw') === '1';
  document.body.classList.toggle('dark', darkModeEnabled);
  updateDarkToggleLabel();
}

function updateDarkToggleLabel() {
  const button = document.getElementById('darkmode-toggle');
  if (!button) return;
  button.textContent = darkModeEnabled ? '☀️' : '🌙';
}

function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode-rw', darkModeEnabled ? '1' : '0');
  updateDarkToggleLabel();
}

function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  window.setTimeout(() => {
    document.body.classList.remove('print-mode');
  }, 100);
}

function onSearchInput(event) {
  const query = event.target.value.trim();
  clearSearchHighlights();
  if (!query) return;
  highlightSearch(query);
}

function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, .pack-progress-bar, .mep-tooltip')) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;

    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  }

  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) {
      const panelId = panel.id.replace('panel-', '');
      showPanel(panelId);
    }
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
}

function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.createElement('div');
  tooltipEl.id = 'mep-tooltip';
  tooltipEl.className = 'mep-tooltip';
  document.body.appendChild(tooltipEl);
  document.querySelector('.pack-root')?.addEventListener('pointerover', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('pointerout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
  document.querySelector('.pack-root')?.addEventListener('focusin', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('focusout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
}

function showTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || target.title || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 240, Math.max(8, rect.left));
  const top = rect.bottom + 10;
  tooltipEl.style.top = `${top}px`;
  tooltipEl.style.left = `${left}px`;
}

function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, script, .mep-abbr, .search-highlight')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    if (!acronymRegex.test(text)) continue;
    replacements.push(node);
  }

  replacements.forEach(node => {
    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    acronymRegex.lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.title = ACRONYMS[match[0]] || '';
      abbr.tabIndex = 0;
      abbr.textContent = match[0];
      fragment.appendChild(abbr);
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  });
}

function hideTooltip() {
  if (!tooltipEl) return;
  tooltipEl.style.opacity = '0';
}

/* ═══════════════════════════════════════════════════════════════
   TASK 2 — HOW-CARD NAVIGATION
   ═══════════════════════════════════════════════════════════════ */
function bindHowCards() {
  document.querySelectorAll('.how-card-link').forEach(card => {
    const handler = () => {
      const panel = card.dataset.navPanel;
      if (!panel) return;
      showPanel(panel);
      // Scroll to anchor if specified
      const anchor = card.dataset.navAnchor;
      if (anchor) {
        setTimeout(() => {
          const el = document.getElementById(anchor);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); }
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   TASK 7 — INTERACTIVE SCORECARD (Rwanda-adapted)
   Same slider mechanic as Ghana MEP, Rwanda-specific dimensions.
   ═══════════════════════════════════════════════════════════════ */

const SCORECARD_DIMENSIONS = [
  {
    id: 'political',
    name: 'Political &amp; Macroeconomic Stability',
    section: 'Market Conditions',
    baseContext: 'Rwanda has maintained exceptional political stability under Vision 2050. GDP growth at 7.5% (2024), inflation below 6%, and IMF Article IV consistently positive. One of Africa\'s most stable operating environments.',
    contextFn: null
  },
  {
    id: 'regulatory',
    name: 'Regulatory Ease',
    section: 'Market Conditions',
    baseContext: 'RDB One Stop Centre: 1-day company registration, no minimum capital requirement. Rwanda ranked #2 globally for business registration speed (World Bank). Consistent rule-of-law scores.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: NBR regulatory sandbox operates on 3–4 month pathway — fastest in East Africa. KIFC passporting enables multi-market licensing from a single Rwanda base. Moderate regulatory burden with strong sandbox support.',
        agritech: 'Agritech: MINAGRI and NAEB are key engagement points. NAEB certification required for export plays. Land tenure reform well-advanced; customary land rights registered. Relatively low regulatory friction.',
        healthtech: 'Healthtech: Rwanda FDA (RURA equivalent: RBC and MoH) regulate medical devices and pharma. MoH partnership model required for B2G healthcare plays. Data Protection Act (RISA) governs health data — active enforcement.',
        climate: 'Climate: Zero EV import duties, RURA issues generation and EV charging licences. Ireme Invest non-dilutive grant pathway active. Regulatory environment is actively enabling for clean energy operators.',
        saas: 'B2B SaaS: 15% CIT rate for ICT companies vs 30% standard. 2026 Digital Services Tax applies to qualifying platforms — consult Rwanda tax counsel. Lightest regulatory burden of all sectors.',
        other: 'Cross-sector: RDB registration is the universal starting point. Investment Certificate unlocks incentives and Key Account Manager access. Generally enabling environment for foreign-owned entities.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'market_size',
    name: 'Market Size &amp; Growth Trajectory',
    section: 'Market Conditions',
    baseContext: 'Population: 14.9M. GDP $14.8B growing at 7.5%+. Primary value is EAC gateway (670M population) rather than domestic scale. Rwanda positions as the proof-of-concept market and regional HQ, not a standalone mass market.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: 96% financial inclusion rate; MTN MoMo and Airtel Money rails fully interoperable. KIFC targets USD 200M investment; 25 fund domiciliations by 2029. MMIP live since 2021.',
        agritech: 'Agritech: 40%+ of GDP from agriculture. 2M+ smallholder farmers. NST2 targets 50% yield increase and USD 4.6B private sector ag investment by 2029. Coffee and tea export premium market is USD 70M+/yr.',
        healthtech: 'Healthtech: 90%+ CBHI coverage. 14.9M population with high state health engagement. Zipline precedent validates B2G health logistics model. MoH is active co-development partner.',
        climate: 'Climate: Zero-emission targets by 2050. 100% electricity access target by 2030 (72% now). EV bus and motorcycle market nascent but government-mandated. BasiGO\'s 60-bus fleet is operational proof.',
        saas: 'B2B SaaS: KIC hosts 4 STEM universities including CMU-Africa. Government ICT procurement is significant and active. Regional HQ structure unlocks EAC markets from a low-friction base.',
        other: 'General: Domestic ceiling is modest. Rwanda entry value is proof-of-concept, reputational credibility, and EAC gateway positioning rather than standalone domestic scale.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'digital_infra',
    name: 'Digital Infrastructure',
    section: 'Operational Readiness',
    baseContext: '4G coverage: 97% of populated areas. Mobile money interoperability live since 2021. National ID system (Irembo) enables digital-first KYC. Kigali Innovation City (61 ha) groundbreaking Sept 2024.',
    contextFn: null
  },
  {
    id: 'talent',
    name: 'Talent Availability',
    section: 'Operational Readiness',
    baseContext: 'English and French-speaking workforce. CMU-Africa, University of Rwanda, and ALU producing tech talent. Kigali talent pool is smaller than Nairobi but growing rapidly. Remote team model common.',
    contextFn: (sector, talent) => {
      const map = {
        tech: 'Tech/Engineering: CMU-Africa and University of Rwanda CS produce 200–300 graduates/yr. kLab and Norrsken House are top recruitment pipelines. Smaller pool than Nairobi — plan for hybrid remote from Day 1.',
        commercial: 'Commercial/Sales: Strong commercial talent exists at Series A+ companies (Zipline, BasiGO, mPharma Rwanda). B2B sales culture emerging rapidly. Government relationship management is a distinct skill — hire for it specifically.',
        finance: 'Finance/Legal: Big 4 presence (PwC, KPMG, EY, Andersen Rwanda). Rwanda-qualified lawyers available via Rwanda Bar Association. Strong for DFI-backed transactions and M&A.',
        agri: 'Agricultural/Field: Strong field extension worker base via MINAGRI and cooperative networks. NAEB has certification training infrastructure. Kinyarwanda-language field staff are essential for smallholder programmes.',
        health: 'Healthcare/Clinical: 0.07 doctors per 1,000 (among Africa\'s lowest). CHW network (45,000+) is the real health delivery infrastructure. Partner with RBC for clinical credibility and CHW access.'
      };
      return map[talent] || null;
    }
  },
  {
    id: 'capital',
    name: 'Capital Access',
    section: 'Funding &amp; Growth',
    baseContext: 'DFI ecosystem: IFC, BII, Proparco, AfDB, USAID, BRD (domestic). Norrsken22, Founders Factory Africa active in Kigali. Non-dilutive: Ireme Invest, USAID Rwanda, RDB incentives.',
    contextFn: (sector, talent, stage) => {
      const map = {
        explore: 'Exploring: Ireme Invest (USD 50K–500K, non-dilutive) and USAID Rwanda grants are most accessible. Focus on non-dilutive pathways before equity dilution at validation stage. RDB Investment Certificate unlocks Key Account Manager support.',
        pilot: 'Piloting: Norrsken22 (Kigali-based), Founders Factory Africa, and Antler East Africa are primary equity targets. Warm intros critical — Norrsken House community is the most active deal-flow channel. Plan 4–9 month fundraise timeline.',
        scale: 'Scaling: IFC Kigali Office, BII, Proparco, and BRD are the primary channels. KIFC structure (0% CIT for regional HQ) significantly improves DFI fundability. Gender lens and climate alignment are key unlock factors for concessional rates.'
      };
      return map[stage] || null;
    }
  },
  {
    id: 'eac_gateway',
    name: 'EAC Gateway &amp; Regional Positioning',
    section: 'Strategic Upside',
    baseContext: 'EAC Common Market Protocol: free movement of capital and professionals across Rwanda, Kenya, Uganda, Tanzania, Burundi, South Sudan, DRC. Combined market: 670M people, USD 300B+ GDP. KIFC passporting enables licence replication across African financial markets.',
    contextFn: null
  },
  {
    id: 'execution_risk',
    name: 'Execution Risk (lower = better score)',
    section: 'Risk Assessment',
    baseContext: 'Key risks: small domestic market ceiling, RWF depreciation (~13% in 2024), government partnership dependency, talent pool depth, and geopolitical risk (DRC border). Rwanda-based government partnerships can be withdrawn — build diversified revenue from Day 1.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech execution risk: MEDIUM. NBR sandbox is enabling but licensing still takes 3–6 months. MMIP infrastructure is functional. Key risk: over-reliance on government partnership for distribution.',
        agritech: 'Agritech execution risk: MEDIUM-HIGH. Cooperative gatekeeping, smallholder adoption pace, and Kinyarwanda-only user base require deep localisation. NAEB dependency for export plays.',
        healthtech: 'Healthtech execution risk: HIGH. B2G model is the primary commercial pathway but government procurement is slow and sometimes unpredictable. Outcome metrics and MoH relationship management are mission-critical.',
        climate: 'Climate execution risk: MEDIUM. EV import duty exemptions are policy-dependent. Grid infrastructure investment in progress but rural electrification timeline is ambitious. Hardware logistics and maintenance are operational challenges.',
        saas: 'B2B SaaS execution risk: LOW-MEDIUM. Lightest regulatory burden. Key risks are ICT procurement cycle length and DST applicability uncertainty. Regional expansion via KIFC reduces single-market revenue risk.',
        other: 'Execution risk: variable. General risks include small domestic market, FX exposure (RWF depreciation), and government relationship management complexity.'
      };
      return map[sector] || null;
    }
  }
];

const scorecardState = {};

function getScorecardContextText(dim, sector, talent, stage) {
  if (dim.contextFn) {
    const ctx = dim.contextFn(sector, talent, stage);
    if (ctx) return ctx;
  }
  return dim.baseContext;
}

function getScoreClass(score) {
  if (score === 0) return '';
  if (score >= 7) return 'score-high';
  if (score >= 5) return 'score-mid';
  return 'score-low';
}

function calcTotal() {
  const ids = SCORECARD_DIMENSIONS.map(d => d.id);
  const scored = ids.filter(id => scorecardState[id] != null);
  if (scored.length === 0) return null;
  const sum = scored.reduce((acc, id) => acc + scorecardState[id], 0);
  return (sum / scored.length).toFixed(1);
}

function updateScorecardResult() {
  const total = calcTotal();
  const scoreEl = document.getElementById('sc-total-score');
  const labelEl = document.getElementById('sc-result-label');
  const signalEl = document.getElementById('sc-result-signal');
  if (!scoreEl || !labelEl || !signalEl) return;

  if (total === null) {
    scoreEl.textContent = '—';
    labelEl.textContent = 'Rate each dimension to generate your entry signal.';
    signalEl.textContent = '';
    signalEl.className = 'scorecard-result-signal';
    return;
  }

  const t = parseFloat(total);
  scoreEl.textContent = `${total}/10`;

  if (t >= 7) {
    labelEl.textContent = 'Strong entry window for your profile. Rwanda\'s stability, fast registration, and EAC gateway positioning make this a compelling commitment.';
    signalEl.textContent = 'Strong Entry Window';
    signalEl.className = 'scorecard-result-signal signal-strong';
  } else if (t >= 5) {
    labelEl.textContent = 'Promising but context-dependent. Address your red-flag dimensions — particularly market size ceiling and talent depth — before committing capital.';
    signalEl.textContent = 'Promising — Address Red Flags';
    signalEl.className = 'scorecard-result-signal signal-promising';
  } else {
    labelEl.textContent = 'Significant barriers identified. Revisit entry timing or strategy, or de-risk the lowest-scoring dimensions first. Consider EAC market sizing.';
    signalEl.textContent = 'Caution — Revisit Strategy';
    signalEl.className = 'scorecard-result-signal signal-caution';
  }
}

function renderScorecardRows() {
  const container = document.getElementById('scorecard-rows');
  if (!container) return;
  const sector = document.getElementById('sc-sector')?.value || 'other';
  const talent = document.getElementById('sc-talent')?.value || 'tech';
  const stage = document.getElementById('sc-stage')?.value || 'explore';

  let html = '';
  let lastSection = '';

  for (const dim of SCORECARD_DIMENSIONS) {
    if (dim.section !== lastSection) {
      html += `<div class="scorecard-section-heading">${dim.section}</div>`;
      lastSection = dim.section;
    }
    const score = scorecardState[dim.id] || 0;
    const scoreClass = getScoreClass(score);
    const ctx = getScorecardContextText(dim, sector, talent, stage);
    const valDisplay = score === 0 ? '—' : `${score}/10`;

    html += `
      <div class="scorecard-dim" id="sc-dim-${dim.id}">
        <div class="scorecard-dim-header">
          <div class="scorecard-dim-name">${dim.name}</div>
          <div class="scorecard-dim-val ${scoreClass} ${score > 0 ? 'scored' : ''}" id="sc-val-${dim.id}">${valDisplay}</div>
        </div>
        <div class="scorecard-dim-context">${ctx}</div>
        <div class="scorecard-slider-wrap">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">0</span>
          <input type="range" class="scorecard-slider" id="sc-slider-${dim.id}"
            min="0" max="10" step="0.5" value="${score}"
            data-dim-id="${dim.id}" aria-label="${dim.name} score">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">10</span>
        </div>
      </div>`;
  }

  container.innerHTML = html;

  // Bind slider events
  container.querySelectorAll('.scorecard-slider').forEach(slider => {
    slider.addEventListener('input', () => {
      const id = slider.dataset.dimId;
      const val = parseFloat(slider.value);
      scorecardState[id] = val;
      const valEl = document.getElementById(`sc-val-${id}`);
      if (valEl) {
        valEl.textContent = val === 0 ? '—' : `${val}/10`;
        valEl.className = `scorecard-dim-val ${val > 0 ? 'scored' : ''} ${getScoreClass(val)}`;
      }
      updateScorecardResult();
    });
  });
}

function initInteractiveScorecard() {
  const container = document.getElementById('interactive-scorecard');
  if (!container) return;

  renderScorecardRows();
  updateScorecardResult();

  // Context selectors trigger re-render of context text
  ['sc-sector', 'sc-talent', 'sc-stage'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => {
      renderScorecardRows();
    });
  });

  // Reset button
  document.getElementById('sc-reset-btn')?.addEventListener('click', () => {
    SCORECARD_DIMENSIONS.forEach(d => { scorecardState[d.id] = 0; });
    renderScorecardRows();
    updateScorecardResult();
  });
}

// Patch initFeatures to include how-card binding + scorecard init
const _origInitFeatures = initFeatures;
initFeatures = function() {
  _origInitFeatures();
  bindHowCards();
};

document.addEventListener('DOMContentLoaded', () => {
  bindHowCards();
  // Scorecard init after content loaded
  setTimeout(initInteractiveScorecard, 300);
});

/* ═══════════════════════════════════════════════════════════════
   MONOCLE 2026 — FEATURE ADDITIONS
   Appended below original handlers — nothing above is modified.
   ═══════════════════════════════════════════════════════════════ */

// ── 1. STICKY NAV SCROLL STATE ──
// (already handled in original DOMContentLoaded block above)

// ── 2. DARK MODE ──
// Already implemented above as hydrateDarkMode / toggleDarkMode.
// Patch: ensure dark toggle button is wired even if initFeatures
// runs before the button is in the DOM.
// Dark mode toggle is wired in initFeatures() — no duplicate listener needed here.

// ── 3. READING PROGRESS BAR ──
// Already wired through updateProgressBar called inside showPanel.

// ── 4. PRINT TRIGGER ──
// Already implemented above as triggerPrint.

// ── 5. VISITED / BOOKMARK STATE ──
// Already implemented above.

// ── 6. SEARCH ──
// Already implemented above (onSearchInput / highlightSearch).

// ── 7. ACRONYM TOOLTIPS ──
// Already implemented above (wrapAcronyms / createTooltip).

// ── 8. PROSE + FUNDING ACCORDIONS ──
// Already implemented above (initializeProseCards + delegated click).

// Expose showPanel to window object so patches can find it
window.showPanel = showPanel;

// ── 9. SMOOTH SCROLL TO TOP ON PANEL CHANGE ──
// Patch showPanel to also smooth-scroll to top of content.
(function patchShowPanelScroll() {
  const _orig = window.showPanel;
  if (!_orig) return;
  window.showPanel = function(id) {
    _orig(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
})();

// ── 10. STAGGERED CARD ENTRANCE ANIMATION TRIGGER ──
// Ensures CSS animation re-triggers on panel switch by
// force-reflowing newly active panels.
(function patchShowPanelReflow() {
  const _prev = window.showPanel;
  if (!_prev) return;
  window.showPanel = function(id) {
    _prev(id);
    const panel = document.getElementById('panel-' + id);
    if (panel) {
      // Force reflow so CSS animations replay
      panel.querySelectorAll('.stat-card, .how-card, .how-card-link').forEach(el => {
        el.style.animation = 'none';
        void el.offsetHeight; // trigger reflow
        el.style.animation = '';
      });
    }
  };
})();

// ── 11. DYNAMIC DARKMODE TOGGLE LABEL ON LOAD ──
(function initDarkLabelOnLoad() {
  const apply = () => {
    const btn = document.getElementById('darkmode-toggle');
    if (!btn) return;
    const isDark = document.body.classList.contains('dark');
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }
})();

// ── 12. FUNDING SECTION ACCORDION — ensure default open ──
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    // Default: expanded
    if (!btn.hasAttribute('aria-expanded')) {
      btn.setAttribute('aria-expanded', 'true');
    }
    if (btn.getAttribute('aria-expanded') === 'true') {
      body.style.maxHeight = body.scrollHeight + 'px';
    } else {
      body.style.maxHeight = '0';
    }
  });
});
