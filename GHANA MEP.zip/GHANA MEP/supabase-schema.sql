-- Ghana Market Entry Pack feedback backend
-- Run this once in the Supabase SQL editor.
-- After running it, replace the temporary admin password below.

create extension if not exists pgcrypto;

create table if not exists public.market_insights (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  sector text,
  insight_text text not null,
  contributor_name text,
  page_url text,
  user_agent text,
  reviewed boolean not null default false,
  internal_notes text
);

create table if not exists public.service_provider_ratings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  provider_name text not null,
  rating integer not null check (rating between 1 and 5),
  comment text,
  page_url text,
  user_agent text,
  reviewed boolean not null default false,
  internal_notes text
);

create table if not exists public.intro_requests (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  looking_for text not null,
  company_context text not null,
  email text not null,
  page_url text,
  user_agent text,
  status text not null default 'new' check (status in ('new', 'contacted', 'closed')),
  internal_notes text
);

create table if not exists public.pack_ratings (
  id uuid primary key default gen_random_uuid(),
  created_at timestamptz not null default now(),
  rating integer not null check (rating between 1 and 5),
  page_url text,
  user_agent text
);

create table if not exists public.admin_settings (
  key text primary key,
  value text not null,
  updated_at timestamptz not null default now()
);

insert into public.admin_settings (key, value)
values ('admin_password_hash', extensions.crypt('change-me-now', extensions.gen_salt('bf')))
on conflict (key) do nothing;

alter table public.market_insights enable row level security;
alter table public.service_provider_ratings enable row level security;
alter table public.intro_requests enable row level security;
alter table public.pack_ratings enable row level security;
alter table public.admin_settings enable row level security;

drop policy if exists "Allow public insight submissions" on public.market_insights;
create policy "Allow public insight submissions"
on public.market_insights
for insert
to anon
with check (
  insight_text is not null
  and length(trim(insight_text)) > 0
);

drop policy if exists "Allow public provider ratings" on public.service_provider_ratings;
create policy "Allow public provider ratings"
on public.service_provider_ratings
for insert
to anon
with check (
  provider_name is not null
  and length(trim(provider_name)) > 0
  and rating between 1 and 5
);

drop policy if exists "Allow public intro requests" on public.intro_requests;
create policy "Allow public intro requests"
on public.intro_requests
for insert
to anon
with check (
  looking_for is not null
  and company_context is not null
  and email is not null
  and length(trim(looking_for)) > 0
  and length(trim(company_context)) > 0
  and length(trim(email)) > 0
);

drop policy if exists "Allow public pack ratings" on public.pack_ratings;
create policy "Allow public pack ratings"
on public.pack_ratings
for insert
to anon
with check (rating between 1 and 5);

create index if not exists market_insights_created_at_idx on public.market_insights (created_at desc);
create index if not exists service_provider_ratings_created_at_idx on public.service_provider_ratings (created_at desc);
create index if not exists intro_requests_created_at_idx on public.intro_requests (created_at desc);
create index if not exists pack_ratings_created_at_idx on public.pack_ratings (created_at desc);

create or replace function public.set_admin_password(new_password text)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  if new_password is null or length(new_password) < 12 then
    raise exception 'Admin password must be at least 12 characters.';
  end if;

  insert into public.admin_settings (key, value, updated_at)
  values ('admin_password_hash', extensions.crypt(new_password, extensions.gen_salt('bf')), now())
  on conflict (key) do update
  set value = excluded.value,
      updated_at = now();
end;
$$;

create or replace function public.is_admin_password(password text)
returns boolean
language sql
security definer
stable
set search_path = public
as $$
  select exists (
    select 1
    from public.admin_settings
    where key = 'admin_password_hash'
      and value = extensions.crypt(password, value)
  );
$$;

create or replace function public.get_admin_submissions(password text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  is_valid boolean;
begin
  select public.is_admin_password(password) into is_valid;
  if not is_valid then
    raise exception 'Invalid admin password.';
  end if;

  return jsonb_build_object(
    'market_insights',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.market_insights t), '[]'::jsonb),
    'service_provider_ratings',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.service_provider_ratings t), '[]'::jsonb),
    'intro_requests',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.intro_requests t), '[]'::jsonb),
    'pack_ratings',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.pack_ratings t), '[]'::jsonb)
  );
end;
$$;

revoke all on table public.market_insights from anon, authenticated;
revoke all on table public.service_provider_ratings from anon, authenticated;
revoke all on table public.intro_requests from anon, authenticated;
revoke all on table public.pack_ratings from anon, authenticated;
revoke all on table public.admin_settings from anon, authenticated;
revoke execute on function public.set_admin_password(text) from public, anon, authenticated;
revoke execute on function public.is_admin_password(text) from public, anon, authenticated;
revoke execute on function public.get_admin_submissions(text) from public, anon, authenticated;

grant insert on table public.market_insights to anon;
grant insert on table public.service_provider_ratings to anon;
grant insert on table public.intro_requests to anon;
grant insert on table public.pack_ratings to anon;
grant execute on function public.is_admin_password(text) to anon;
grant execute on function public.get_admin_submissions(text) to anon;

-- ═══════════════════════════════════════════════════════════════
-- Pack Content — editable text blocks for index.html
-- ═══════════════════════════════════════════════════════════════

create table if not exists public.pack_content (
  id text primary key,
  content text not null,
  updated_at timestamptz not null default now(),
  updated_by text
);

alter table public.pack_content enable row level security;

-- Anon can read all content (public page)
drop policy if exists "Allow public content reads" on public.pack_content;
create policy "Allow public content reads"
on public.pack_content
for select
to anon
using (true);

-- No direct insert/update/delete from client — all writes go through RPC
revoke insert, update, delete on table public.pack_content from anon, authenticated;
grant select on table public.pack_content to anon;

-- Security-definer RPC for admin content updates
create or replace function public.update_pack_content(
  password text,
  content_id text,
  new_content text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  is_valid boolean;
begin
  select public.is_admin_password(password) into is_valid;
  if not is_valid then
    raise exception 'Invalid admin password.';
  end if;

  insert into public.pack_content (id, content, updated_at, updated_by)
  values (content_id, new_content, now(), 'admin')
  on conflict (id) do update
  set content = excluded.content,
      updated_at = excluded.updated_at,
      updated_by = excluded.updated_by;
end;
$$;

revoke execute on function public.update_pack_content(text, text, text) from public, anon, authenticated;
grant execute on function public.update_pack_content(text, text, text) to anon;

-- Seed default content from index.html (ON CONFLICT DO NOTHING — won't overwrite edits)
insert into public.pack_content (id, content) values
  -- Front matter
  ('front-eyebrow', '2026 Edition — West Africa Series'),
  ('front-title', 'Ghana
Market Entry Pack'),
  ('front-sub', 'A strategic playbook for founders, operators, and investors entering one of Africa''s most reformed economies.'),
  ('front-how-title', 'How to use this pack'),
  ('front-how1-label', 'Orient fast'),
  ('front-how1-desc', 'Use the Country Snapshot and Scorecard to decide if Ghana is even the right move before reading further.'),
  ('front-how2-label', 'Match your sector'),
  ('front-how2-desc', 'Jump to Section 3 and read only the sector(s) relevant to your business. Each has its own competitive landscape and opportunities.'),
  ('front-how3-label', 'Structure your entry'),
  ('front-how3-desc', 'Use Section 2''s decision matrix to pick your entry vehicle, then follow the registration checklist.'),
  ('front-how4-label', 'Share and improve'),
  ('front-how4-desc', 'Add your feedback via the Feedback tab. Rate agencies, flag things that have changed, and request intros.'),
  ('front-fit-title', 'Who belongs here — and who doesn''t'),
  ('front-analyst-note', 'Ghana is in a genuine inflection point. After the 2022 debt crisis and IMF programme, the macro recovery through 2025–26 has exceeded expectations — the cedi has appreciated ~40% against the dollar, inflation has fallen from 54% to 3.3%, and GDP crossed $100bn. The new Mahama administration''s reform agenda (GIPA Bill, GIPC liberalisation, Feed Ghana Programme) signals sustained investor intent. The AfCFTA Secretariat being domiciled in Accra is a structural advantage few markets can replicate.

That said, high domestic interest rates (25%+), energy sector fragility, and a legal system where disputes take years to resolve remain genuine drags. The opportunity is real — but execution risk is high for those entering without local anchoring.'),

  -- Section 1
  ('s1-title', 'Strategic Country Overview'),
  ('s1-intro', 'Ghana is West Africa''s most stable democracy and, as of 2025, one of the ten largest economies on the continent. This section covers the political and economic backdrop, business culture, infrastructure, and Ghana''s strategic position in regional integration frameworks.'),
  ('s1-gdp-value', '$100B+'),
  ('s1-gdp-sub', 'Top 10 in Africa'),
  ('s1-growth-value', '5.1%'),
  ('s1-growth-sub', 'World Bank forecast'),
  ('s1-inflation-value', '3.3%'),
  ('s1-inflation-sub', 'Down from 54% peak'),
  ('s1-population-value', '34M'),
  ('s1-population-sub', '56% under age 25'),
  ('s1-fx-reserves-value', '$13.8B'),
  ('s1-fx-reserves-sub', '5.7 months import cover'),

  -- Section 2
  ('s2-title', 'Market Entry Framework'),
  ('s2-intro', 'This section covers the mechanics of setting up in Ghana — registration requirements, entry strategy options, regulatory risk, and FX considerations. The decision matrix below is designed to help you pick the right vehicle for your business model and risk profile.'),
  ('s2-fx-usd-rate', '~10.5'),
  ('s2-fx-usd-trend', 'Cedi +40.7% vs USD (2025)'),
  ('s2-fx-gbp-rate', '~13.5'),
  ('s2-fx-gbp-trend', 'Cedi +30.9% vs GBP (2025)'),
  ('s2-fx-eur-rate', '~11.8'),
  ('s2-fx-eur-trend', 'Cedi +24% vs EUR (2025)'),

  -- Section 3
  ('s3-title', 'Sector Deep Dives'),
  ('s3-intro', 'Four sectors with the strongest entry dynamics in Ghana right now. Select a sector tab below to explore market sizing, regulatory environment, competitive landscape, opportunities, and industry associations.'),

  -- Fintech stats
  ('s3-fintech-unbanked-value', '~40%'),
  ('s3-fintech-unbanked-sub', 'Declining rapidly'),
  ('s3-fintech-momo-value', '$50B+'),
  ('s3-fintech-momo-sub', 'Annual (2024 est.)'),
  ('s3-fintech-cos-value', '200+'),
  ('s3-fintech-cos-sub', 'Registered entities'),
  ('s3-fintech-sandbox-value', 'Active'),
  ('s3-fintech-sandbox-sub', 'Since 2021'),

  -- Agritech stats
  ('s3-agritech-gdp-value', '~20%'),
  ('s3-agritech-gdp-sub', 'of GDP'),
  ('s3-agritech-workforce-value', '~40%'),
  ('s3-agritech-workforce-sub', 'Mostly smallholder'),
  ('s3-agritech-cocoa-value', '~$3B'),
  ('s3-agritech-cocoa-sub', 'Annually (world''s 2nd)'),
  ('s3-agritech-feed-value', 'Active'),
  ('s3-agritech-feed-sub', '2025–2030 programme'),

  -- Healthtech stats
  ('s3-healthtech-doctors-value', '0.14'),
  ('s3-healthtech-doctors-sub', 'WHO benchmark: 1.0'),
  ('s3-healthtech-nhis-value', '~35%'),
  ('s3-healthtech-nhis-sub', 'Active enrollees'),
  ('s3-healthtech-oop-value', '~30%'),
  ('s3-healthtech-oop-sub', 'of health expenditure'),
  ('s3-healthtech-cos-value', '80+'),
  ('s3-healthtech-cos-sub', 'Active in Ghana'),

  -- Edtech stats
  ('s3-edtech-schoolage-value', '~8M'),
  ('s3-edtech-schoolage-sub', 'K–12'),
  ('s3-edtech-tertiary-value', '~18%'),
  ('s3-edtech-tertiary-sub', 'Rising annually'),
  ('s3-edtech-unicef-value', '40%'),
  ('s3-edtech-unicef-sub', 'EdTech-focused startups'),
  ('s3-edtech-youth-value', '~13%'),
  ('s3-edtech-youth-sub', 'Skills mismatch key driver'),

  -- Feedback section
  ('feedback-title', 'Help improve this pack'),
  ('feedback-intro', 'This pack is only as good as the collective knowledge behind it. Share what you''ve learned on the ground, rate service providers, flag what''s changed, or request introductions to key contacts.'),
  -- Section 4
  ('s4-title', 'Case Studies'),
  ('s4-intro', 'Real-world examples of how successful ventures navigated the Ghanaian market across our four core sectors. These playbooks highlight strategic entry choices, operational hurdles, and product localisation.'),
  ('s4-fintech-background', 'The company entered Ghana to capitalise on the mature mobile money infrastructure and the massive gap in SME credit. With over 40% of adults still underbanked but almost ubiquitous mobile money usage, the strategic rationale was to use alternative data for underwriting where traditional bureaus failed.'),
  ('s4-fintech-market-sizing', 'Ghana''s SME sector accounts for ~70% of GDP but receives less than 10% of commercial bank lending. The addressable market for micro and SME credit was estimated at over $2B annually, constrained purely by supply and underwriting capability, not demand.'),
  ('s4-fintech-operational', 'Operating under a Tier 2 PSP license, the venture partnered closely with GhIPSS and MTN to access transaction data APIs. They set up local operations in Accra, hiring a team of data scientists to build an underwriting model entirely calibrated on Ghanaian mobile money and utility payment patterns.'),
  ('s4-fintech-competitive', 'Traditional banks were absent from the micro-SME space due to high operational costs. Existing digital lenders were focused strictly on consumer payday loans. The venture entered a whitespace by specifically targeting merchants with working capital loans ranging from $500 to $5,000.'),
  ('s4-fintech-pmf', 'The initial app-based onboarding failed because merchants preferred USSD and WhatsApp for interactions. Growth exploded only after the company released a WhatsApp bot for loan applications and disbursed funds directly to MoMo wallets within 15 minutes of approval, bypassing bank accounts entirely.'),
  ('s4-fintech-financial', 'With domestic interest rates soaring above 25%, the cost of local capital was prohibitive. The company raised USD-denominated debt facilities offshore but had to strictly manage the USD/GHS FX risk. Non-performing loan (NPL) rates were kept below 4% through aggressive, automated collections linked to daily mobile money sweeps.'),
  ('s4-fintech-roadmap', 'They launched a closed pilot in Makola Market, acquiring the first 500 merchants through face-to-face agent sales. They then incentivised these early adopters with lower interest rates for referring other verified merchants in their supply chains, achieving viral, low-CAC growth across Accra and Kumasi.'),
  ('s4-agritech-background', 'The venture was founded to address the severe post-harvest losses and predatory middleman pricing in Ghana''s northern grain corridor. The goal was to build a digital cooperative model that gave smallholder farmers direct access to industrial buyers and fair market prices.'),
  ('s4-agritech-market-sizing', 'Agriculture employs roughly 40% of the workforce, with maize and soybeans being critical staples. However, farmers routinely lost up to 30% of their crop value due to lack of storage and immediate cash needs. The potential to capture margin by disintermediating the supply chain was substantial.'),
  ('s4-agritech-operational', 'The company built physical aggregation centres in the Northern and Bono regions, equipped with moisture meters and digital weighing scales. They developed an offline-first mobile app for field agents to register farmers, record yields, and issue digital receipts that farmers could immediately cash out via mobile money.'),
  ('s4-agritech-competitive', 'The main competitors were informal market aggregators ("market queens") who provided informal credit to farmers in exchange for below-market crop prices. Formal agritech competition was sparse, mostly focused on advisory services rather than physical supply chain logistics.'),
  ('s4-agritech-pmf', 'The purely digital approach initially struggled with trust. PMF was achieved when the company hired respected community leaders as field agents and introduced "input financing" — providing seeds and fertiliser on credit at the start of the season, deducted from the final harvest purchase.'),
  ('s4-agritech-financial', 'Unit economics were tight due to high transport costs on poor rural roads. Profitability hinged on securing forward contracts with large poultry feed manufacturers in Accra, allowing the company to lock in margins and secure working capital financing from the Agricultural Development Bank (ADB) against those contracts.'),
  ('s4-agritech-roadmap', 'Phase 1 involved deeply integrating into three farming communities in Tamale to prove the model and secure a 95% repayment rate on inputs. Phase 2 expanded via partnerships with farmer cooperatives, using radio broadcasts in local languages (Dagbani and Twi) to build brand awareness before agent deployment.'),
  ('s4-healthtech-background', 'The startup identified the fragmented, unreliable pharmaceutical supply chain as a critical bottleneck in healthcare delivery. Pharmacies routinely faced stockouts of essential medicines, while patients suffered from price gouging and counterfeit drugs.'),
  ('s4-healthtech-market-sizing', 'Ghana''s pharmaceutical market is heavily import-dependent, with out-of-pocket spending accounting for nearly 30% of total health expenditure. The B2B market for supplying private pharmacies and clinics presented a high-volume, recurring revenue opportunity.'),
  ('s4-healthtech-operational', 'The venture established a central, temperature-controlled warehouse in Tema and developed a proprietary inventory management system (IMS). They provided this software free to retail pharmacies in exchange for exclusive supply agreements, effectively becoming a tech-enabled distributor.'),
  ('s4-healthtech-competitive', 'The market was dominated by traditional, paper-based distributors with limited reach outside major cities. There was almost no tech-driven supply chain competition. Pharmacies were used to dealing with 10-15 different suppliers to maintain basic stock.'),
  ('s4-healthtech-pmf', 'The free software was a hard sell until they integrated an automated reordering feature that guaranteed 24-hour delivery in Accra and Kumasi. The breakthrough came when they added patient financing, allowing pharmacies to offer "buy now, pay later" for chronic disease medications.'),
  ('s4-healthtech-financial', 'Working capital was the primary constraint. Purchasing drugs in bulk from international manufacturers required USD, while pharmacy payments were in GHS and often delayed. They mitigated this by raising equity and securing a credit guarantee facility from a major DFI to manage FX exposure.'),
  ('s4-healthtech-roadmap', 'They launched in Accra by targeting medium-sized pharmacy chains rather than independent shops, securing higher volume faster. They leveraged the Ghana Pharmacy Council''s registry to map high-density areas and deployed a medical sales team to drive software adoption door-to-door.'),
  ('s4-edtech-background', 'Recognising the massive youth unemployment rate despite high tertiary enrollment, this venture built a vocational upskilling platform. The strategy was to bridge the gap between academic theory taught in universities and the practical digital skills demanded by employers.'),
  ('s4-edtech-market-sizing', 'With hundreds of thousands of graduates entering the workforce annually and facing an ~13% youth unemployment rate, the B2C demand for employability skills was high. More importantly, the B2B demand from corporations struggling to hire competent software developers and data analysts represented a lucrative revenue stream.'),
  ('s4-edtech-operational', 'They opted for a blended learning model, combining an online learning management system (LMS) with weekend in-person intensive workshops in Accra. They secured accreditation from the National Accreditation Board (NAB) to ensure their certificates held weight in the local job market.'),
  ('s4-edtech-competitive', 'Traditional universities were slow to update curricula. Existing tech training was largely limited to elite, expensive bootcamps (like MEST) or purely online global platforms (Coursera) which suffered from low completion rates without local context or community support.'),
  ('s4-edtech-pmf', 'Pure B2C sales struggled because the target demographic couldn''t afford upfront fees. PMF was achieved by shifting to an Income Share Agreement (ISA) model, where students learned for free and paid a percentage of their salary only after securing a tech job above a certain income threshold.'),
  ('s4-edtech-financial', 'The ISA model was highly capital intensive and risky due to the lack of a robust national credit scoring system. They mitigated this by partnering with major tech employers in Ghana to guarantee hiring pipelines, thus reducing the placement risk and ensuring cash flow.'),
  ('s4-edtech-roadmap', 'They ran a pilot cohort of 50 students, achieving a 90% placement rate within 3 months. They used these success stories heavily in social media marketing. Growth was then accelerated by partnering with university student representative councils (SRCs) to host coding bootcamps on campuses.'),

  -- Section 5
  ('s5-title', 'Funding Landscape'),
  ('s5-intro', 'A structured directory of capital allocators active in Ghana — from pan-African institutions to local Ghana-specific organisations. Each entry includes instrument type, typical ticket size, and a direct link to engage.'),

  -- Section 6
  ('s6-title', 'Operational Readiness Toolkit'),
  ('s6-intro', 'Essential operational contacts and a live tracker of market-specific red flags to monitor during your entry phase.'),
  ('s6-redflag-power', '<strong>Infrastructure (Dumsor risk)</strong>: Despite recent stabilisation, power generation capacity remains vulnerable to debt arrears. Frequent localized outages (Dumsor) can disrupt tech operations. Ensure backup power (UPS + generator) is provisioned for all critical physical infrastructure.'),
  ('s6-redflag-fx', '<strong>FX Pressure Points</strong>: While the Cedi has stabilized recently, structural vulnerabilities persist. Importers and tech companies with heavy USD-denominated server/SaaS costs must closely monitor BoG FX auction availability and maintain sufficient local currency reserves to weather sudden depreciation spikes.'),
  ('s6-redflag-data', '<strong>Data Protection Enforcement</strong>: The Data Protection Commission is aggressively increasing audits and penalties for non-compliance. Fintech and Healthtech startups must ensure strict data localization and privacy-by-design, treating GDPR compliance as the baseline.'),
  ('s6-redflag-political', '<strong>Political Risk (Electoral Cycle)</strong>: With the new administration settling in post-2024 elections, immediate political violence risk is low. However, watch for abrupt policy shifts or leadership changes in key regulatory bodies (BoG, FDA, NCA) which can delay pending licenses and approvals.')
on conflict (id) do nothing;


-- ═══════════════════════════════════════════════════════════════
-- UPGRADE: Supabase Auth + Role-Based Access Control
-- Run this block AFTER the initial schema above has been applied.
-- ═══════════════════════════════════════════════════════════════

-- Profiles table — one row per admin user, linked to auth.users
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  role text not null default 'admin' check (role in ('admin', 'super_admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

-- Admin users can read their own profile (needed for role-check after login)
drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
on public.profiles
for select
to authenticated
using (auth.uid() = id);

-- Auto-create a profile row whenever a new user is created in Supabase Auth
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer
set search_path = public
as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'admin')
  on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- ═══════════════════════════════════════════════════════════════
-- Auth-based RPCs — replace password-argument equivalents
-- These validate via auth.uid() matched against profiles table.
-- ═══════════════════════════════════════════════════════════════

create or replace function public.get_admin_submissions_auth()
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  is_admin boolean;
begin
  select exists(
    select 1 from public.profiles
    where id = auth.uid()
    and role in ('admin', 'super_admin')
  ) into is_admin;

  if not is_admin then
    raise exception 'Unauthorized: admin access required.';
  end if;

  return jsonb_build_object(
    'market_insights',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.market_insights t), '[]'::jsonb),
    'service_provider_ratings',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.service_provider_ratings t), '[]'::jsonb),
    'intro_requests',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.intro_requests t), '[]'::jsonb),
    'pack_ratings',
      coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.pack_ratings t), '[]'::jsonb)
  );
end;
$$;

revoke execute on function public.get_admin_submissions_auth() from public, anon;
grant execute on function public.get_admin_submissions_auth() to authenticated;

create or replace function public.update_pack_content_auth(
  content_id text,
  new_content text
)
returns void
language plpgsql
security definer
set search_path = public
as $$
declare
  is_admin boolean;
  editor_email text;
begin
  select exists(
    select 1 from public.profiles
    where id = auth.uid()
    and role in ('admin', 'super_admin')
  ) into is_admin;

  if not is_admin then
    raise exception 'Unauthorized: admin access required.';
  end if;

  select email from public.profiles where id = auth.uid() into editor_email;

  insert into public.pack_content (id, content, updated_at, updated_by)
  values (content_id, new_content, now(), editor_email)
  on conflict (id) do update
  set content     = excluded.content,
      updated_at  = excluded.updated_at,
      updated_by  = excluded.updated_by;
end;
$$;

revoke execute on function public.update_pack_content_auth(text, text) from public, anon;
grant execute on function public.update_pack_content_auth(text, text) to authenticated;

-- ═══════════════════════════════════════════════════════════════
-- Supabase Storage — Media bucket for image uploads
-- ═══════════════════════════════════════════════════════════════

-- Create the media bucket (public: images are readable by anyone with the URL)
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'media',
  'media',
  true,
  10485760,  -- 10 MB per file
  array['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']
)
on conflict (id) do nothing;

-- Authenticated admins can upload images
drop policy if exists "Admin upload to media" on storage.objects;
create policy "Admin upload to media"
on storage.objects
for insert
to authenticated
with check (bucket_id = 'media');

-- Authenticated admins can update/replace images
drop policy if exists "Admin update media" on storage.objects;
create policy "Admin update media"
on storage.objects
for update
to authenticated
using (bucket_id = 'media');

-- Authenticated admins can delete images
drop policy if exists "Admin delete media" on storage.objects;
create policy "Admin delete media"
on storage.objects
for delete
to authenticated
using (bucket_id = 'media');

-- Public (anon) can view/read all images in the media bucket
drop policy if exists "Public read media" on storage.objects;
create policy "Public read media"
on storage.objects
for select
to anon
using (bucket_id = 'media');
