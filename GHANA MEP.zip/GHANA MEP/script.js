const SUPABASE_URL = 'https://uauzozmlzgpgmurngqxu.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Octlx2Juh2XMWMVvCUTdJQ_GV9E8U89';

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const db = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

let currentRating = 0;
let packRating = 0;

function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(item => item.classList.remove('active'));

  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');

  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
}

function showSector(id) {
  const panel = document.getElementById('sector-' + id);
  const order = ['fintech', 'agritech', 'healthtech', 'edtech'];
  const idx = order.indexOf(id);
  const tabs = document.querySelectorAll('.sector-tab');
  if (!panel || idx < 0 || !tabs[idx]) return;

  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  tabs.forEach(t => t.classList.remove('active'));
  panel.classList.add('active');
  tabs[idx].classList.add('active');
}

function setRating(n) {
  currentRating = n;
  document.querySelectorAll('#stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });
}

async function setPackRating(n) {
  packRating = n;
  document.querySelectorAll('#pack-stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });

  const result = await insertRow('pack_ratings', {
    rating: packRating,
    page_url: window.location.href,
    user_agent: navigator.userAgent
  });

  if (result.ok) {
    showThanks('pack-rating-thanks');
  } else {
    showFormMessage('pack-stars', result.message, 'error');
  }
}

function getValue(id) {
  return document.getElementById(id)?.value.trim() || '';
}

function showThanks(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'block';
}

function setBusy(button, isBusy) {
  if (!button) return;
  button.disabled = isBusy;
  button.dataset.originalText ||= button.textContent;
  button.textContent = isBusy ? 'Submitting' : button.dataset.originalText;
  button.classList.toggle('btn-loading', isBusy);
  button.setAttribute('aria-label', isBusy ? 'Submitting…' : button.dataset.originalText);
}

function showFormMessage(anchorId, message, type = 'error') {
  const anchor = document.getElementById(anchorId);
  if (!anchor) return;

  const existing = anchor.parentElement.querySelector('.form-message');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = `form-message ${type}`;
  note.textContent = message;
  anchor.insertAdjacentElement('afterend', note);
}

function clearFormMessage(anchorId) {
  const anchor = document.getElementById(anchorId);
  const existing = anchor?.parentElement.querySelector('.form-message');
  if (existing) existing.remove();
}

function showTemporaryFormError(button, message) {
  if (!button?.parentElement) return;

  const existing = button.parentElement.querySelector('.form-error');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = 'form-error';
  note.textContent = message;
  button.insertAdjacentElement('afterend', note);

  window.setTimeout(() => {
    if (note.isConnected) note.remove();
  }, 5000);
}

async function insertRow(table, payload) {
  if (!db) {
    return {
      ok: false,
      message: 'Supabase is not configured yet. Add your project URL and anon key in script.js.'
    };
  }

  const { error } = await db.from(table).insert(payload);
  if (error) {
    const rawMessage = error.message || 'Submission failed. Please try again.';
    if (rawMessage.includes(`Could not find the table 'public.${table}'`)) {
      return {
        ok: false,
        message: 'This form backend is not live yet. The Supabase schema still needs to be run for this project.'
      };
    }

    return { ok: false, message: error.message || 'Submission failed. Please try again.' };
  }

  return { ok: true };
}

async function submitInsight(event) {
  const button = event?.currentTarget;
  const text = getValue('insight-text');
  clearFormMessage('insight-form');

  if (!text) {
    showFormMessage('insight-form', 'Please add your insight before submitting.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('market_insights', {
      sector: getValue('insight-sector') || null,
      insight_text: text,
      contributor_name: getValue('insight-name') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    document.getElementById('insight-form').style.display = 'none';
    showThanks('insight-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitRating(event) {
  const button = event?.currentTarget;
  const agencyName = getValue('agency-name');
  clearFormMessage('rating-form');

  if (!agencyName || currentRating === 0) {
    showFormMessage('rating-form', 'Please add a provider name and choose a star rating.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('service_provider_ratings', {
      provider_name: agencyName,
      rating: currentRating,
      comment: getValue('agency-comment') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    document.getElementById('rating-form').style.display = 'none';
    showThanks('rating-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitIntro(event) {
  const button = event?.currentTarget;
  const lookingFor = getValue('intro-looking');
  const context = getValue('intro-context');
  const email = getValue('intro-email');
  clearFormMessage('intro-form');

  if (!lookingFor || !context || !email) {
    showFormMessage('intro-form', 'Please fill out all intro request fields.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('intro_requests', {
      looking_for: lookingFor,
      company_context: context,
      email,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    document.getElementById('intro-form').style.display = 'none';
    showThanks('intro-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

function bindInteractions() {
  document.querySelectorAll('[data-panel]').forEach(button => {
    if (button.classList.contains('bookmark-btn')) return;
    button.addEventListener('click', () => showPanel(button.dataset.panel));
  });

  document.querySelectorAll('.bookmark-btn').forEach(button => {
    button.addEventListener('click', () => setBookmark(button.dataset.panel));
  });

  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });

  document.querySelectorAll('[data-rating]').forEach(star => {
    star.addEventListener('click', () => setRating(Number(star.dataset.rating)));
  });

  document.querySelectorAll('[data-pack-rating]').forEach(star => {
    star.addEventListener('click', () => setPackRating(Number(star.dataset.packRating)));
  });

  document.querySelector('[data-action="submit-insight"]')?.addEventListener('click', submitInsight);
  document.querySelector('[data-action="submit-rating"]')?.addEventListener('click', submitRating);
  document.querySelector('[data-action="submit-intro"]')?.addEventListener('click', submitIntro);
}

document.addEventListener('DOMContentLoaded', () => {
  bindInteractions();
  loadPackContent().finally(initFeatures);

  // Sticky nav shadow on scroll
  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }
});

/**
 * Load editable content from the pack_content table (anon SELECT).
 * Falls back to hardcoded HTML if Supabase is not configured or the table is empty.
 */
async function loadPackContent() {
  if (!db) return;

  try {
    const { data, error } = await db.from('pack_content').select('id, content');
    if (error || !data || data.length === 0) return;

    for (const row of data) {
      const els = document.querySelectorAll(`[data-content-id="${row.id}"]`);
      if (!els.length) continue;

      // Auto-detect HTML: if stored content starts with an HTML tag, render
      // as innerHTML (supports rich text written via the Quill editor in admin).
      // All other values are set as textContent for safety.
      const isHtml = /^\s*</.test(row.content);
      for (const el of els) {
        if (isHtml) {
          el.innerHTML = row.content;
          // Ensure all embedded links open in new tab
          el.querySelectorAll('a').forEach(a => {
            if (!a.getAttribute('target')) a.setAttribute('target', '_blank');
            a.setAttribute('rel', 'noopener noreferrer');
          });
        } else {
          el.textContent = row.content;
        }
      }
    }
  } catch {
    // Supabase not available or table doesn't exist — keep hardcoded content
  }
}

// ── FEATURE ADDITIONS ──

const SECTION_ORDER = ['front', 's1', 's2', 's3', 's4', 's5', 'feedback', 'glossary'];
const ACRONYMS = {
  GIPA: 'Ghana Investment Promotion Agency',
  GIPC: 'Ghana Investment Promotion Centre',
  GhIPSS: 'Ghana Interbank Payment and Settlement Systems',
  AfCFTA: 'African Continental Free Trade Area',
  ECOWAS: 'Economic Community of West African States',
  SSNIT: 'Social Security and National Insurance Trust',
  NCA: 'National Communications Authority',
  TIN: 'Tax Identification Number',
  DFI: 'Development Finance Institution',
  ISA: 'Income Share Agreement',
  BoG: 'Bank of Ghana',
  GRA: 'Ghana Revenue Authority',
  FDA: 'Food and Drugs Authority',
  ORC: 'Office of the Registrar of Companies',
  PECAN: 'Public Enterprises and Consumer Affairs Network',
  NHIS: 'National Health Insurance Scheme',
  NDC: 'National Democratic Congress',
  NPP: 'New Patriotic Party',
  MEST: 'Meltwater Entrepreneurial School of Technology',
  NAB: 'National Accreditation Board',
  SRC: 'Students Representative Council',
  PSP: 'Payment Service Provider',
  DEMI: 'Digital Economy and Market Innovations',
  AML: 'Anti-Money Laundering',
  KYC: 'Know Your Customer',
  ESG: 'Environmental, Social, and Governance',
  CSR: 'Corporate Social Responsibility',
  LMS: 'Learning Management System',
  IPP: 'Independent Power Producer',
  VAT: 'Value Added Tax'
};

let visitedSections = new Set();
let bookmarkedSection = null;
let darkModeEnabled = false;
let tooltipEl = null;

const initialDarkMode = localStorage.getItem('mep-darkmode') === '1';
if (initialDarkMode) {
  document.body.classList.add('dark');
  darkModeEnabled = true;
}

function persistVisited() {
  localStorage.setItem('mep-visited', JSON.stringify([...visitedSections]));
}

function hydrateVisited() {
  const raw = localStorage.getItem('mep-visited');
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (Array.isArray(list)) {
      visitedSections = new Set(list);
      updateVisitedChecks();
    }
  } catch {
    visitedSections = new Set();
  }
}

function updateVisitedChecks() {
  visitedSections.forEach(id => {
    const button = document.querySelector(`.nav-btn[data-panel="${id}"]`);
    if (!button || button.querySelector('.nav-check')) return;
    const mark = document.createElement('span');
    mark.className = 'nav-check';
    mark.textContent = '✓';
    button.appendChild(mark);
  });
}

function markVisited(id) {
  if (visitedSections.has(id)) return;
  visitedSections.add(id);
  persistVisited();
  updateVisitedChecks();
}

function updateProgressBar(index) {
  const fill = document.querySelector('.pack-progress-fill');
  if (!fill) return;
  fill.style.width = `${Math.round(((index + 1) / SECTION_ORDER.length) * 100)}%`;
}

function hydrateBookmark() {
  const raw = localStorage.getItem('mep-bookmark');
  bookmarkedSection = raw || null;
  updateBookmarkIndicators();
}

function updateBookmarkIndicators() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const isBookmarked = btn.dataset.panel === bookmarkedSection;
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (isBookmarked) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.title = 'Bookmarked';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else if (indicator) {
      indicator.remove();
    }
  });

  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.style.opacity = btn.dataset.panel === bookmarkedSection ? '1' : '0.35';
  });
}

function setBookmark(panelId) {
  if (panelId === bookmarkedSection) {
    bookmarkedSection = null;
    localStorage.removeItem('mep-bookmark');
  } else {
    bookmarkedSection = panelId;
    localStorage.setItem('mep-bookmark', panelId);
  }
  updateBookmarkIndicators();
}

function initFeatures() {
  hydrateVisited();
  hydrateBookmark();
  hydrateDarkMode();
  initializeProseCards();
  wrapAcronyms();
  createTooltip();
  document.getElementById('pack-search')?.addEventListener('input', onSearchInput);
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);

  document.querySelector('.pack-root')?.addEventListener('click', event => {
    const proseToggle = event.target.closest('.prose-toggle');
    if (proseToggle) {
      event.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;

      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
      return;
    }

    const fundingToggle = event.target.closest('.funding-toggle');
    if (fundingToggle) {
      event.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;

      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
    }
  });

  if (bookmarkedSection) {
    showPanel(bookmarkedSection);
  } else {
    const current = document.querySelector('.nav-btn.active')?.dataset.panel || SECTION_ORDER[0];
    showPanel(current);
  }
}

function hydrateDarkMode() {
  darkModeEnabled = localStorage.getItem('mep-darkmode') === '1';
  document.body.classList.toggle('dark', darkModeEnabled);
  updateDarkToggleLabel();
}

function updateDarkToggleLabel() {
  const button = document.getElementById('darkmode-toggle');
  if (!button) return;
  button.textContent = darkModeEnabled ? '☀️' : '🌙';
}

function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode', darkModeEnabled ? '1' : '0');
  updateDarkToggleLabel();
}

function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  window.setTimeout(() => {
    document.body.classList.remove('print-mode');
  }, 100);
}

function onSearchInput(event) {
  const query = event.target.value.trim();
  clearSearchHighlights();
  if (!query) return;
  highlightSearch(query);
}

function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, .pack-progress-bar, .mep-tooltip')) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;

    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  }

  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) {
      const panelId = panel.id.replace('panel-', '');
      showPanel(panelId);
    }
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
}

function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.createElement('div');
  tooltipEl.id = 'mep-tooltip';
  tooltipEl.className = 'mep-tooltip';
  document.body.appendChild(tooltipEl);
  document.querySelector('.pack-root')?.addEventListener('pointerover', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('pointerout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
  document.querySelector('.pack-root')?.addEventListener('focusin', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('focusout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
}

function showTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || target.title || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 240, Math.max(8, rect.left));
  const top = rect.bottom + 10;
  tooltipEl.style.top = `${top}px`;
  tooltipEl.style.left = `${left}px`;
}

function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, script, .mep-abbr, .search-highlight')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    if (!acronymRegex.test(text)) continue;
    replacements.push(node);
  }

  replacements.forEach(node => {
    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    acronymRegex.lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.title = ACRONYMS[match[0]] || '';
      abbr.tabIndex = 0;
      abbr.textContent = match[0];
      fragment.appendChild(abbr);
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  });
}

function hideTooltip() {
  if (!tooltipEl) return;
  tooltipEl.style.opacity = '0';
}

/* ═══════════════════════════════════════════════════════════════
   TASK 2 — HOW-CARD NAVIGATION
   ═══════════════════════════════════════════════════════════════ */
function bindHowCards() {
  document.querySelectorAll('.how-card-link').forEach(card => {
    const handler = () => {
      const panel = card.dataset.navPanel;
      if (!panel) return;
      showPanel(panel);
      // Scroll to anchor if specified
      const anchor = card.dataset.navAnchor;
      if (anchor) {
        setTimeout(() => {
          const el = document.getElementById(anchor);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); }
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   TASK 7 — INTERACTIVE SCORECARD
   ═══════════════════════════════════════════════════════════════ */
const SCORECARD_DIMENSIONS = [
  {
    id: 'political',
    name: 'Political & Macroeconomic Stability',
    section: 'Market Conditions',
    baseContext: 'Ghana has had 9 consecutive peaceful elections. Post-2022 debt crisis recovery has exceeded expectations — inflation down to 3.3%, cedi appreciated ~40%. IMF programme on track.',
    contextFn: (sector, talent, stage) => null // use base
  },
  {
    id: 'regulatory',
    name: 'Regulatory Ease',
    section: 'Market Conditions',
    baseContext: 'General regulatory environment: GIPA registration is streamlined; major complexity is in licensed sectors.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: BoG licensing takes 6–18 months. Sandbox pathway available — recommended for novel models. Moderate-to-high regulatory burden.',
        agritech: 'Agritech: MoFA and EPA approvals required for scale ops. COCOBOD mandatory for cocoa plays. Land tenure complexity is a major watchpoint.',
        healthtech: 'Healthtech: FDA device registration can take 3–12 months. NHIA accreditation is a significant milestone. GHS partnership needed for public-sector plays.',
        edtech: 'Edtech: Lightest regulatory burden — no specific digital education regulation. GES approval needed only if selling curricula to public schools.',
        other: 'Cross-sector: varies by activity. GIPA registration is the universal starting point.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'market_size',
    name: 'Market Size & Growth Trajectory',
    section: 'Market Conditions',
    baseContext: 'Population: 34M, 56% under 25. GDP $100B+, growing at 5.1% (2026F). Rising middle class and rapidly digitising economy.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: $50B+ annual mobile money volume. 40% of adults still unbanked. SME credit penetration below 10% — large structural gap.',
        agritech: 'Agritech: ~20% of GDP from agriculture. 40% of workforce in ag. Cocoa exports ~$3B/yr. Post-harvest losses 25–40%.',
        healthtech: 'Healthtech: 0.14 doctors per 1,000. NHIS covers ~35%. ~30% out-of-pocket health spend. 80+ active healthtech cos.',
        edtech: 'Edtech: ~8M K–12 students. Tertiary enrolment at 18% and rising. World Bank $300M education project FY26.',
        other: 'Cross-sector: broad market opportunity driven by young demographics and digital adoption.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'digital_infra',
    name: 'Digital Infrastructure',
    section: 'Operational Readiness',
    baseContext: '4G across major cities. GhIPSS real-time interoperability. Ghana Card digital ID. Broadband penetration ~55–60%.',
    contextFn: null
  },
  {
    id: 'talent',
    name: 'Talent Availability',
    section: 'Operational Readiness',
    baseContext: 'English-speaking workforce with strong diaspora connections. MEST Africa and university system producing talent.',
    contextFn: (sector, talent) => {
      const map = {
        tech: 'Tech/Engineering: Good depth in Accra. Full-stack devs available but competitive. MEST Africa and Ashesi University are key pipelines. Remote hiring common.',
        commercial: 'Commercial/Sales: Strong commercial talent in Accra. B2B sales culture exists but needs local relationship-building. Sales cycles are longer than Western markets.',
        finance: 'Finance/Legal: Strong Big 4 presence. GIPA/GIPC-experienced lawyers available at Reindorf Chambers, AB & David. Corporate finance talent concentrated in Accra.',
        agri: 'Agricultural/Field: Strong field extension worker base. MoFA and COCOBOD have large networks. Agronomy graduates from KNUST available.',
        health: 'Healthcare/Clinical: Severe doctor shortage (0.14/1,000). Nurses and CHWs more accessible. Clinical talent retention is a significant challenge.'
      };
      return map[talent] || null;
    }
  },
  {
    id: 'capital',
    name: 'Capital Access',
    section: 'Funding & Growth',
    baseContext: 'Ecosystem includes GAIN angels, MEST, GreenHouse Capital, IFC, AfDB, BII, DBG. High domestic interest rates (25%+) make local debt expensive.',
    contextFn: (sector, talent, stage) => {
      const map = {
        explore: 'Exploring: GAIN, MEST, and Voltron Capital most accessible. Focus on grant-based options (UNICEF, GIZ) to reduce equity dilution at validation stage.',
        pilot: 'Piloting: GreenHouse Capital, Ventures Platform, and Founders Factory Africa are primary targets. Warm intros critical. Plan for 4–9 month fundraise timeline.',
        scale: 'Scaling: IFC Accra office, BII, Proparco, DBG are the primary channels. DFI capital is patient and impact-aligned — requires strong metrics and ESG narrative.'
      };
      return map[stage] || null;
    }
  },
  {
    id: 'afcfta',
    name: 'AfCFTA & Regional Gateway Potential',
    section: 'Strategic Upside',
    baseContext: 'AfCFTA Secretariat headquartered in Accra — unique structural advantage. ECOWAS protocol enables regional expansion. Anglophone bridge in Francophone West Africa.',
    contextFn: null
  },
  {
    id: 'execution_risk',
    name: 'Execution Risk (lower = better score)',
    section: 'Risk Assessment',
    baseContext: 'Key risks: sector licensing delays, informal sector complexity, commercial dispute resolution slowness, FX stress scenarios, ESG compliance obligations.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech execution risk: HIGH. BoG licensing backlog, fraud exposure, competitive MNO layer. Recommend sandbox entry and 12-month legal runway.',
        agritech: 'Agritech execution risk: HIGH. Land tenure complexity, COCOBOD gatekeeping, rural last-mile logistics, and climate variability are compounding risks.',
        healthtech: 'Healthtech execution risk: HIGH. FDA registration delays, NHIS integration complexity, and trust-building with Ghana Health Service take 12–24 months.',
        edtech: 'Edtech execution risk: MEDIUM. Lighter regulatory burden but price sensitivity is extreme. B2B routes to market more reliable than B2C at scale.',
        other: 'Execution risk: variable. General risks include court enforcement speed, informal sector navigation, and cultural relationship requirements.'
      };
      return map[sector] || null;
    }
  }
];

const scorecardState = {};

function getScorecardContextText(dim, sector, talent, stage) {
  if (dim.contextFn) {
    const ctx = dim.contextFn(sector, talent, stage);
    if (ctx) return ctx;
  }
  return dim.baseContext;
}

function getScoreClass(score) {
  if (score === 0) return '';
  if (score >= 7) return 'score-high';
  if (score >= 5) return 'score-mid';
  return 'score-low';
}

function calcTotal() {
  const ids = SCORECARD_DIMENSIONS.map(d => d.id);
  const scored = ids.filter(id => scorecardState[id] != null);
  if (scored.length === 0) return null;
  const sum = scored.reduce((acc, id) => acc + scorecardState[id], 0);
  return (sum / scored.length).toFixed(1);
}

function updateScorecardResult() {
  const total = calcTotal();
  const scoreEl = document.getElementById('sc-total-score');
  const labelEl = document.getElementById('sc-result-label');
  const signalEl = document.getElementById('sc-result-signal');
  if (!scoreEl || !labelEl || !signalEl) return;

  if (total === null) {
    scoreEl.textContent = '—';
    labelEl.textContent = 'Rate each dimension to generate your entry signal.';
    signalEl.textContent = '';
    signalEl.className = 'scorecard-result-signal';
    return;
  }

  const t = parseFloat(total);
  scoreEl.textContent = `${total}/10`;

  if (t >= 7) {
    labelEl.textContent = 'Strong entry window for your profile. Key risks are manageable with proper local anchoring and capital planning.';
    signalEl.textContent = 'Strong Entry Window';
    signalEl.className = 'scorecard-result-signal signal-strong';
  } else if (t >= 5) {
    labelEl.textContent = 'Promising but context-dependent. Address your red-flag dimensions before committing capital.';
    signalEl.textContent = 'Promising — Address Red Flags';
    signalEl.className = 'scorecard-result-signal signal-promising';
  } else {
    labelEl.textContent = 'Significant barriers identified. Revisit entry timing or strategy, or de-risk the lowest-scoring dimensions first.';
    signalEl.textContent = 'Caution — Revisit Strategy';
    signalEl.className = 'scorecard-result-signal signal-caution';
  }
}

function renderScorecardRows() {
  const container = document.getElementById('scorecard-rows');
  if (!container) return;
  const sector = document.getElementById('sc-sector')?.value || 'other';
  const talent = document.getElementById('sc-talent')?.value || 'tech';
  const stage = document.getElementById('sc-stage')?.value || 'explore';

  let html = '';
  let lastSection = '';

  for (const dim of SCORECARD_DIMENSIONS) {
    if (dim.section !== lastSection) {
      html += `<div class="scorecard-section-heading">${dim.section}</div>`;
      lastSection = dim.section;
    }
    const score = scorecardState[dim.id] || 0;
    const scoreClass = getScoreClass(score);
    const ctx = getScorecardContextText(dim, sector, talent, stage);
    const valDisplay = score === 0 ? '—' : `${score}/10`;

    html += `
      <div class="scorecard-dim" id="sc-dim-${dim.id}">
        <div class="scorecard-dim-header">
          <div class="scorecard-dim-name">${dim.name}</div>
          <div class="scorecard-dim-val ${scoreClass} ${score > 0 ? 'scored' : ''}" id="sc-val-${dim.id}">${valDisplay}</div>
        </div>
        <div class="scorecard-dim-context">${ctx}</div>
        <div class="scorecard-slider-wrap">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">0</span>
          <input type="range" class="scorecard-slider" id="sc-slider-${dim.id}"
            min="0" max="10" step="0.5" value="${score}"
            data-dim-id="${dim.id}" aria-label="${dim.name} score">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">10</span>
        </div>
      </div>`;
  }

  container.innerHTML = html;

  // Bind slider events
  container.querySelectorAll('.scorecard-slider').forEach(slider => {
    slider.addEventListener('input', () => {
      const id = slider.dataset.dimId;
      const val = parseFloat(slider.value);
      scorecardState[id] = val;
      const valEl = document.getElementById(`sc-val-${id}`);
      if (valEl) {
        valEl.textContent = val === 0 ? '—' : `${val}/10`;
        valEl.className = `scorecard-dim-val ${val > 0 ? 'scored' : ''} ${getScoreClass(val)}`;
      }
      updateScorecardResult();
    });
  });
}

function initInteractiveScorecard() {
  const container = document.getElementById('interactive-scorecard');
  if (!container) return;

  renderScorecardRows();
  updateScorecardResult();

  // Context selectors trigger re-render of context text
  ['sc-sector', 'sc-talent', 'sc-stage'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => {
      renderScorecardRows();
    });
  });

  // Reset button
  document.getElementById('sc-reset-btn')?.addEventListener('click', () => {
    SCORECARD_DIMENSIONS.forEach(d => { scorecardState[d.id] = 0; });
    renderScorecardRows();
    updateScorecardResult();
  });
}

// Patch initFeatures to include how-card binding + scorecard init
const _origInitFeatures = initFeatures;
// Override to add new features
document.addEventListener('DOMContentLoaded', () => {
  bindHowCards();
  // Scorecard init after content loaded
  setTimeout(initInteractiveScorecard, 300);
});

/* ═══════════════════════════════════════════════════════════════
   MONOCLE 2026 — FEATURE ADDITIONS
   Appended below original handlers — nothing above is modified.
   ═══════════════════════════════════════════════════════════════ */

// ── 1. STICKY NAV SCROLL STATE ──
// (already handled in original DOMContentLoaded block above)

// ── 2. DARK MODE ──
// Already implemented above as hydrateDarkMode / toggleDarkMode.
// Patch: ensure dark toggle button is wired even if initFeatures
// runs before the button is in the DOM.
document.addEventListener('DOMContentLoaded', () => {
  const toggleBtn = document.getElementById('darkmode-toggle');
  if (toggleBtn && !toggleBtn.__monocleWired) {
    toggleBtn.__monocleWired = true;
    toggleBtn.addEventListener('click', () => {
      if (typeof toggleDarkMode === 'function') toggleDarkMode();
    });
    if (typeof updateDarkToggleLabel === 'function') updateDarkToggleLabel();
  }
});

// ── 3. READING PROGRESS BAR ──
// Already wired through updateProgressBar called inside showPanel.

// ── 4. PRINT TRIGGER ──
// Already implemented above as triggerPrint.

// ── 5. VISITED / BOOKMARK STATE ──
// Already implemented above.

// ── 6. SEARCH ──
// Already implemented above (onSearchInput / highlightSearch).

// ── 7. ACRONYM TOOLTIPS ──
// Already implemented above (wrapAcronyms / createTooltip).

// ── 8. PROSE + FUNDING ACCORDIONS ──
// Already implemented above (initializeProseCards + delegated click).

// ── 9. SMOOTH SCROLL TO TOP ON PANEL CHANGE ──
// Patch showPanel to also smooth-scroll to top of content.
(function patchShowPanelScroll() {
  const _orig = window.showPanel;
  if (!_orig) return;
  window.showPanel = function(id) {
    _orig(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
})();

// ── 10. STAGGERED CARD ENTRANCE ANIMATION TRIGGER ──
// Ensures CSS animation re-triggers on panel switch by
// force-reflowing newly active panels.
(function patchShowPanelReflow() {
  const _prev = window.showPanel;
  if (!_prev) return;
  window.showPanel = function(id) {
    _prev(id);
    const panel = document.getElementById('panel-' + id);
    if (panel) {
      // Force reflow so CSS animations replay
      panel.querySelectorAll('.stat-card, .how-card, .how-card-link').forEach(el => {
        el.style.animation = 'none';
        void el.offsetHeight; // trigger reflow
        el.style.animation = '';
      });
    }
  };
})();

// ── 11. DYNAMIC DARKMODE TOGGLE LABEL ON LOAD ──
(function initDarkLabelOnLoad() {
  const apply = () => {
    const btn = document.getElementById('darkmode-toggle');
    if (!btn) return;
    const isDark = document.body.classList.contains('dark');
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }
})();

// ── 12. FUNDING SECTION ACCORDION — ensure default open ──
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    // Default: expanded
    if (!btn.hasAttribute('aria-expanded')) {
      btn.setAttribute('aria-expanded', 'true');
    }
    if (btn.getAttribute('aria-expanded') === 'true') {
      body.style.maxHeight = body.scrollHeight + 'px';
    } else {
      body.style.maxHeight = '0';
    }
  });
});
