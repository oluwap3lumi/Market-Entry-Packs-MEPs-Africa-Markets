const SUPABASE_URL = 'https://uauzozmlzgpgmurngqxu.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Octlx2Juh2XMWMVvCUTdJQ_GV9E8U89';
const POLL_INTERVAL_MS = 15000;

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const adminDb = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

let submissions = [];
let pollTimer = null;

const tableLabels = {
  market_insights: 'Insight',
  service_provider_ratings: 'Provider rating',
  intro_requests: 'Intro request',
  pack_ratings: 'Pack rating'
};

function $(id) {
  return document.getElementById(id);
}

function setStatus(message, isError = false) {
  const status = $('admin-status') || $('login-error');
  if (!status) return;
  status.hidden = false;
  status.textContent = message;
  status.classList.toggle('error', isError);
}

function normalizeRows(data) {
  return [
    ...(data.market_insights || []).map(row => ({ type: 'market_insights', ...row })),
    ...(data.service_provider_ratings || []).map(row => ({ type: 'service_provider_ratings', ...row })),
    ...(data.intro_requests || []).map(row => ({ type: 'intro_requests', ...row })),
    ...(data.pack_ratings || []).map(row => ({ type: 'pack_ratings', ...row }))
  ].sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
}

async function fetchSubmissions() {
  if (!adminDb) {
    throw new Error('Supabase is not configured yet. Add your project URL and anon key in admin.js.');
  }

  // Uses auth-based RPC — no password argument needed; JWT from session is used
  const { data, error } = await adminDb.rpc('get_admin_submissions_auth');

  if (error) throw error;
  submissions = normalizeRows(data || {});
  renderDashboard();
  setStatus(`Last synced ${new Date().toLocaleTimeString()}. Auto-refreshing every 15 seconds.`);
}

function renderCounts() {
  $('count-insights').textContent = submissions.filter(row => row.type === 'market_insights').length;
  $('count-ratings').textContent = submissions.filter(row => row.type === 'service_provider_ratings').length;
  $('count-intros').textContent = submissions.filter(row => row.type === 'intro_requests').length;
  $('count-pack-ratings').textContent = submissions.filter(row => row.type === 'pack_ratings').length;
}

function searchableText(row) {
  return [
    row.sector,
    row.insight_text,
    row.contributor_name,
    row.provider_name,
    row.comment,
    row.looking_for,
    row.company_context,
    row.email,
    row.status,
    row.internal_notes
  ].filter(Boolean).join(' ').toLowerCase();
}

function filteredRows() {
  const type = $('type-filter').value;
  const rating = $('rating-filter').value;
  const query = $('search-filter').value.trim().toLowerCase();

  return submissions.filter(row => {
    if (type !== 'all' && row.type !== type) return false;
    if (rating !== 'all' && String(row.rating || '') !== rating) return false;
    if (query && !searchableText(row).includes(query)) return false;
    return true;
  });
}

function primaryText(row) {
  if (row.type === 'market_insights') return row.contributor_name || 'Anonymous insight';
  if (row.type === 'service_provider_ratings') return row.provider_name;
  if (row.type === 'intro_requests') return row.email;
  return 'Overall pack rating';
}

function detailText(row) {
  if (row.type === 'market_insights') return `${row.sector || 'General'}: ${row.insight_text}`;
  if (row.type === 'service_provider_ratings') return row.comment || 'No comment provided.';
  if (row.type === 'intro_requests') return `${row.looking_for} — ${row.company_context}`;
  return row.page_url || 'No page URL captured.';
}

function escapeHtml(value) {
  return String(value ?? '').replace(/[&<>"']/g, char => ({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&#39;'
  }[char]));
}

function renderRows() {
  const rows = filteredRows();
  const body = $('submission-rows');

  if (!rows.length) {
    body.innerHTML = '<tr><td colspan="5">No submissions match the current filters.</td></tr>';
    return;
  }

  body.innerHTML = rows.map(row => `
    <tr>
      <td>
        ${escapeHtml(new Date(row.created_at).toLocaleString())}
        <div class="admin-muted">${escapeHtml(row.id)}</div>
      </td>
      <td><span class="admin-type ${escapeHtml(row.type)}">${escapeHtml(tableLabels[row.type])}</span></td>
      <td>${escapeHtml(primaryText(row))}</td>
      <td>${escapeHtml(detailText(row))}</td>
      <td>${row.rating ? `${escapeHtml(row.rating)} / 5` : '<span class="admin-muted">N/A</span>'}</td>
    </tr>
  `).join('');
}

function renderDashboard() {
  renderCounts();
  renderRows();
}

function downloadCsv() {
  const rows = filteredRows();
  const headers = ['created_at', 'type', 'primary', 'details', 'rating', 'email', 'sector', 'status', 'id'];
  const csvRows = [
    headers.join(','),
    ...rows.map(row => [
      row.created_at,
      tableLabels[row.type],
      primaryText(row),
      detailText(row),
      row.rating || '',
      row.email || '',
      row.sector || '',
      row.status || '',
      row.id
    ].map(csvCell).join(','))
  ];

  const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8' });
  const link = document.createElement('a');
  link.href = URL.createObjectURL(blob);
  link.download = `ghana-pack-submissions-${new Date().toISOString().slice(0, 10)}.csv`;
  link.click();
  URL.revokeObjectURL(link.href);
}

function csvCell(value) {
  return `"${String(value ?? '').replace(/"/g, '""')}"`;
}

/* =================================================================
   AUTHENTICATION — Supabase Auth (email + password)
   ================================================================= */

async function checkSession() {
  if (!adminDb) return;
  const { data: { session } } = await adminDb.auth.getSession();
  if (session) {
    await showDashboard();
  }
}

async function signIn() {
  const email = $('admin-email').value.trim();
  const password = $('admin-password').value;
  const errorEl = $('login-error');
  errorEl.hidden = true;

  if (!email || !password) {
    errorEl.hidden = false;
    errorEl.textContent = 'Please enter your email and password.';
    return;
  }

  const btn = $('login-button');
  btn.disabled = true;
  btn.textContent = 'Signing in…';

  try {
    const { data, error } = await adminDb.auth.signInWithPassword({ email, password });

    if (error) {
      errorEl.hidden = false;
      errorEl.textContent = error.message || 'Sign-in failed. Check your credentials.';
      return;
    }

    // Verify the user has an admin profile
    const { data: profile, error: profileError } = await adminDb
      .from('profiles')
      .select('role')
      .eq('id', data.user.id)
      .single();

    if (profileError || !profile || !['admin', 'super_admin'].includes(profile.role)) {
      await adminDb.auth.signOut();
      errorEl.hidden = false;
      errorEl.textContent = 'Your account does not have admin access. Contact the system owner.';
      return;
    }

    await showDashboard();
  } catch (err) {
    errorEl.hidden = false;
    errorEl.textContent = err.message || 'An unexpected error occurred.';
  } finally {
    btn.disabled = false;
    btn.textContent = 'Sign in';
  }
}

async function showDashboard() {
  $('login-view').hidden = true;
  $('dashboard-view').hidden = false;
  await fetchSubmissions().catch(err => setStatus(err.message, true));
  startPolling();
}

async function signOut() {
  clearInterval(pollTimer);
  contentLoaded = false;
  quillInstances = {};
  submissions = [];

  if (adminDb) await adminDb.auth.signOut();

  $('admin-email').value = '';
  $('admin-password').value = '';
  $('dashboard-view').hidden = true;
  $('login-view').hidden = false;

  // Switch back to submissions tab for next login
  switchAdminTab('submissions');
}

function startPolling() {
  clearInterval(pollTimer);
  pollTimer = setInterval(() => {
    fetchSubmissions().catch(error => setStatus(error.message, true));
  }, POLL_INTERVAL_MS);
}

/* =================================================================
   TAB SWITCHING
   ================================================================= */

function switchAdminTab(tabName) {
  document.querySelectorAll('.admin-tab').forEach(t => {
    t.classList.toggle('active', t.dataset.adminTab === tabName);
  });
  document.querySelectorAll('.admin-tab-panel').forEach(p => {
    p.classList.toggle('active', p.id === `tab-${tabName}`);
  });

  if (tabName === 'content' && !contentLoaded) {
    loadContentEditor();
  }
}

/* =================================================================
   EDIT CONTENT TAB — with Quill rich text + image upload
   ================================================================= */

let contentLoaded = false;
let savedContent = {};
let pendingEdits = {};
let quillInstances = {};

const sectionLabels = {
  front: 'Front Matter',
  s1: 'Section 1 — Country Overview',
  s2: 'Section 2 — Entry Framework',
  s3: 'Section 3 — Sector Deep Dives',
  s4: 'Section 4 — Case Studies (in Sector Deep Dives)',
  s5: 'Section 4 — Funding Landscape',
  s6: 'Section 5 — Directory',
  feedback: 'Feedback & Community'
};

function deriveSection(id) {
  const prefix = id.split('-')[0];
  return sectionLabels[prefix] || prefix;
}

function humanLabel(id) {
  return id.replace(/-/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
}

function getDirtyCount() {
  return Object.keys(pendingEdits).length;
}

function updateSaveBar() {
  const count = getDirtyCount();
  const saveBtn = $('content-save-btn');
  const discardBtn = $('content-discard-btn');
  const badge = $('content-dirty-badge');

  if (saveBtn) {
    saveBtn.disabled = count === 0;
    saveBtn.textContent = count > 0 ? `Save ${count} change${count > 1 ? 's' : ''}` : 'Save changes';
  }
  if (discardBtn) discardBtn.disabled = count === 0;
  if (badge) {
    badge.textContent = count;
    badge.hidden = count === 0;
  }
}

/**
 * Determines whether a content field should use the Quill rich text editor.
 * Rich fields: those containing HTML tags, line breaks, or prose over 100 chars.
 */
function isRichField(content) {
  return content.includes('<') || content.includes('\n') || content.length > 100;
}

/**
 * Handles image upload to Supabase Storage when the Quill image button is clicked.
 */
function makeImageHandler(quill, contentId) {
  return function () {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/jpeg,image/png,image/gif,image/webp,image/svg+xml';
    input.click();

    input.onchange = async () => {
      const file = input.files[0];
      if (!file) return;

      // Show uploading state in editor toolbar area
      const statusEl = $(`edit-status-${contentId}`);
      if (statusEl) {
        statusEl.textContent = 'Uploading image…';
        statusEl.className = 'edit-field-status';
      }

      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, '_');
      const path = `content/${contentId}/${Date.now()}-${safeName}`;

      try {
        const { error: uploadError } = await adminDb.storage
          .from('media')
          .upload(path, file, { cacheControl: '3600', upsert: false });

        if (uploadError) throw uploadError;

        const { data: urlData } = adminDb.storage.from('media').getPublicUrl(path);
        const range = quill.getSelection(true);
        quill.insertEmbed(range.index, 'image', urlData.publicUrl);
        quill.setSelection(range.index + 1);

        if (statusEl) {
          statusEl.textContent = '✓ Image uploaded';
          statusEl.className = 'edit-field-status edit-field-success';
          setTimeout(() => { statusEl.textContent = ''; statusEl.className = 'edit-field-status'; }, 3000);
        }
      } catch (err) {
        if (statusEl) {
          statusEl.textContent = `✕ Upload failed: ${err.message}`;
          statusEl.className = 'edit-field-status edit-field-error';
        }
      }
    };
  };
}


/**
 * Ensure all anchor tags inside a Quill editor open in a new tab.
 */
function patchQuillLinks(quill) {
  quill.root.querySelectorAll('a').forEach(a => {
    a.setAttribute('target', '_blank');
    a.setAttribute('rel', 'noopener noreferrer');
  });
}

/**
 * Initialises Quill editors for all [data-quill-id] containers.
 */
function initQuillEditors() {
  document.querySelectorAll('[data-quill-id]').forEach(container => {
    const id = container.dataset.quillId;

    const quill = new Quill(container, {
      theme: 'snow',
      modules: {
        toolbar: {
          container: [
            ['bold', 'italic', 'underline'],
            [{ list: 'ordered' }, { list: 'bullet' }],
            ['link', 'image'],
            ['clean']
          ],
          handlers: {
            image: function () {
              makeImageHandler(this.quill, id)();
            },
            link: function (value) {
              if (value) {
                let url = prompt('Enter the URL (e.g. https://example.com):');
                if (url) {
                  // Ensure absolute URL
                  if (!/^https?:\/\//i.test(url)) url = 'https://' + url;
                  this.quill.format('link', url);
                  // Patch all <a> in this editor to open in new tab
                  setTimeout(() => patchQuillLinks(this.quill), 50);
                }
              } else {
                this.quill.format('link', false);
              }
            }
          }
        }
      }
    });

    // Set initial content (stored as HTML)
    quill.root.innerHTML = savedContent[id] || '';
    // Ensure pre-existing links open in new tab
    patchQuillLinks(quill);

    // Track dirty state on every change
    quill.on('text-change', () => {
      const html = quill.root.innerHTML;
      const field = $(`edit-field-${id}`);
      const isBlank = html === '<p><br></p>';

      if (!isBlank && html !== (savedContent[id] || '')) {
        pendingEdits[id] = html;
        if (field) field.classList.add('dirty');
      } else if (isBlank && !savedContent[id]) {
        delete pendingEdits[id];
        if (field) field.classList.remove('dirty');
      } else if (html === savedContent[id]) {
        delete pendingEdits[id];
        if (field) field.classList.remove('dirty');
      } else {
        pendingEdits[id] = html;
        if (field) field.classList.add('dirty');
      }
      updateSaveBar();
    });

    quillInstances[id] = quill;
  });
}

async function loadContentEditor() {
  const container = $('tab-content');
  if (!container || !adminDb) return;

  container.innerHTML = '<div class="edit-loading">Loading content…</div>';

  try {
    const { data, error } = await adminDb.from('pack_content').select('*').order('id');
    if (error) throw error;
    if (!data || data.length === 0) {
      container.innerHTML = '<div class="edit-loading">No content rows found. Run the SQL schema seed first.</div>';
      return;
    }

    savedContent = {};
    pendingEdits = {};
    quillInstances = {};

    // Group rows by section prefix
    const groups = {};
    for (const row of data) {
      savedContent[row.id] = row.content;
      const section = deriveSection(row.id);
      if (!groups[section]) groups[section] = [];
      groups[section].push(row);
    }

    let html = `
      <div class="edit-save-bar" id="edit-save-bar">
        <div class="edit-save-bar-left">
          <button class="admin-button edit-save-btn" id="content-save-btn" disabled>Save changes</button>
          <span class="edit-dirty-badge" id="content-dirty-badge" hidden>0</span>
        </div>
        <button class="admin-button edit-discard-btn" id="content-discard-btn" disabled>Discard</button>
      </div>
      <div class="edit-status" id="edit-status"></div>
    `;

    for (const [section, rows] of Object.entries(groups)) {
      html += `<div class="edit-section-group">
        <div class="edit-section-heading">${escapeHtml(section)}</div>`;

      for (const row of rows) {
        if (isRichField(row.content)) {
          // Quill rich text editor
          html += `
            <div class="edit-field" id="edit-field-${escapeHtml(row.id)}">
              <label class="edit-field-label">${escapeHtml(humanLabel(row.id))}</label>
              <div class="quill-wrap" data-quill-id="${escapeHtml(row.id)}"></div>
              <div class="edit-field-status" id="edit-status-${escapeHtml(row.id)}"></div>
            </div>`;
        } else {
          // Plain textarea for short values (stat numbers, labels, etc.)
          const lines = Math.max(1, Math.min(4, row.content.split('\n').length + 1));
          html += `
            <div class="edit-field" id="edit-field-${escapeHtml(row.id)}">
              <label class="edit-field-label" for="edit-${escapeHtml(row.id)}">${escapeHtml(humanLabel(row.id))}</label>
              <textarea class="edit-textarea" id="edit-${escapeHtml(row.id)}"
                data-edit-id="${escapeHtml(row.id)}" rows="${lines}">${escapeHtml(row.content)}</textarea>
              <div class="edit-field-status" id="edit-status-${escapeHtml(row.id)}"></div>
            </div>`;
        }
      }

      html += '</div>';
    }

    container.innerHTML = html;
    contentLoaded = true;

    // Initialise all Quill editors
    initQuillEditors();

    // Bind plain textarea change listeners
    container.querySelectorAll('.edit-textarea').forEach(ta => {
      ta.addEventListener('input', () => {
        const id = ta.dataset.editId;
        const original = savedContent[id];
        const field = $(`edit-field-${id}`);

        if (ta.value !== original) {
          pendingEdits[id] = ta.value;
          if (field) field.classList.add('dirty');
        } else {
          delete pendingEdits[id];
          if (field) field.classList.remove('dirty');
        }
        updateSaveBar();
      });
    });

    $('content-save-btn').addEventListener('click', saveContentEdits);
    $('content-discard-btn').addEventListener('click', discardContentEdits);

    updateSaveBar();
  } catch (err) {
    container.innerHTML = `<div class="edit-loading edit-error">Failed to load content: ${escapeHtml(err.message)}</div>`;
  }
}

async function saveContentEdits() {
  const ids = Object.keys(pendingEdits);
  if (ids.length === 0) return;

  const saveBtn = $('content-save-btn');
  const statusEl = $('edit-status');
  if (saveBtn) saveBtn.disabled = true;
  if (statusEl) statusEl.textContent = `Saving ${ids.length} change${ids.length > 1 ? 's' : ''}…`;

  let successCount = 0;
  let failCount = 0;

  for (const id of ids) {
    const fieldStatus = $(`edit-status-${id}`);
    const field = $(`edit-field-${id}`);

    try {
      // Auth-based RPC — no password argument; validated via JWT session
      const { error } = await adminDb.rpc('update_pack_content_auth', {
        content_id: id,
        new_content: pendingEdits[id]
      });

      if (error) throw error;

      savedContent[id] = pendingEdits[id];
      delete pendingEdits[id];
      if (field) field.classList.remove('dirty');
      if (fieldStatus) {
        fieldStatus.textContent = '✓ Saved';
        fieldStatus.className = 'edit-field-status edit-field-success';
      }
      successCount++;
    } catch (err) {
      if (fieldStatus) {
        fieldStatus.textContent = `✕ ${err.message || 'Save failed'}`;
        fieldStatus.className = 'edit-field-status edit-field-error';
      }
      failCount++;
    }
  }

  if (statusEl) {
    statusEl.textContent = failCount > 0
      ? `Saved ${successCount}, failed ${failCount}.`
      : `All ${successCount} change${successCount > 1 ? 's' : ''} saved.`;
    statusEl.className = failCount > 0 ? 'edit-status edit-status-warn' : 'edit-status edit-status-ok';
  }

  updateSaveBar();

  setTimeout(() => {
    document.querySelectorAll('.edit-field-status').forEach(el => {
      el.textContent = '';
      el.className = 'edit-field-status';
    });
    if (statusEl) {
      statusEl.textContent = '';
      statusEl.className = 'edit-status';
    }
  }, 4000);
}

function discardContentEdits() {
  for (const id of Object.keys(pendingEdits)) {
    const field = $(`edit-field-${id}`);
    if (field) field.classList.remove('dirty');

    if (quillInstances[id]) {
      // Reset Quill editor to saved content
      quillInstances[id].root.innerHTML = savedContent[id] || '';
    } else {
      const ta = document.querySelector(`[data-edit-id="${id}"]`);
      if (ta) ta.value = savedContent[id];
    }
  }
  pendingEdits = {};
  updateSaveBar();
}

/* =================================================================
   BOOTSTRAP
   ================================================================= */

function bindAdmin() {
  $('login-button').addEventListener('click', signIn);
  $('admin-password').addEventListener('keydown', event => {
    if (event.key === 'Enter') signIn();
  });
  $('admin-email').addEventListener('keydown', event => {
    if (event.key === 'Enter') $('admin-password').focus();
  });

  $('refresh-button').addEventListener('click', () => {
    fetchSubmissions().catch(error => setStatus(error.message, true));
  });
  $('export-button').addEventListener('click', downloadCsv);
  $('lock-button').addEventListener('click', signOut);
  $('type-filter').addEventListener('change', renderRows);
  $('rating-filter').addEventListener('change', renderRows);
  $('search-filter').addEventListener('input', renderRows);

  document.querySelectorAll('[data-admin-tab]').forEach(btn => {
    btn.addEventListener('click', () => switchAdminTab(btn.dataset.adminTab));
  });

  // Check for existing session (e.g. page refresh while logged in)
  checkSession();
}

document.addEventListener('DOMContentLoaded', bindAdmin);
