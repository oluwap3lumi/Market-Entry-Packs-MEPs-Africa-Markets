-- ============================================================
-- South Africa Market Entry Pack 2026 — Supabase Schema
-- Run this in your Supabase SQL Editor
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS pack_ratings (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  pack       TEXT NOT NULL DEFAULT 'sa-2026',
  rating     INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment    TEXT,
  user_agent TEXT
);

CREATE TABLE IF NOT EXISTS market_insights (
  id         UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at TIMESTAMPTZ DEFAULT NOW(),
  pack       TEXT NOT NULL DEFAULT 'sa-2026',
  name       TEXT,
  org        TEXT,
  section    TEXT,
  insight    TEXT NOT NULL,
  status     TEXT DEFAULT 'pending' CHECK (status IN ('pending','reviewed','incorporated','rejected')),
  admin_notes TEXT
);

CREATE TABLE IF NOT EXISTS intro_requests (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  pack        TEXT NOT NULL DEFAULT 'sa-2026',
  name        TEXT NOT NULL,
  email       TEXT NOT NULL,
  org         TEXT,
  target      TEXT NOT NULL,
  intro_type  TEXT,
  context     TEXT,
  status      TEXT DEFAULT 'pending' CHECK (status IN ('pending','in_progress','completed','declined')),
  admin_notes TEXT
);

CREATE TABLE IF NOT EXISTS service_provider_ratings (
  id            UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at    TIMESTAMPTZ DEFAULT NOW(),
  pack          TEXT NOT NULL DEFAULT 'sa-2026',
  provider_name TEXT NOT NULL,
  provider_type TEXT,
  rating        INTEGER CHECK (rating BETWEEN 1 AND 5),
  review        TEXT,
  verified      BOOLEAN DEFAULT FALSE
);

CREATE TABLE IF NOT EXISTS pack_content (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  updated_at  TIMESTAMPTZ DEFAULT NOW(),
  pack        TEXT NOT NULL DEFAULT 'sa-2026',
  content_id  TEXT NOT NULL UNIQUE,
  content_html TEXT NOT NULL,
  updated_by  TEXT DEFAULT 'admin'
);

-- RLS
ALTER TABLE pack_ratings            ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_insights         ENABLE ROW LEVEL SECURITY;
ALTER TABLE intro_requests          ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_provider_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE pack_content            ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_insert_ratings" ON pack_ratings FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_insights" ON market_insights FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_intros" ON intro_requests FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_provider_ratings" ON service_provider_ratings FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_select_content" ON pack_content FOR SELECT TO anon USING (true);

CREATE INDEX IF NOT EXISTS idx_sa_pack_ratings ON pack_ratings (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sa_insights ON market_insights (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sa_intros ON intro_requests (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_sa_content ON pack_content (content_id);
