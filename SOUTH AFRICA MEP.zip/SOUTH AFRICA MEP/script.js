// ═══════════════════ CONFIGURATION ═══════════════════
const SUPABASE_URL = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';
const isSupabaseConfigured = SUPABASE_URL.startsWith('https://') && !SUPABASE_URL.includes('YOUR_') && SUPABASE_ANON_KEY.length > 40 && !SUPABASE_ANON_KEY.includes('YOUR_');
const db = isSupabaseConfigured && window.supabase ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY) : null;

// ═══════════════════ SECTION ORDER ═══════════════════
const SECTION_ORDER = ['front', 's1', 's2', 's3', 's4', 's5', 'feedback', 'glossary'];

// ═══════════════════ STATE ═══════════════════
let visitedSections = new Set();
let bookmarkedSection = null;
let darkModeEnabled = localStorage.getItem('mep-darkmode-sa') === '1';
let tooltipEl = null;
if (darkModeEnabled) document.body.classList.add('dark');

// ═══════════════════ ACRONYMS ═══════════════════
const ACRONYMS = {
  'B-BBEE': 'Broad-Based Black Economic Empowerment — mandatory SA transformation policy covering ownership, management, skills, enterprise development, and socio-economic contribution',
  'CIPC':   'Companies and Intellectual Property Commission — SA company and IP registration authority; BizPortal registration typically 1–3 business days',
  'FSCA':   'Financial Sector Conduct Authority — regulates financial services, fintech, crypto-assets, insurance, and capital markets; runs the Fintech Regulatory Sandbox (2023)',
  'SARB':   'South African Reserve Bank — central bank, banking supervision, payment system oversight, and exchange control authority',
  'SARS':   'South African Revenue Service — national tax authority; administers Income Tax, VAT (15%), CIT (27%), PAYE, and customs via eFiling',
  'DTIC':   'Department of Trade, Industry and Competition — investment promotion, B-BBEE policy, R&D Tax Incentive (Section 11D: 150% deduction)',
  'POPIA':  'Protection of Personal Information Act — SA data protection law; fully enforced from July 2021; up to ZAR 10M fine for non-compliance',
  'GNU':    'Government of National Unity — coalition government formed June 2024; includes ANC, DA, IFP, and smaller parties; driving current reform momentum',
  'IDC':    'Industrial Development Corporation — SA\'s primary DFI; ZAR 5M–5B+ tickets across all sectors; Green Economy window for climate tech',
  'DBSA':   'Development Bank of Southern Africa — SADC regional infrastructure DFI; essential for REIPPP projects and large-scale infrastructure',
  'REIPPP': 'Renewable Energy Independent Power Producer Procurement Programme — government competitive tender for renewable energy generation; Round 6+ active',
  'JET':    'Just Energy Transition Partnership — G7-backed USD 8.5B commitment to fund South Africa\'s coal-to-renewables transition',
  'JSE':    'Johannesburg Stock Exchange — Africa\'s largest stock exchange by market cap (~USD 1.2T); ~340 listings',
  'SACAA':  'South African Civil Aviation Authority — regulates commercial drone (RPAS) operations under Part 101',
  'SAHPRA': 'South African Health Products Regulatory Authority — regulates medicines, medical devices, and clinical trials',
  'NHI':    'National Health Insurance — SA government\'s universal health coverage programme; NHI Act signed May 2024',
  'EME':    'Exempted Micro Enterprise — companies with <ZAR 10M turnover; automatically B-BBEE Level 4',
  'QSE':    'Qualifying Small Enterprise — companies with ZAR 10–50M turnover; simplified B-BBEE scorecard',
  'CIT':    'Corporate Income Tax — 27% standard rate; 15% in designated SEZs; reduced from 28% in April 2023',
  'LRA':    'Labour Relations Act — SA\'s primary labour law; CCMA enforces unfair dismissal and collective bargaining',
  'SEZ':    'Special Economic Zone — designated zones with 15% CIT and enhanced incentives; Coega IDZ, East London IDZ',
  'SADC':   'Southern African Development Community — 16-country regional bloc; SA as largest economy is the regional gateway',
  'NERSA':  'National Energy Regulator of South Africa — issues generation licences; administers REIPPP framework',
  'ANC':    'African National Congress — ruling party since 1994; lost outright majority in May 2024 elections (40.18% of vote)',
  'DA':     'Democratic Alliance — official opposition and GNU coalition partner; holds several economic policy cabinet portfolios',
  'ZAR':    'South African Rand — official currency; ~ZAR 18–19 per USD (2024–2025); historically volatile against major currencies',
  'GDP':    'Gross Domestic Product — South Africa ~USD 382B nominal (2025); ~USD 1.0T PPP-adjusted; 2nd largest in Africa',
  'VC':     'Venture Capital — South Africa hosts Africa\'s deepest VC ecosystem; Knife Capital, 4Di, Naspers Foundry, Kalon VP all active',
  'DFI':    'Development Finance Institution — government-backed long-term lender; IFC, IDC, DBSA, BII all have active SA portfolios',
  'FDI':    'Foreign Direct Investment — USD 5.3B inflows to South Africa in 2024 (UNCTAD 2025)',
  'YC':     'Y Combinator — US seed accelerator; Aerobotics (W2020) is SA\'s most prominent YC alumnus; provides US market access and investor credibility',
  'API':    'Application Programming Interface — technical standard for software integration; Stitch and Ozow provide open banking API infrastructure for South Africa',
  'KYC':    'Know Your Customer — mandatory identity verification for banking and financial services; FSCA and SARB both require KYC compliance for all financial product providers',
  'AML':    'Anti-Money Laundering — Financial Intelligence Centre Act (FICA) mandates AML compliance for all South African financial services companies',
  'PAYU':   'Pay-As-You-Use — financing model converting upfront hardware cost to monthly operational subscription; Wetility\'s core residential solar model',
};

// ═══════════════════ SHOW PANEL ═══════════════════
function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(item => item.classList.remove('active'));
  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');
  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
  window.scrollTo({ top: 0, behavior: 'smooth' });
  // Reflow for CSS animations
  panel.querySelectorAll('.stat-card, .how-card-link').forEach(el => {
    el.style.animation = 'none';
    void el.offsetHeight;
    el.style.animation = '';
  });
}
window.showPanel = showPanel;

// ═══════════════════ SECTOR TABS ═══════════════════
function showSector(id) {
  const panel = document.getElementById('sector-' + id);
  if (!panel) return;
  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sector-tab').forEach(t => t.classList.remove('active'));
  panel.classList.add('active');
  document.querySelector(`.sector-tab[data-sector="${id}"]`)?.classList.add('active');
}

// ═══════════════════ VISITED & PROGRESS ═══════════════════
function markVisited(id) { visitedSections.add(id); }
function updateProgressBar(idx) {
  const fill = document.getElementById('progress-fill');
  if (fill) fill.style.width = (((idx + 1) / SECTION_ORDER.length) * 100) + '%';
}
function updateBookmarkIndicators() {
  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.classList.toggle('bookmarked', btn.dataset.panel === bookmarkedSection);
  });
}

// ═══════════════════ BOOKMARKS ═══════════════════
function setBookmark(id) {
  bookmarkedSection = (bookmarkedSection === id) ? null : id;
  localStorage.setItem('mep-bookmark-sa', bookmarkedSection || '');
  updateBookmarkIndicators();
}

// ═══════════════════ DARK MODE ═══════════════════
function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode-sa', darkModeEnabled ? '1' : '0');
  const btn = document.getElementById('darkmode-toggle');
  if (btn) btn.textContent = darkModeEnabled ? '☀️' : '🌙';
}

// ═══════════════════ PRINT ═══════════════════
function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  setTimeout(() => document.body.classList.remove('print-mode'), 100);
}

// ═══════════════════ SEARCH ═══════════════════
function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}
function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;
  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, .pack-progress-bar, .mep-tooltip, abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);
  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
  }
  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) showPanel(panel.id.replace('panel-', ''));
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

// ═══════════════════ PROSE CARDS ═══════════════════
function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = body.scrollHeight + 'px';
  });
}

// ═══════════════════ ACRONYM TOOLTIPS ═══════════════════
function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.getElementById('mep-tooltip');
}
function showTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || target.title || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 280, Math.max(8, rect.left));
  tooltipEl.style.top = (rect.bottom + 10) + 'px';
  tooltipEl.style.left = left + 'px';
}
function hideTooltip() { if (tooltipEl) tooltipEl.style.opacity = '0'; }
function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;
  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, script, .mep-abbr, .search-highlight, abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);
  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    if (!acronymRegex.test(node.nodeValue)) continue;
    replacements.push(node);
  }
  replacements.forEach(node => {
    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    acronymRegex.lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index;
      if (start > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.tabIndex = 0;
      abbr.textContent = match[0];
      fragment.appendChild(abbr);
      lastIndex = start + match[0].length;
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
  });
}

// ═══════════════════ SCORECARD ═══════════════════
(function initScorecard() {
  const steps = document.querySelectorAll('.scorecard-step');
  const result = document.getElementById('sc-result');
  const answers = {};
  if (!steps.length || !result) return;

  const RESULTS = {
    getResult(a) {
      const stage = a[0], sector = a[1], obj = a[2], bbee = a[3], province = a[4];
      let title = 'Your South Africa Entry Roadmap';
      let body = '';

      if (stage === 'idea') {
        body = '<strong>Recommendation: Build product before committing to South Africa entry.</strong> South Africa rewards companies with proven product-market fit from their home market. The regulatory, B-BBEE, and operational complexity of SA entry is best navigated with a working product and some initial revenue evidence. Use this pack to build your SA market map, then return when you have a product ready for local validation.';
      } else if (stage === 'corp') {
        body = '<strong>Recommendation: Gauteng-first with B-BBEE advisors engaged from day one.</strong> MNC expansions into SA require early engagement with a Tier 1 law firm (Cliffe Dekker Hofmeyr or Werksmans) for entity structuring, and a Big Four B-BBEE advisor (PwC or Deloitte) for transformation strategy. Your primary commercial headquarters should be Sandton or Rosebank for enterprise client proximity. Budget ZAR 2&#8211;5M for Year 1 legal, compliance, and establishment costs.';
      } else if (obj === 'capital') {
        body = '<strong>Recommendation: Western Cape first, with Knife Capital, 4Di Capital, and Grindstone as primary targets.</strong> Cape Town is Africa\'s primary fundraising environment for early-stage companies. Engage <a href="https://knifecapital.com" target="_blank" rel="noopener">Knife Capital</a> and <a href="https://www.4digroup.com" target="_blank" rel="noopener">4Di Capital</a> for initial conversations; apply to <a href="https://www.grindstone.co.za" target="_blank" rel="noopener">Grindstone Accelerator</a> if ZAR 1M+ ARR. Register your entity in SA via CIPC (1&#8211;3 days) before investor meetings to demonstrate commitment.';
      } else if (obj === 'enterprise') {
        body = '<strong>Recommendation: Gauteng first, with AlphaCode and Tshimologong as ecosystem entry points.</strong> Every South African multinational\'s decision-maker is in Gauteng. Engage <a href="https://alphacode.co.za" target="_blank" rel="noopener">AlphaCode</a> for fintech enterprise access, or <a href="https://www.tshimologong.joburg" target="_blank" rel="noopener">Tshimologong</a> for government and corporate digital economy procurement. Enterprise sales cycles are 3&#8211;9 months; budget accordingly and ensure B-BBEE compliance is in place before your first RFP.';
      } else if (sector === 'fintech') {
        body = '<strong>Recommendation: Register entity via CIPC, engage FSCA Fintech Sandbox, and apply to AlphaCode.</strong> South Africa\'s fintech regulatory pathway is among Africa\'s most structured. The FSCA Regulatory Sandbox (2023) provides an innovation licence pathway. Apply to <a href="https://alphacode.co.za" target="_blank" rel="noopener">AlphaCode</a> for RMI ecosystem access. Your first 50 paying customers in SA will be more credible to international VCs than 500 in a less regulated market.';
      } else if (sector === 'agritech') {
        body = '<strong>Recommendation: Western Cape first, targeting commercial farms in the citrus and wine belts.</strong> Follow the Aerobotics playbook: target commercial farmers in high-value export crops first (not smallholders), partner with <a href="https://www.nedbank.co.za" target="_blank" rel="noopener">Nedbank Agri</a> for distribution, and register with <a href="https://www.arc.agric.za" target="_blank" rel="noopener">ARC</a> for government agri-tech partnership credibility.';
      } else if (sector === 'climate') {
        body = '<strong>Recommendation: Target C&amp;I solar and the JET Partnership pipeline.</strong> The loadshedding crisis has passed but the energy transition opportunity is structural. Engage <a href="https://www.idc.co.za" target="_blank" rel="noopener">IDC Green Economy</a> for DFI capital, target the C&amp;I solar market through corporate partnerships, and map your product to the JET Partnership\'s USD 8.5B spend pipeline. The Northern Cape is your operational base for large-scale renewable energy projects.';
      } else {
        body = '<strong>Your next three actions:</strong> (1) Register your SA entity via <a href="https://www.bizportal.gov.za" target="_blank" rel="noopener">BizPortal/CIPC</a> (1&#8211;3 business days); (2) Confirm your B-BBEE EME status and engage a B-BBEE advisor if your turnover exceeds ZAR 10M; (3) Select your primary province (Gauteng for enterprise, Western Cape for SaaS/VC) and identify your first five customer or partner targets from the Directory section of this pack.';
      }

      if (bbee === 'no') {
        body += '<br><br><strong>B-BBEE Note:</strong> You have not yet addressed your B-BBEE strategy. If your annual turnover will exceed ZAR 10M in South Africa, engage a B-BBEE advisor immediately. Non-compliance creates material commercial disadvantage for enterprise sales and any government-adjacent business.';
      }
      if (province === 'unsure') {
        body += '<br><br><strong>Province Selection:</strong> For most technology companies, the decision is straightforward: Western Cape for SaaS, VC-seeking, and B2C; Gauteng for enterprise B2B, financial services, and government. If you\'re still unsure, use the Feedback tab to request a targeted province recommendation from our research team.';
      }
      document.getElementById('sc-result-title').textContent = title;
      return body;
    }
  };

  steps.forEach(step => {
    step.querySelectorAll('.sc-btn').forEach(btn => {
      btn.addEventListener('click', function() {
        const q = parseInt(this.dataset.scQ);
        answers[q] = this.dataset.scVal;
        step.querySelectorAll('.sc-btn').forEach(b => b.classList.remove('selected'));
        this.classList.add('selected');
        setTimeout(() => {
          if (q < steps.length - 1) {
            steps[q].classList.remove('active');
            steps[q + 1].classList.add('active');
          } else {
            steps[q].classList.remove('active');
            document.getElementById('sc-result-text').innerHTML = RESULTS.getResult(answers);
            result.classList.remove('hidden');
          }
        }, 200);
      });
    });
  });

  document.getElementById('sc-restart')?.addEventListener('click', function() {
    Object.keys(answers).forEach(k => delete answers[k]);
    steps.forEach(s => { s.classList.remove('active'); s.querySelectorAll('.sc-btn').forEach(b => b.classList.remove('selected')); });
    result.classList.add('hidden');
    steps[0].classList.add('active');
  });
})();

// ═══════════════════ FEEDBACK HANDLERS ═══════════════════
(function initFeedback() {
  function showStatus(el, msg, type) {
    if (!el) return;
    el.textContent = msg;
    el.className = 'feedback-status feedback-status-' + type;
    setTimeout(() => { el.textContent = ''; el.className = 'feedback-status'; }, 4500);
  }

  // Star rating
  const stars = document.querySelectorAll('.star-btn');
  let selectedRating = 0;
  stars.forEach(s => {
    s.addEventListener('mouseenter', function() {
      const v = parseInt(this.dataset.val);
      stars.forEach((star, i) => star.classList.toggle('hover', i < v));
    });
    s.addEventListener('mouseleave', () => stars.forEach(star => star.classList.remove('hover')));
    s.addEventListener('click', function() {
      selectedRating = parseInt(this.dataset.val);
      stars.forEach((star, i) => star.classList.toggle('active', i < selectedRating));
    });
  });

  document.getElementById('submit-rating')?.addEventListener('click', function() {
    if (!selectedRating) { showStatus(document.getElementById('rating-status'), 'Please select a star rating first.', 'error'); return; }
    const comment = document.getElementById('rating-comment')?.value || '';
    if (db) {
      db.from('pack_ratings').insert([{ rating: selectedRating, comment, pack: 'sa-2026' }])
        .then(() => showStatus(document.getElementById('rating-status'), 'Thank you for your rating!', 'success'))
        .catch(() => showStatus(document.getElementById('rating-status'), 'Rating saved locally. Connect Supabase to sync.', 'info'));
    } else {
      showStatus(document.getElementById('rating-status'), 'Thank you for your rating! (Connect Supabase to persist)', 'success');
    }
  });

  document.getElementById('submit-insight')?.addEventListener('click', function() {
    const text = document.getElementById('insight-text')?.value || '';
    if (!text.trim()) { showStatus(document.getElementById('insight-status'), 'Please add your insight before submitting.', 'error'); return; }
    const payload = {
      name: document.getElementById('insight-name')?.value || '',
      org: document.getElementById('insight-org')?.value || '',
      section: document.getElementById('insight-section')?.value || '',
      insight: text,
      pack: 'sa-2026'
    };
    if (db) {
      db.from('market_insights').insert([payload])
        .then(() => showStatus(document.getElementById('insight-status'), 'Insight submitted. Thank you!', 'success'))
        .catch(() => showStatus(document.getElementById('insight-status'), 'Submitted locally. Connect Supabase to sync.', 'info'));
    } else {
      showStatus(document.getElementById('insight-status'), 'Thank you for your insight!', 'success');
    }
  });

  document.getElementById('submit-intro')?.addEventListener('click', function() {
    const name = document.getElementById('intro-name')?.value || '';
    const email = document.getElementById('intro-email')?.value || '';
    const target = document.getElementById('intro-target')?.value || '';
    if (!name || !email || !target) { showStatus(document.getElementById('feedback-status') || document.getElementById('intro-status') || document.createElement('div'), 'Please fill in your name, email, and introduction target.', 'error'); return; }
    const payload = {
      name, email,
      org: document.getElementById('intro-org')?.value || '',
      target,
      intro_type: document.getElementById('intro-type')?.value || '',
      context: document.getElementById('intro-context')?.value || '',
      pack: 'sa-2026'
    };
    if (db) {
      db.from('intro_requests').insert([payload])
        .then(() => showStatus(document.getElementById('intro-status') || document.createElement('div'), 'Introduction request submitted!', 'success'))
        .catch(() => showStatus(document.getElementById('intro-status') || document.createElement('div'), 'Submitted locally. Connect Supabase to sync.', 'info'));
    } else {
      const s = document.getElementById('intro-status');
      if (s) { s.textContent = 'Request received!'; s.className = 'feedback-status feedback-status-success'; setTimeout(() => { s.textContent = ''; s.className = 'feedback-status'; }, 4500); }
    }
  });
})();

// ═══════════════════ INIT ═══════════════════
document.addEventListener('DOMContentLoaded', function() {
  // Nav buttons
  document.querySelectorAll('[data-panel]').forEach(btn => {
    if (btn.classList.contains('bookmark-btn')) return;
    btn.addEventListener('click', () => showPanel(btn.dataset.panel));
  });
  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.addEventListener('click', () => setBookmark(btn.dataset.panel));
  });
  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });

  // Dark mode toggle
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);
  const dmBtn = document.getElementById('darkmode-toggle');
  if (dmBtn) dmBtn.textContent = darkModeEnabled ? '☀️' : '🌙';

  // Print
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);

  // Sticky nav
  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 10), { passive: true });
  }

  // Search
  const searchInput = document.getElementById('pack-search');
  if (searchInput) {
    searchInput.addEventListener('input', function() {
      clearSearchHighlights();
      if (this.value.trim()) highlightSearch(this.value.trim());
    });
  }

  // Prose card accordions (delegated)
  document.querySelector('.pack-root')?.addEventListener('click', function(e) {
    const proseToggle = e.target.closest('.prose-toggle');
    if (proseToggle) {
      e.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;
      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : body.scrollHeight + 'px';
    }
    const fundingToggle = e.target.closest('.funding-toggle');
    if (fundingToggle) {
      e.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;
      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : body.scrollHeight + 'px';
    }
  });

  // How-cards navigation
  document.querySelectorAll('.how-card-link').forEach(card => {
    const handler = () => {
      const panel = card.dataset.navPanel;
      if (!panel) return;
      showPanel(panel);
      const anchor = card.dataset.navAnchor;
      if (anchor) {
        setTimeout(() => {
          const el = document.getElementById(anchor);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      }
    };
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); } });
  });

  // Initialize prose cards
  initializeProseCards();

  // Initialize tooltips
  createTooltip();
  wrapAcronyms();
  const root = document.querySelector('.pack-root');
  if (root && tooltipEl) {
    root.addEventListener('pointerover', e => { const t = e.target.closest('.mep-abbr'); if (t) showTooltip(t); });
    root.addEventListener('pointerout', e => { if (e.target.closest('.mep-abbr')) hideTooltip(); });
  }

  // Funding section defaults
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    if (!btn.hasAttribute('aria-expanded')) btn.setAttribute('aria-expanded', 'true');
    if (btn.getAttribute('aria-expanded') === 'true') {
      body.style.maxHeight = body.scrollHeight + 'px';
    } else {
      body.style.maxHeight = '0';
    }
  });

  // Restore bookmark
  const savedBookmark = localStorage.getItem('mep-bookmark-sa');
  if (savedBookmark && SECTION_ORDER.includes(savedBookmark)) {
    bookmarkedSection = savedBookmark;
    showPanel(savedBookmark);
  } else {
    showPanel('front');
  }
});
