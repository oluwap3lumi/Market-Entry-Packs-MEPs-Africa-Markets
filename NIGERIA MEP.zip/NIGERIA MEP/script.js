/* ── Nigeria Market Entry Pack 2026 — script.js ── */

'use strict';

/* ══ SUPABASE CONFIG ══
   Replace with your actual project credentials.
   Supabase is loaded dynamically so it never blocks the UI.
*/
const SUPABASE_URL  = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'YOUR_ANON_KEY';

let supabase = null;

function loadSupabase() {
  return new Promise((resolve) => {
    if (window.supabase) { resolve(); return; }
    if (SUPABASE_URL === 'https://YOUR_PROJECT_ID.supabase.co') { resolve(); return; }
    const s = document.createElement('script');
    s.src = 'https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2';
    s.onload = () => {
      try {
        supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON);
      } catch(e) {
        console.warn('Supabase init error:', e);
      }
      resolve();
    };
    s.onerror = () => { console.warn('Supabase CDN failed to load.'); resolve(); };
    document.head.appendChild(s);
  });
}

/* ══ DOM READY ══ */
document.addEventListener('DOMContentLoaded', () => {
  // Init all UI immediately — no waiting on external scripts
  initNavigation();
  initDarkMode();
  initSearch();
  initSectorTabs();
  initProseToggles();
  initFundingToggles();
  initBookmarks();
  initStarRating();
  initScorecard();
  initTooltips();
  initScrollProgress();
  initPrint();
  initHowCardLinks();

  // Ensure initial panel is visible
  const hash = location.hash.replace('#', '');
  if (!hash || !document.getElementById('panel-' + hash)) {
    const front = document.getElementById('panel-front');
    if (front && !front.classList.contains('active')) {
      front.classList.add('active');
    }
  }

  // Load Supabase in background — forms will work once it loads
  loadSupabase().then(() => {
    initFeedbackForms();
  });
});

/* ══ NAVIGATION ══ */
function initNavigation() {
  const navBtns   = document.querySelectorAll('.nav-btn[data-panel], .mobile-nav-item[data-panel]');
  const panels    = document.querySelectorAll('.panel[id^="panel-"]');
  const navStrip  = document.querySelector('.nav-strip');

  function showPanel(panelId) {
    // Hide all panels
    panels.forEach(p => {
      p.classList.remove('active');
      p.style.display = '';
    });
    navBtns.forEach(b => b.classList.remove('active'));

    const target = document.getElementById('panel-' + panelId);
    if (target) {
      target.classList.add('active');
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }

    navBtns.forEach(b => {
      if (b.dataset.panel === panelId) b.classList.add('active');
    });

    // update URL hash
    try { history.replaceState(null, '', '#' + panelId); } catch(e) {}

    // update progress
    updateProgress(panelId);

    // update bookmark indicators
    updateBookmarkIndicators();
  }

  navBtns.forEach(btn => {
    btn.addEventListener('click', function(e) {
      e.preventDefault();
      showPanel(this.dataset.panel);
    });
  });

  // deep-link support
  const hash = location.hash.replace('#', '');
  if (hash && document.getElementById('panel-' + hash)) {
    showPanel(hash);
  }

  // sticky nav shadow
  if (navStrip) {
    window.addEventListener('scroll', () => {
      navStrip.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }

  // expose globally for how-card links
  window._showPanel = showPanel;
}

/* ══ HOW-CARD NAV LINKS ══ */
function initHowCardLinks() {
  document.querySelectorAll('.how-card-link[data-nav-panel]').forEach(card => {
    const handler = () => window._showPanel && window._showPanel(card.dataset.navPanel);
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') handler(); });
  });
}

/* ══ DARK MODE ══ */
function initDarkMode() {
  const btn  = document.getElementById('darkmode-toggle');
  const root = document.documentElement;
  const body = document.body;
  const stored = localStorage.getItem('ng-mep-dark');

  function applyDark(isDark) {
    if (isDark) {
      body.classList.add('dark');
      root.classList.add('dark');
      if (btn) btn.textContent = '☀️';
    } else {
      body.classList.remove('dark');
      root.classList.remove('dark');
      if (btn) btn.textContent = '🌙';
    }
  }

  // Restore preference
  if (stored === 'true') applyDark(true);

  if (btn) {
    btn.addEventListener('click', () => {
      const isDark = !body.classList.contains('dark');
      applyDark(isDark);
      localStorage.setItem('ng-mep-dark', isDark);
    });
  }
}

/* ══ SEARCH ══ */
function initSearch() {
  const input = document.getElementById('pack-search');
  if (!input) return;

  let lastQuery = '';
  let debounceTimer;

  input.addEventListener('input', () => {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(() => {
      const q = input.value.trim().toLowerCase();
      if (q === lastQuery) return;
      lastQuery = q;

      // clear previous highlights
      document.querySelectorAll('mark.search-highlight').forEach(m => {
        const parent = m.parentNode;
        parent.replaceChild(document.createTextNode(m.textContent), m);
        parent.normalize();
      });

      if (q.length < 2) return;

      const panels = document.querySelectorAll('.panel');
      let firstMatch = null;

      panels.forEach(panel => {
        const walker = document.createTreeWalker(
          panel, NodeFilter.SHOW_TEXT,
          { acceptNode: n => {
            const tag = n.parentElement && n.parentElement.tagName;
            return ['SCRIPT', 'STYLE', 'INPUT', 'TEXTAREA', 'SELECT'].includes(tag)
              ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
          }}
        );

        const nodes = [];
        while (walker.nextNode()) nodes.push(walker.currentNode);

        nodes.forEach(node => {
          const text  = node.textContent;
          const lower = text.toLowerCase();
          const idx   = lower.indexOf(q);
          if (idx < 0) return;

          const frag = document.createDocumentFragment();
          let pos = 0;

          while (pos < text.length) {
            const i = lower.indexOf(q, pos);
            if (i < 0) {
              frag.appendChild(document.createTextNode(text.slice(pos)));
              break;
            }
            if (i > pos) frag.appendChild(document.createTextNode(text.slice(pos, i)));
            const mark = document.createElement('mark');
            mark.className = 'search-highlight';
            mark.textContent = text.slice(i, i + q.length);
            frag.appendChild(mark);
            pos = i + q.length;
          }

          node.parentNode.replaceChild(frag, node);

          if (!firstMatch) firstMatch = panel.id;
        });
      });

      // navigate to first matching panel
      if (firstMatch) {
        const panelId = firstMatch.replace('panel-', '');
        window._showPanel && window._showPanel(panelId);
        setTimeout(() => {
          const firstHighlight = document.querySelector('mark.search-highlight');
          if (firstHighlight) firstHighlight.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }, 150);
      }
    }, 220);
  });
}

/* ══ SECTOR TABS ══ */
function initSectorTabs() {
  const tabs = document.querySelectorAll('.sector-tab[data-sector]');
  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      const sector = tab.dataset.sector;
      const parent = tab.closest('.panel');
      if (!parent) return;

      parent.querySelectorAll('.sector-tab').forEach(t => t.classList.remove('active'));
      parent.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));

      tab.classList.add('active');
      const panel = parent.querySelector('#sector-' + sector);
      if (panel) panel.classList.add('active');
    });
  });
}

/* ══ PROSE TOGGLES ══ */
function initProseToggles() {
  // Wrap each prose-card's post-heading content in a .prose-body, collapsed by default.
  document.querySelectorAll('.prose-card').forEach(card => {
    const heading = card.querySelector('h4, h5');
    if (!heading) return;

    let body = card.querySelector('.prose-body');
    if (!body) {
      body = document.createElement('div');
      body.className = 'prose-body';
      let node = heading.nextSibling;
      while (node) {
        const next = node.nextSibling;
        body.appendChild(node);
        node = next;
      }
      card.appendChild(body);
    }
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = '0';

    const btn = card.querySelector('.prose-toggle');
    if (btn) btn.setAttribute('aria-expanded', 'false');
  });

  // Single-click toggle; measures live scrollHeight so it works regardless of
  // whether the panel was visible at load (avoids any two-click quirk).
  document.querySelectorAll('.prose-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const card = btn.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;

      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : body.scrollHeight + 'px';
    });
  });
}

/* ══ FUNDING TOGGLES ══ */
function initFundingToggles() {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    btn.addEventListener('click', () => {
      const section = btn.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      const expanded = btn.getAttribute('aria-expanded') === 'true';
      btn.setAttribute('aria-expanded', !expanded);
      if (body) {
        body.style.maxHeight = expanded ? '0' : '4000px';
        body.style.overflow  = expanded ? 'hidden' : '';
      }
    });
  });
}

/* ══ BOOKMARKS ══ */
const BOOKMARK_KEY = 'ng-mep-bookmarks';

function getBookmarks() {
  try { return JSON.parse(localStorage.getItem(BOOKMARK_KEY) || '[]'); }
  catch { return []; }
}

function saveBookmarks(bm) {
  localStorage.setItem(BOOKMARK_KEY, JSON.stringify(bm));
}

function initBookmarks() {
  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    const panelId = btn.dataset.panel;
    const bm = getBookmarks();
    if (bm.includes(panelId)) btn.style.opacity = '1';

    btn.addEventListener('click', () => {
      let bookmarks = getBookmarks();
      if (bookmarks.includes(panelId)) {
        bookmarks = bookmarks.filter(b => b !== panelId);
        btn.style.opacity = '0.35';
        showToast('Bookmark removed');
      } else {
        bookmarks.push(panelId);
        btn.style.opacity = '1';
        showToast('Section bookmarked');
      }
      saveBookmarks(bookmarks);
      updateBookmarkIndicators();
    });
  });
}

function updateBookmarkIndicators() {
  const bm = getBookmarks();
  document.querySelectorAll('.nav-btn[data-panel]').forEach(btn => {
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (bm.includes(btn.dataset.panel)) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else {
      if (indicator) indicator.remove();
    }
  });
}

/* ══ SCROLL PROGRESS ══ */
function updateProgress(panelId) {
  const panelOrder = ['front', 's1', 's1b', 's2', 's3', 's4', 's5', 's6', 'feedback', 'glossary'];
  const idx = panelOrder.indexOf(panelId);
  const pct = idx >= 0 ? ((idx + 1) / panelOrder.length) * 100 : 0;
  const fill = document.querySelector('.pack-progress-fill');
  if (fill) fill.style.width = pct + '%';
}

function initScrollProgress() {
  updateProgress('front');
}

/* ══ STAR RATING ══ */
function initStarRating() {
  const container = document.getElementById('star-rating');
  const thanks    = document.getElementById('rating-thanks');
  if (!container) return;

  const stars = container.querySelectorAll('.star');

  stars.forEach(star => {
    star.addEventListener('mouseover', () => {
      const val = parseInt(star.dataset.val);
      stars.forEach(s => s.classList.toggle('on', parseInt(s.dataset.val) <= val));
    });

    star.addEventListener('mouseout', () => {
      const selected = container.dataset.selected ? parseInt(container.dataset.selected) : 0;
      stars.forEach(s => s.classList.toggle('on', parseInt(s.dataset.val) <= selected));
    });

    star.addEventListener('click', () => {
      const val = parseInt(star.dataset.val);
      container.dataset.selected = val;
      stars.forEach(s => s.classList.toggle('on', parseInt(s.dataset.val) <= val));
      if (thanks) { thanks.style.display = 'block'; }
      submitRating(val);
    });

    star.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') star.click();
    });
  });
}

async function submitRating(val) {
  if (!supabase) { console.log('Rating submitted (offline):', val); return; }
  try {
    await supabase.from('pack_ratings').insert({ pack: 'nigeria_mep_2026', rating: val, created_at: new Date().toISOString() });
  } catch (e) { console.warn('Rating submission error:', e); }
}

/* ══ FEEDBACK FORMS ══ */
function initFeedbackForms() {
  setupForm('feedback-form', 'fb-submit', 'fb-form-msg', 'fb-thanks', async () => {
    const name    = document.getElementById('fb-name')?.value?.trim();
    const org     = document.getElementById('fb-org')?.value?.trim();
    const section = document.getElementById('fb-section')?.value;
    const type    = document.getElementById('fb-type')?.value;
    const message = document.getElementById('fb-message')?.value?.trim();

    if (!message) return { ok: false, msg: 'Please describe your feedback before submitting.' };

    const payload = { pack: 'nigeria_mep_2026', name, org, section, type, message, created_at: new Date().toISOString() };
    if (supabase) {
      const { error } = await supabase.from('pack_feedback').insert(payload);
      if (error) return { ok: false, msg: 'Submission error. Please try again.' };
    } else {
      console.log('Feedback (offline):', payload);
    }
    return { ok: true };
  });

  setupForm('intro-form', 'intro-submit', 'intro-form-msg', 'intro-thanks', async () => {
    const name    = document.getElementById('intro-name')?.value?.trim();
    const email   = document.getElementById('intro-email')?.value?.trim();
    const org     = document.getElementById('intro-org')?.value?.trim();
    const target  = document.getElementById('intro-target')?.value?.trim();
    const purpose = document.getElementById('intro-purpose')?.value;
    const context = document.getElementById('intro-context')?.value?.trim();

    if (!name || !email || !target) return { ok: false, msg: 'Please fill in your name, email, and who you would like to be connected with.' };
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) return { ok: false, msg: 'Please enter a valid email address.' };

    const payload = { pack: 'nigeria_mep_2026', name, email, org, target, purpose, context, created_at: new Date().toISOString() };
    if (supabase) {
      const { error } = await supabase.from('intro_requests').insert(payload);
      if (error) return { ok: false, msg: 'Submission error. Please try again.' };
    } else {
      console.log('Intro request (offline):', payload);
    }
    return { ok: true };
  });

  setupForm('sp-form', 'sp-submit', 'sp-form-msg', 'sp-thanks', async () => {
    const provider = document.getElementById('sp-provider')?.value?.trim();
    const service  = document.getElementById('sp-service')?.value?.trim();
    const rating   = document.getElementById('sp-rating')?.value;
    const comment  = document.getElementById('sp-comment')?.value?.trim();

    if (!provider || !rating) return { ok: false, msg: 'Please name the service provider and select a rating.' };

    const payload = { pack: 'nigeria_mep_2026', provider, service, rating: parseInt(rating), comment, created_at: new Date().toISOString() };
    if (supabase) {
      const { error } = await supabase.from('provider_ratings').insert(payload);
      if (error) return { ok: false, msg: 'Submission error. Please try again.' };
    } else {
      console.log('SP rating (offline):', payload);
    }
    return { ok: true };
  });
}

function setupForm(formId, submitId, msgId, thanksId, handler) {
  const form   = document.getElementById(formId);
  const btn    = document.getElementById(submitId);
  const msgEl  = document.getElementById(msgId);
  const thanks = document.getElementById(thanksId);

  if (!form || !btn) return;

  form.addEventListener('submit', async e => {
    e.preventDefault();

    if (msgEl)  { msgEl.textContent = ''; msgEl.className = 'form-message'; }
    btn.disabled = true;
    btn.classList.add('btn-loading');
    btn.textContent = 'Submitting…';

    try {
      const result = await handler();
      if (result.ok) {
        form.style.opacity = '0.4';
        form.style.pointerEvents = 'none';
        if (thanks) thanks.style.display = 'block';
      } else {
        if (msgEl) { msgEl.textContent = result.msg || 'An error occurred.'; msgEl.className = 'form-message error'; }
        btn.disabled = false;
        btn.classList.remove('btn-loading');
        btn.textContent = 'Submit';
      }
    } catch (err) {
      if (msgEl) { msgEl.textContent = 'An unexpected error occurred. Please try again.'; msgEl.className = 'form-message error'; }
      btn.disabled = false;
      btn.classList.remove('btn-loading');
      btn.textContent = 'Submit';
    }
  });
}

/* ══ SCORECARD ══ */
const SCORECARD_DIMS = [
  { key: 'market_size',     label: 'Market size and TAM',        context: 'How large is your addressable market in Nigeria? Consider 224M population, 40M+ SMEs, 82M off-grid households.' },
  { key: 'regulatory',      label: 'Regulatory complexity',      context: 'How complex is your sector\'s regulatory environment? CBN fintech licencing, NAFDAC pharma, NCC telecoms — rate complexity relative to your capacity to navigate it.' },
  { key: 'competition',     label: 'Competitive landscape',      context: 'How crowded is your segment? Consumer fintech is intensely competitive; agricultural finance, healthcare in secondary cities, and clean energy have lower competition density.' },
  { key: 'talent',          label: 'Talent availability',        context: 'How available is your required talent profile in Nigeria? Tech engineering in Lagos is abundant; clinical healthcare talent is scarce; agricultural field operators require significant training investment.' },
  { key: 'infrastructure',  label: 'Infrastructure readiness',   context: 'How dependent is your business on reliable power, internet, and logistics infrastructure? Products designed around infrastructure gaps perform better than those that assume reliability.' },
  { key: 'capital',         label: 'Capital access',             context: 'How clearly can you access the capital you need? Lagos-based fintech and climate tech have strong VC/DFI pipelines; northern market entry and niche B2B sectors have shallower institutional investor appetite.' },
  { key: 'local_partner',   label: 'Local partner quality',      context: 'Do you have or can you credibly secure a high-quality local Nigerian co-founder, advisor, or operator? The single most important factor for execution success.' },
  { key: 'fx_resilience',   label: 'FX resilience',              context: 'How resilient is your business model to 25–40% annual naira depreciation? USD-invoiced B2B models are structurally stronger than pure naira consumer plays.' },
];

function initScorecard() {
  const container = document.getElementById('scorecard-rows');
  const totalEl   = document.getElementById('sc-total-score');
  const labelEl   = document.getElementById('sc-result-label');
  const signalEl  = document.getElementById('sc-result-signal');
  const resetBtn  = document.getElementById('sc-reset-btn');

  if (!container) return;

  const scores = {};

  SCORECARD_DIMS.forEach(dim => {
    scores[dim.key] = 0;

    const row = document.createElement('div');
    row.className = 'scorecard-dim';
    row.innerHTML = `
      <div class="scorecard-dim-header">
        <div>
          <div class="scorecard-dim-name">${dim.label}</div>
          <div class="scorecard-dim-context">${dim.context}</div>
        </div>
        <div class="scorecard-dim-val" id="val-${dim.key}">—</div>
      </div>
      <div class="scorecard-slider-wrap">
        <span style="font-size:10px;color:var(--color-text-tertiary);">Low 1</span>
        <input type="range" class="scorecard-slider" id="slider-${dim.key}" min="1" max="10" step="1" value="5">
        <span style="font-size:10px;color:var(--color-text-tertiary);">10 High</span>
      </div>
    `;
    container.appendChild(row);

    const slider = row.querySelector('input[type="range"]');
    const valEl  = row.querySelector('.scorecard-dim-val');

    slider.addEventListener('input', () => {
      const v = parseInt(slider.value);
      scores[dim.key] = v;
      valEl.textContent = v;
      valEl.className = 'scorecard-dim-val scored ' + (v >= 7 ? 'score-high' : v >= 4 ? 'score-mid' : 'score-low');
      updateScorecardResult();
    });
  });

  function updateScorecardResult() {
    const vals = Object.values(scores).filter(v => v > 0);
    if (vals.length === 0) { totalEl.textContent = '—'; return; }

    const avg   = vals.reduce((a, b) => a + b, 0) / vals.length;
    const total = Math.round(avg * 10);
    totalEl.textContent = total;

    if (total >= 70) {
      labelEl.textContent = 'Strong market entry signal. Your profile aligns well with Nigeria\'s opportunity structure. Prioritise Lagos launch, CBN regulatory engagement, and institutional funding pipeline.';
      if (signalEl) { signalEl.textContent = 'Strong Signal'; signalEl.className = 'scorecard-result-signal signal-strong'; }
    } else if (total >= 45) {
      labelEl.textContent = 'Promising but conditional. Address your lowest-scoring dimensions — particularly local partner quality and regulatory complexity — before committing significant capital.';
      if (signalEl) { signalEl.textContent = 'Promising'; signalEl.className = 'scorecard-result-signal signal-promising'; }
    } else {
      labelEl.textContent = 'Significant caution warranted. Several dimensions require resolution before a capital commitment is advisable. Consider a 6–12 month market observation phase before formal entry.';
      if (signalEl) { signalEl.textContent = 'Proceed with Caution'; signalEl.className = 'scorecard-result-signal signal-caution'; }
    }
  }

  if (resetBtn) {
    resetBtn.addEventListener('click', () => {
      Object.keys(scores).forEach(k => { scores[k] = 0; });
      container.querySelectorAll('.scorecard-slider').forEach(s => { s.value = 5; });
      container.querySelectorAll('.scorecard-dim-val').forEach(v => { v.textContent = '—'; v.className = 'scorecard-dim-val'; });
      if (totalEl)  totalEl.textContent = '—';
      if (labelEl)  labelEl.textContent = 'Complete the scorecard above to receive your entry signal.';
      if (signalEl) { signalEl.textContent = ''; signalEl.className = 'scorecard-result-signal'; }
    });
  }
}

/* ══ TOOLTIPS (ABBREVIATIONS) ══ */
const ABBREVS = {
  'CBN':   'Central Bank of Nigeria — primary financial services regulator',
  'NCC':   'Nigerian Communications Commission — telecoms regulator',
  'NIPC':  'Nigerian Investment Promotion Commission — foreign investment body',
  'CAC':   'Corporate Affairs Commission — company registration body',
  'NITDA': 'National IT Development Agency — digital economy regulator',
  'NAFDAC': 'National Agency for Food and Drug Administration and Control',
  'NSA':   'Nigeria Startup Act 2022 — startup incentives framework',
  'NIBSS': 'Nigeria Inter-Bank Settlement System — central payment infrastructure',
  'NIP':   'Nigeria Instant Payment — real-time interbank payment rail',
  'FIRS':  'Federal Inland Revenue Service — federal tax authority',
  'BVN':   'Bank Verification Number — biometric banking identity system',
  'CAMA':  'Companies and Allied Matters Act 2020 — corporate law framework',
  'MFB':   'Microfinance Bank — CBN-licensed micro-lending institution',
  'PSB':   'Payment Service Bank — CBN-licensed mobile money operator',
  'PTSP':  'Payment Terminal Service Provider — POS deployment licence',
  'PaaS':  'Power-as-a-Service — solar energy subscription model',
  'LSETF': 'Lagos State Employment Trust Fund — SME low-interest loan facility',
  'BOI':   'Bank of Industry — Nigeria DFI for manufacturing and industrial lending',
  'EDA':   'Extension and Development Agent — agricultural field advisory agent',
  'NDPA':  'Nigeria Data Protection Act 2023',
  'DFI':   'Development Finance Institution — government-backed patient capital provider',
  'AfCFTA': 'African Continental Free Trade Area',
  'USSD':  'Unstructured Supplementary Service Data — mobile banking shortcode protocol',
  'PAPSS': 'Pan-African Payment and Settlement System — cross-border FX settlement',
  'REA':   'Rural Electrification Agency — mini-grid and off-grid programme body',
  'C&I':   'Commercial and Industrial (solar/energy context)',
  'FTZ':   'Free Trade Zone — export-oriented tax incentive area',
  'CERPAC':'Combined Expatriate Residence Permit and Aliens Card — work authorisation',
  'MPR':   'Monetary Policy Rate — CBN benchmark interest rate (currently 26.25%)',
  'NBS':   'National Bureau of Statistics — Nigeria official statistical body',
};

function initTooltips() {
  const tooltip = document.getElementById('mep-tooltip');
  if (!tooltip) return;

  // wrap abbreviations in <abbr> tags
  Object.keys(ABBREVS).forEach(abbr => {
    const regex = new RegExp(`\\b(${abbr})\\b(?![^<]*>)`, 'g');
    document.querySelectorAll('.prose-card p, .prose-card li, .stat-sub, .comp-desc, .assoc-desc, .case-study-block-body p, .analyst-note').forEach(el => {
      if (el.querySelector('abbr')) return; // already processed
      el.innerHTML = el.innerHTML.replace(regex, (match) =>
        `<abbr class="mep-abbr" data-def="${ABBREVS[abbr]}">${match}</abbr>`
      );
    });
  });

  // tooltip show/hide
  document.addEventListener('mouseover', e => {
    const abbr = e.target.closest('.mep-abbr');
    if (!abbr) return;
    tooltip.textContent = abbr.dataset.def;
    tooltip.style.opacity = '1';
    positionTooltip(e);
  });

  document.addEventListener('mousemove', e => {
    if (tooltip.style.opacity === '1') positionTooltip(e);
  });

  document.addEventListener('mouseout', e => {
    if (e.target.closest('.mep-abbr')) tooltip.style.opacity = '0';
  });

  function positionTooltip(e) {
    const x = e.clientX + 12;
    const y = e.clientY + 20;
    tooltip.style.left = Math.min(x, window.innerWidth - 240) + 'px';
    tooltip.style.top  = Math.min(y, window.innerHeight - 60) + 'px';
  }
}

/* ══ PRINT / PDF ══ */
function initPrint() {
  const btn = document.getElementById('print-btn');
  if (!btn) return;

  btn.addEventListener('click', () => {
    // Show all panels for print
    document.querySelectorAll('.panel').forEach(p => p.classList.add('active'));

    setTimeout(() => {
      window.print();
      // restore after print dialog
      setTimeout(() => {
        const hash = location.hash.replace('#', '') || 'front';
        document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
        const active = document.getElementById('panel-' + hash);
        if (active) active.classList.add('active');
      }, 1000);
    }, 100);
  });
}

/* ══ TOAST ══ */
function showToast(msg) {
  let toast = document.getElementById('mep-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'mep-toast';
    Object.assign(toast.style, {
      position: 'fixed', bottom: '72px', left: '50%', transform: 'translateX(-50%)',
      background: 'var(--ng-black)', color: '#fff', padding: '8px 18px',
      borderRadius: '2px', fontSize: '12px', zIndex: '999',
      opacity: '0', transition: 'opacity 0.2s ease', pointerEvents: 'none',
    });
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 2200);
}
