/* ── Nigeria MEP Admin Dashboard — admin.js ── */
'use strict';

/* ══ CONFIG ══ */
const SUPABASE_URL  = 'https://YOUR_PROJECT_ID.supabase.co';
const SUPABASE_ANON = 'YOUR_ANON_KEY';
const ADMIN_PW_HASH = 'nigeria_mep_admin_2026'; // Change before deploying

let supabase = null;
let adminAuthenticated = false;

/* ══ INIT ══ */
document.addEventListener('DOMContentLoaded', () => {
  initSupabase();
  initSidebar();
  initLogin();
});

function initSupabase() {
  try {
    if (window.supabase && SUPABASE_URL !== 'https://YOUR_PROJECT_ID.supabase.co') {
      supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON);
    }
  } catch (e) {
    console.warn('Supabase not initialised — using mock data mode.');
  }
}

/* ══ LOGIN ══ */
function initLogin() {
  // Check stored session
  const stored = sessionStorage.getItem('ng-mep-admin-auth');
  if (stored === 'true') {
    adminAuthenticated = true;
    showView('overview');
    loadAllData();
    return;
  }

  // Show login view
  showView('login');

  const loginBtn = document.getElementById('login-btn');
  const pwInput  = document.getElementById('admin-pw');
  const errEl    = document.getElementById('login-error');

  const attempt = () => {
    const pw = pwInput?.value?.trim();
    if (!pw) { if (errEl) errEl.textContent = 'Please enter a password.'; return; }

    if (pw === ADMIN_PW_HASH) {
      adminAuthenticated = true;
      sessionStorage.setItem('ng-mep-admin-auth', 'true');
      if (errEl) errEl.textContent = '';
      showView('overview');
      loadAllData();
    } else {
      if (errEl) errEl.textContent = 'Incorrect password. Please try again.';
      if (pwInput) { pwInput.value = ''; pwInput.focus(); }
    }
  };

  if (loginBtn) loginBtn.addEventListener('click', attempt);
  if (pwInput)  pwInput.addEventListener('keydown', e => { if (e.key === 'Enter') attempt(); });
}

/* ══ SIDEBAR NAVIGATION ══ */
function initSidebar() {
  document.querySelectorAll('.admin-nav-item[data-view]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (!adminAuthenticated && btn.dataset.view !== 'login') return;
      showView(btn.dataset.view);
    });
  });
}

function showView(viewId) {
  document.querySelectorAll('.admin-view').forEach(v => v.classList.remove('active'));
  document.querySelectorAll('.admin-nav-item').forEach(b => b.classList.remove('active'));

  const view = document.getElementById('view-' + viewId);
  if (view) view.classList.add('active');

  const btn = document.querySelector(`.admin-nav-item[data-view="${viewId}"]`);
  if (btn) btn.classList.add('active');
}

/* ══ DATA LOADING ══ */
async function loadAllData() {
  await Promise.all([
    loadOverview(),
    loadFeedback(),
    loadIntros(),
    loadRatings(),
    loadProviders(),
  ]);
}

/* ══ OVERVIEW ══ */
async function loadOverview() {
  if (!supabase) {
    renderOverviewMock();
    return;
  }

  try {
    const [feedback, intros, ratings, providers] = await Promise.all([
      supabase.from('pack_feedback').select('*', { count: 'exact', head: true }),
      supabase.from('intro_requests').select('*', { count: 'exact', head: true }),
      supabase.from('pack_ratings').select('rating'),
      supabase.from('provider_ratings').select('*', { count: 'exact', head: true }),
    ]);

    const fbCount  = feedback.count ?? 0;
    const intCount = intros.count ?? 0;
    const prCount  = providers.count ?? 0;

    const ratings_data = ratings.data ?? [];
    const avgRating = ratings_data.length
      ? (ratings_data.reduce((s, r) => s + r.rating, 0) / ratings_data.length).toFixed(1)
      : '—';

    setEl('stat-feedback',   fbCount);
    setEl('stat-intros',     intCount);
    setEl('stat-avg-rating', avgRating + (ratings_data.length ? ' / 5' : ''));
    setEl('stat-providers',  prCount);
    updateBadge('badge-feedback', fbCount);
    updateBadge('badge-intros',   intCount);

    // Recent activity
    const [recentFb, recentIntro] = await Promise.all([
      supabase.from('pack_feedback').select('name,org,section,created_at').order('created_at', { ascending: false }).limit(5),
      supabase.from('intro_requests').select('name,target,created_at').order('created_at', { ascending: false }).limit(3),
    ]);

    renderRecentActivity([
      ...(recentFb.data ?? []).map(r => ({ type: 'feedback', text: `${r.name || 'Anonymous'} (${r.org || 'unknown org'}) submitted feedback on ${r.section || 'General'}`, time: r.created_at })),
      ...(recentIntro.data ?? []).map(r => ({ type: 'intro', text: `${r.name || 'Anonymous'} requested intro to ${r.target || 'unknown'}`, time: r.created_at })),
    ].sort((a, b) => new Date(b.time) - new Date(a.time)).slice(0, 8));

  } catch (e) {
    console.warn('Overview load error:', e);
    renderOverviewMock();
  }
}

function renderOverviewMock() {
  setEl('stat-feedback',   '—');
  setEl('stat-intros',     '—');
  setEl('stat-avg-rating', '—');
  setEl('stat-providers',  '—');
  const el = document.getElementById('recent-activity');
  if (el) {
    el.className = 'admin-empty';
    el.textContent = 'Connect Supabase to view live activity data. See supabase-schema.sql for setup instructions.';
  }
}

function renderRecentActivity(items) {
  const el = document.getElementById('recent-activity');
  if (!el) return;

  if (!items.length) {
    el.className = 'admin-empty';
    el.textContent = 'No recent activity yet.';
    return;
  }

  el.className = '';
  el.innerHTML = items.map(item => `
    <div class="admin-activity-item">
      <div class="admin-activity-dot"></div>
      <div class="admin-activity-text">${escHtml(item.text)}</div>
      <div class="admin-activity-time">${formatDate(item.time)}</div>
    </div>
  `).join('');
}

/* ══ FEEDBACK ══ */
async function loadFeedback() {
  const tbody = document.getElementById('feedback-tbody');
  const empty = document.getElementById('feedback-empty');
  if (!tbody) return;

  if (!supabase) {
    tbody.innerHTML = '';
    if (empty) { empty.style.display = 'block'; empty.textContent = 'Connect Supabase to view feedback submissions.'; }
    return;
  }

  try {
    const { data, error } = await supabase
      .from('pack_feedback')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);

    if (error || !data?.length) {
      tbody.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }

    if (empty) empty.style.display = 'none';
    updateBadge('badge-feedback', data.length);

    tbody.innerHTML = data.map(row => `
      <tr id="fb-row-${row.id}">
        <td>${formatDate(row.created_at)}</td>
        <td>
          <strong>${escHtml(row.name || 'Anonymous')}</strong>
          ${row.org ? `<br><span style="font-size:11px;color:var(--admin-text-tertiary);">${escHtml(row.org)}</span>` : ''}
        </td>
        <td>${escHtml(row.section || '—')}</td>
        <td>${row.type ? `<span class="admin-status status-reviewed">${escHtml(row.type)}</span>` : '—'}</td>
        <td>
          <div class="admin-truncate" id="fb-msg-${row.id}">${escHtml(row.message || '')}</div>
          ${(row.message || '').length > 80 ? `<span class="admin-expand" onclick="expandCell('fb-msg-${row.id}')">Show more</span>` : ''}
        </td>
        <td>
          <button class="admin-btn-action" onclick="markFeedbackReviewed('${row.id}')">Mark Reviewed</button>
          <button class="admin-btn-danger" style="margin-left:4px;" onclick="deleteFeedback('${row.id}')">Delete</button>
        </td>
      </tr>
    `).join('');

    // Filter handlers
    const typeFilter    = document.getElementById('fb-filter-type');
    const sectionFilter = document.getElementById('fb-filter-section');

    const applyFilters = () => {
      const type    = typeFilter?.value || '';
      const section = sectionFilter?.value || '';
      data.forEach(row => {
        const tr = document.getElementById('fb-row-' + row.id);
        if (!tr) return;
        const typeMatch    = !type    || row.type    === type;
        const sectionMatch = !section || row.section === section;
        tr.style.display = (typeMatch && sectionMatch) ? '' : 'none';
      });
    };

    if (typeFilter)    typeFilter.addEventListener('change', applyFilters);
    if (sectionFilter) sectionFilter.addEventListener('change', applyFilters);

    // CSV export
    const exportBtn = document.getElementById('fb-export-btn');
    if (exportBtn) {
      exportBtn.onclick = () => exportCSV(data, ['created_at','name','org','section','type','message'], 'nigeria_mep_feedback.csv');
    }

  } catch (e) {
    console.warn('Feedback load error:', e);
  }
}

async function markFeedbackReviewed(id) {
  if (!supabase) return;
  try {
    await supabase.from('pack_feedback').update({ reviewed: true, reviewed_at: new Date().toISOString() }).eq('id', id);
    showToast('Marked as reviewed');
  } catch (e) { showToast('Error updating record'); }
}

async function deleteFeedback(id) {
  if (!confirm('Delete this feedback item?')) return;
  if (!supabase) return;
  try {
    await supabase.from('pack_feedback').delete().eq('id', id);
    const row = document.getElementById('fb-row-' + id);
    if (row) row.remove();
    showToast('Feedback deleted');
  } catch (e) { showToast('Error deleting record'); }
}

/* ══ INTRO REQUESTS ══ */
async function loadIntros() {
  const tbody = document.getElementById('intros-tbody');
  const empty = document.getElementById('intros-empty');
  if (!tbody) return;

  if (!supabase) {
    tbody.innerHTML = '';
    if (empty) { empty.style.display = 'block'; empty.textContent = 'Connect Supabase to view introduction requests.'; }
    return;
  }

  try {
    const { data, error } = await supabase
      .from('intro_requests')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);

    if (error || !data?.length) {
      tbody.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }

    if (empty) empty.style.display = 'none';
    updateBadge('badge-intros', data.filter(r => r.status === 'pending' || !r.status).length);

    tbody.innerHTML = data.map(row => `
      <tr id="intro-row-${row.id}">
        <td>${formatDate(row.created_at)}</td>
        <td>
          <strong>${escHtml(row.name || 'Anonymous')}</strong><br>
          <span style="font-size:11px;color:var(--admin-text-tertiary);">${escHtml(row.email || '')} ${row.org ? '· ' + escHtml(row.org) : ''}</span>
        </td>
        <td><strong>${escHtml(row.target || '—')}</strong></td>
        <td>${escHtml(row.purpose || '—')}</td>
        <td>
          <div class="admin-truncate" id="intro-ctx-${row.id}">${escHtml(row.context || '')}</div>
          ${(row.context || '').length > 80 ? `<span class="admin-expand" onclick="expandCell('intro-ctx-${row.id}')">Show more</span>` : ''}
        </td>
        <td>
          <span class="admin-status ${statusClass(row.status)}" id="intro-status-${row.id}">
            ${escHtml(row.status || 'pending')}
          </span>
        </td>
        <td>
          <select class="admin-select" style="font-size:10px;padding:3px 6px;min-width:90px;" onchange="updateIntroStatus('${row.id}', this.value)">
            <option value="">Update…</option>
            <option value="pending">Pending</option>
            <option value="matched">Matched</option>
            <option value="declined">Declined</option>
          </select>
        </td>
      </tr>
    `).join('');

    // CSV export
    const exportBtn = document.getElementById('intro-export-btn');
    if (exportBtn) {
      exportBtn.onclick = () => exportCSV(data, ['created_at','name','email','org','target','purpose','context','status'], 'nigeria_mep_intros.csv');
    }

  } catch (e) {
    console.warn('Intros load error:', e);
  }
}

async function updateIntroStatus(id, status) {
  if (!status || !supabase) return;
  try {
    await supabase.from('intro_requests').update({ status, updated_at: new Date().toISOString() }).eq('id', id);
    const badge = document.getElementById('intro-status-' + id);
    if (badge) { badge.textContent = status; badge.className = 'admin-status ' + statusClass(status); }
    showToast('Status updated to ' + status);
  } catch (e) { showToast('Error updating status'); }
}

/* ══ PACK RATINGS ══ */
async function loadRatings() {
  if (!supabase) return;

  try {
    const { data } = await supabase.from('pack_ratings').select('rating').eq('pack', 'nigeria_mep_2026');
    if (!data?.length) return;

    const total = data.length;
    const avg   = (data.reduce((s, r) => s + r.rating, 0) / total).toFixed(1);
    const fiveS = data.filter(r => r.rating === 5).length;
    const oneS  = data.filter(r => r.rating === 1).length;

    setEl('ratings-count', total);
    setEl('ratings-avg',   avg + ' / 5');
    setEl('ratings-5star', fiveS);
    setEl('ratings-1star', oneS);

    // Distribution bars
    const distEl = document.getElementById('ratings-distribution');
    if (distEl) {
      const counts = [5,4,3,2,1].map(star => ({
        star,
        count: data.filter(r => r.rating === star).length,
        pct:   Math.round((data.filter(r => r.rating === star).length / total) * 100),
      }));

      distEl.innerHTML = `
        <div style="font-size:13px;font-weight:500;color:var(--admin-text-primary);margin-bottom:16px;">Rating Distribution</div>
        ${counts.map(c => `
          <div class="admin-rating-bar-row">
            <div class="admin-rating-bar-label">★ ${c.star}</div>
            <div class="admin-rating-bar-track">
              <div class="admin-rating-bar-fill" style="width:${c.pct}%"></div>
            </div>
            <div class="admin-rating-bar-count">${c.count}</div>
          </div>
        `).join('')}
      `;
    }
  } catch (e) {
    console.warn('Ratings load error:', e);
  }
}

/* ══ PROVIDER RATINGS ══ */
async function loadProviders() {
  const tbody = document.getElementById('providers-tbody');
  const empty = document.getElementById('providers-empty');
  if (!tbody) return;

  if (!supabase) {
    tbody.innerHTML = '';
    if (empty) { empty.style.display = 'block'; empty.textContent = 'Connect Supabase to view provider ratings.'; }
    return;
  }

  try {
    const { data, error } = await supabase
      .from('provider_ratings')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(200);

    if (error || !data?.length) {
      tbody.innerHTML = '';
      if (empty) empty.style.display = 'block';
      return;
    }

    if (empty) empty.style.display = 'none';

    tbody.innerHTML = data.map(row => `
      <tr>
        <td>${formatDate(row.created_at)}</td>
        <td><strong>${escHtml(row.provider || '—')}</strong></td>
        <td>${escHtml(row.service || '—')}</td>
        <td>
          <span style="color:var(--ng-green);font-size:14px;">${'★'.repeat(row.rating || 0)}</span>
          <span style="color:var(--admin-text-tertiary);font-size:11px;margin-left:4px;">${row.rating}/5</span>
        </td>
        <td>
          <div class="admin-truncate" id="sp-comment-${row.id}">${escHtml(row.comment || '—')}</div>
          ${(row.comment || '').length > 80 ? `<span class="admin-expand" onclick="expandCell('sp-comment-${row.id}')">Show more</span>` : ''}
        </td>
      </tr>
    `).join('');

    // CSV export
    const exportBtn = document.getElementById('providers-export-btn');
    if (exportBtn) {
      exportBtn.onclick = () => exportCSV(data, ['created_at','provider','service','rating','comment'], 'nigeria_mep_provider_ratings.csv');
    }

  } catch (e) {
    console.warn('Providers load error:', e);
  }
}

/* ══ HELPERS ══ */
function setEl(id, val) {
  const el = document.getElementById(id);
  if (el) el.textContent = val;
}

function updateBadge(id, count) {
  const el = document.getElementById(id);
  if (el) {
    el.textContent = count;
    el.style.display = count > 0 ? '' : 'none';
  }
}

function formatDate(isoStr) {
  if (!isoStr) return '—';
  const d = new Date(isoStr);
  return d.toLocaleDateString('en-GB', { day: '2-digit', month: 'short', year: 'numeric' });
}

function escHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function statusClass(status) {
  const map = { pending: 'status-pending', matched: 'status-matched', declined: 'status-declined', reviewed: 'status-reviewed' };
  return map[status] || 'status-pending';
}

function expandCell(id) {
  const el = document.getElementById(id);
  if (!el) return;
  el.style.maxWidth = 'none';
  el.style.whiteSpace = 'normal';
  el.classList.remove('admin-truncate');
  const expandLink = el.nextElementSibling;
  if (expandLink && expandLink.classList.contains('admin-expand')) expandLink.remove();
}

function exportCSV(data, cols, filename) {
  const header = cols.join(',');
  const rows = data.map(row =>
    cols.map(col => {
      const val = row[col] ?? '';
      return `"${String(val).replace(/"/g, '""')}"`;
    }).join(',')
  );
  const csv  = [header, ...rows].join('\n');
  const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement('a');
  a.href     = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
  showToast('CSV exported: ' + filename);
}

/* ══ TOAST ══ */
function showToast(msg) {
  let toast = document.getElementById('admin-toast');
  if (!toast) {
    toast = document.createElement('div');
    toast.id = 'admin-toast';
    document.body.appendChild(toast);
  }
  toast.textContent = msg;
  toast.style.opacity = '1';
  clearTimeout(toast._timer);
  toast._timer = setTimeout(() => { toast.style.opacity = '0'; }, 2400);
}

/* ══ GLOBAL HELPERS FOR INLINE HANDLERS ══ */
window.expandCell          = expandCell;
window.markFeedbackReviewed = markFeedbackReviewed;
window.deleteFeedback      = deleteFeedback;
window.updateIntroStatus   = updateIntroStatus;
