-- ══════════════════════════════════════════════════════════════════
-- Nigeria Market Entry Pack 2026 — Supabase Schema
-- Run this in your Supabase SQL editor to create all required tables
-- ══════════════════════════════════════════════════════════════════

-- ── EXTENSIONS ──
create extension if not exists "uuid-ossp";

-- ══════════════════════════════════════════════════════════════════
-- TABLE: pack_feedback
-- Stores general feedback, data corrections, and content suggestions
-- ══════════════════════════════════════════════════════════════════
create table if not exists public.pack_feedback (
  id           uuid primary key default uuid_generate_v4(),
  pack         text not null default 'nigeria_mep_2026',
  name         text,
  org          text,
  section      text,
  type         text,
  message      text,
  reviewed     boolean default false,
  reviewed_at  timestamptz,
  created_at   timestamptz default now()
);

comment on table public.pack_feedback is
  'General feedback, data corrections, and content suggestions submitted via the Nigeria MEP feedback form.';

-- ══════════════════════════════════════════════════════════════════
-- TABLE: intro_requests
-- Stores introduction requests from pack users
-- ══════════════════════════════════════════════════════════════════
create table if not exists public.intro_requests (
  id           uuid primary key default uuid_generate_v4(),
  pack         text not null default 'nigeria_mep_2026',
  name         text,
  email        text,
  org          text,
  target       text,
  purpose      text,
  context      text,
  status       text default 'pending',   -- pending | matched | declined
  notes        text,                     -- admin internal notes
  updated_at   timestamptz,
  created_at   timestamptz default now()
);

comment on table public.intro_requests is
  'Introduction requests from pack users to Nigerian operators, investors, regulators, and ecosystem stakeholders.';

-- Status constraint
alter table public.intro_requests
  add constraint intro_status_check
  check (status in ('pending', 'matched', 'declined'));

-- ══════════════════════════════════════════════════════════════════
-- TABLE: pack_ratings
-- Stores overall pack quality ratings (1–5 stars)
-- ══════════════════════════════════════════════════════════════════
create table if not exists public.pack_ratings (
  id         uuid primary key default uuid_generate_v4(),
  pack       text not null default 'nigeria_mep_2026',
  rating     integer not null,
  created_at timestamptz default now()
);

comment on table public.pack_ratings is
  'Star ratings (1–5) submitted by pack users for overall quality assessment.';

-- Rating range constraint
alter table public.pack_ratings
  add constraint rating_range_check
  check (rating between 1 and 5);

-- ══════════════════════════════════════════════════════════════════
-- TABLE: provider_ratings
-- Stores user ratings and reviews of service providers
-- ══════════════════════════════════════════════════════════════════
create table if not exists public.provider_ratings (
  id         uuid primary key default uuid_generate_v4(),
  pack       text not null default 'nigeria_mep_2026',
  provider   text not null,
  service    text,
  rating     integer not null,
  comment    text,
  created_at timestamptz default now()
);

comment on table public.provider_ratings is
  'Ratings and qualitative reviews of legal, banking, accounting, and other service providers listed in the pack.';

-- Rating range constraint
alter table public.provider_ratings
  add constraint provider_rating_range_check
  check (rating between 1 and 5);

-- ══════════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY (RLS)
-- Enables public insert (anonymous submissions) while restricting
-- reads to authenticated admin users only
-- ══════════════════════════════════════════════════════════════════

-- pack_feedback
alter table public.pack_feedback enable row level security;

create policy "Allow public insert on pack_feedback"
  on public.pack_feedback for insert
  to anon
  with check (true);

create policy "Allow authenticated read on pack_feedback"
  on public.pack_feedback for select
  to authenticated
  using (true);

create policy "Allow authenticated update on pack_feedback"
  on public.pack_feedback for update
  to authenticated
  using (true);

create policy "Allow authenticated delete on pack_feedback"
  on public.pack_feedback for delete
  to authenticated
  using (true);

-- intro_requests
alter table public.intro_requests enable row level security;

create policy "Allow public insert on intro_requests"
  on public.intro_requests for insert
  to anon
  with check (true);

create policy "Allow authenticated read on intro_requests"
  on public.intro_requests for select
  to authenticated
  using (true);

create policy "Allow authenticated update on intro_requests"
  on public.intro_requests for update
  to authenticated
  using (true);

-- pack_ratings
alter table public.pack_ratings enable row level security;

create policy "Allow public insert on pack_ratings"
  on public.pack_ratings for insert
  to anon
  with check (true);

create policy "Allow authenticated read on pack_ratings"
  on public.pack_ratings for select
  to authenticated
  using (true);

-- provider_ratings
alter table public.provider_ratings enable row level security;

create policy "Allow public insert on provider_ratings"
  on public.provider_ratings for insert
  to anon
  with check (true);

create policy "Allow authenticated read on provider_ratings"
  on public.provider_ratings for select
  to authenticated
  using (true);

-- ══════════════════════════════════════════════════════════════════
-- INDEXES
-- Optimise common admin query patterns
-- ══════════════════════════════════════════════════════════════════

-- pack_feedback
create index if not exists idx_feedback_pack         on public.pack_feedback(pack);
create index if not exists idx_feedback_created_at   on public.pack_feedback(created_at desc);
create index if not exists idx_feedback_section      on public.pack_feedback(section);
create index if not exists idx_feedback_type         on public.pack_feedback(type);
create index if not exists idx_feedback_reviewed     on public.pack_feedback(reviewed);

-- intro_requests
create index if not exists idx_intros_pack           on public.intro_requests(pack);
create index if not exists idx_intros_created_at     on public.intro_requests(created_at desc);
create index if not exists idx_intros_status         on public.intro_requests(status);
create index if not exists idx_intros_email          on public.intro_requests(email);

-- pack_ratings
create index if not exists idx_ratings_pack          on public.pack_ratings(pack);
create index if not exists idx_ratings_created_at    on public.pack_ratings(created_at desc);
create index if not exists idx_ratings_rating        on public.pack_ratings(rating);

-- provider_ratings
create index if not exists idx_providers_pack        on public.provider_ratings(pack);
create index if not exists idx_providers_created_at  on public.provider_ratings(created_at desc);
create index if not exists idx_providers_provider    on public.provider_ratings(provider);
create index if not exists idx_providers_rating      on public.provider_ratings(rating);

-- ══════════════════════════════════════════════════════════════════
-- VIEWS
-- Convenient admin analytics views
-- ══════════════════════════════════════════════════════════════════

-- Average pack rating per pack
create or replace view public.v_pack_rating_summary as
  select
    pack,
    count(*)                               as total_ratings,
    round(avg(rating), 2)                  as avg_rating,
    count(*) filter (where rating = 5)     as five_star,
    count(*) filter (where rating = 4)     as four_star,
    count(*) filter (where rating = 3)     as three_star,
    count(*) filter (where rating = 2)     as two_star,
    count(*) filter (where rating = 1)     as one_star
  from public.pack_ratings
  group by pack;

-- Provider ratings aggregated by provider
create or replace view public.v_provider_rating_summary as
  select
    provider,
    count(*)              as total_reviews,
    round(avg(rating), 2) as avg_rating,
    min(rating)           as min_rating,
    max(rating)           as max_rating
  from public.provider_ratings
  where pack = 'nigeria_mep_2026'
  group by provider
  order by total_reviews desc;

-- Pending intro requests with requester details
create or replace view public.v_pending_intros as
  select
    id, name, email, org, target, purpose, context, created_at
  from public.intro_requests
  where pack = 'nigeria_mep_2026'
    and (status = 'pending' or status is null)
  order by created_at asc;

-- Feedback by section (unreviewed only)
create or replace view public.v_unreviewed_feedback as
  select
    id, name, org, section, type, message, created_at
  from public.pack_feedback
  where pack = 'nigeria_mep_2026'
    and (reviewed = false or reviewed is null)
  order by created_at asc;

-- ══════════════════════════════════════════════════════════════════
-- SETUP NOTES
-- ══════════════════════════════════════════════════════════════════

/*
DEPLOYMENT STEPS:
─────────────────
1. Create a new Supabase project at https://supabase.com
2. Open the SQL editor and run this entire script
3. Navigate to Project Settings > API to find:
   - Project URL → replace SUPABASE_URL in script.js and admin.js
   - anon / public key → replace SUPABASE_ANON in script.js and admin.js
4. For admin.js, also update ADMIN_PW_HASH to a secure password of your choice
5. In Supabase Authentication > Settings:
   - Enable "Email" provider for admin login if desired
   - Alternatively, the current password-gate in admin.js is sufficient
     for a private admin dashboard not exposed publicly
6. Test by submitting a feedback form on the pack and confirming
   the row appears in the pack_feedback table

OPTIONAL — REALTIME (for live admin dashboard updates):
────────────────────────────────────────────────────────
In Supabase > Database > Replication:
  - Enable realtime on: pack_feedback, intro_requests, pack_ratings, provider_ratings
Then in admin.js, subscribe to the relevant channels:
  supabase.channel('admin-live')
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'pack_feedback' }, () => loadFeedback())
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'intro_requests' }, () => loadIntros())
    .subscribe()

DATA SECURITY NOTES:
─────────────────────
- Anonymous users can INSERT into all tables (required for public form submissions)
- Only authenticated (logged-in) users can SELECT, UPDATE, or DELETE
- The admin.js password gate provides a client-side authentication layer
- For production deployments, add server-side auth via Supabase Auth
  (email/password or magic link) and replace the password gate with
  a proper Supabase session check
- Never expose your SERVICE_ROLE key in client-side code
- The anon key has limited permissions per the RLS policies above

ESTIMATED STORAGE (per 1,000 submissions):
────────────────────────────────────────────
- pack_feedback:    ~0.5 MB
- intro_requests:   ~0.8 MB
- pack_ratings:     ~0.05 MB
- provider_ratings: ~0.3 MB
Well within Supabase free tier (500 MB database, 5 GB file storage)
*/
