-- Uganda Market Entry Pack — Supabase Backend Schema
-- Run this once in the Supabase SQL editor for a new Uganda MEP project.
-- Replace the temporary admin password below before deploying.
-- This schema is functionally identical to the Ghana MEP schema;
-- only labels and seed content are Uganda-specific.

create extension if not exists pgcrypto;

-- ═══════════════════════════════════════════════════════════════
-- SUBMISSION TABLES
-- ═══════════════════════════════════════════════════════════════

create table if not exists public.market_insights (
  id               uuid        primary key default gen_random_uuid(),
  created_at       timestamptz not null    default now(),
  sector           text,
  insight_text     text        not null,
  contributor_name text,
  page_url         text,
  user_agent       text,
  reviewed         boolean     not null    default false,
  internal_notes   text
);

create table if not exists public.service_provider_ratings (
  id            uuid        primary key default gen_random_uuid(),
  created_at    timestamptz not null    default now(),
  provider_name text        not null,
  rating        integer     not null    check (rating between 1 and 5),
  comment       text,
  page_url      text,
  user_agent    text,
  reviewed      boolean     not null    default false,
  internal_notes text
);

create table if not exists public.intro_requests (
  id              uuid        primary key default gen_random_uuid(),
  created_at      timestamptz not null    default now(),
  looking_for     text        not null,
  company_context text        not null,
  email           text        not null,
  page_url        text,
  user_agent      text,
  status          text        not null    default 'new'
                              check (status in ('new', 'contacted', 'closed')),
  internal_notes  text
);

create table if not exists public.pack_ratings (
  id         uuid        primary key default gen_random_uuid(),
  created_at timestamptz not null    default now(),
  rating     integer     not null    check (rating between 1 and 5),
  page_url   text,
  user_agent text
);

create table if not exists public.admin_settings (
  key        text        primary key,
  value      text        not null,
  updated_at timestamptz not null default now()
);

insert into public.admin_settings (key, value)
values ('admin_password_hash', extensions.crypt('change-me-now', extensions.gen_salt('bf')))
on conflict (key) do nothing;

-- ═══════════════════════════════════════════════════════════════
-- ROW LEVEL SECURITY
-- ═══════════════════════════════════════════════════════════════

alter table public.market_insights          enable row level security;
alter table public.service_provider_ratings enable row level security;
alter table public.intro_requests           enable row level security;
alter table public.pack_ratings             enable row level security;
alter table public.admin_settings           enable row level security;

drop policy if exists "Allow public insight submissions"   on public.market_insights;
create policy "Allow public insight submissions"
on public.market_insights for insert to anon
with check (insight_text is not null and length(trim(insight_text)) > 0);

drop policy if exists "Allow public provider ratings"     on public.service_provider_ratings;
create policy "Allow public provider ratings"
on public.service_provider_ratings for insert to anon
with check (provider_name is not null and length(trim(provider_name)) > 0 and rating between 1 and 5);

drop policy if exists "Allow public intro requests"       on public.intro_requests;
create policy "Allow public intro requests"
on public.intro_requests for insert to anon
with check (
  looking_for is not null and company_context is not null and email is not null
  and length(trim(looking_for)) > 0 and length(trim(company_context)) > 0 and length(trim(email)) > 0
);

drop policy if exists "Allow public pack ratings"         on public.pack_ratings;
create policy "Allow public pack ratings"
on public.pack_ratings for insert to anon
with check (rating between 1 and 5);

-- ═══════════════════════════════════════════════════════════════
-- INDEXES
-- ═══════════════════════════════════════════════════════════════

create index if not exists market_insights_created_at_idx          on public.market_insights (created_at desc);
create index if not exists service_provider_ratings_created_at_idx on public.service_provider_ratings (created_at desc);
create index if not exists intro_requests_created_at_idx           on public.intro_requests (created_at desc);
create index if not exists pack_ratings_created_at_idx             on public.pack_ratings (created_at desc);

-- ═══════════════════════════════════════════════════════════════
-- ADMIN RPCs (password-based, for fallback)
-- ═══════════════════════════════════════════════════════════════

create or replace function public.set_admin_password(new_password text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if new_password is null or length(new_password) < 12 then
    raise exception 'Admin password must be at least 12 characters.';
  end if;
  insert into public.admin_settings (key, value, updated_at)
  values ('admin_password_hash', extensions.crypt(new_password, extensions.gen_salt('bf')), now())
  on conflict (key) do update set value = excluded.value, updated_at = excluded.updated_at;
end; $$;

create or replace function public.is_admin_password(password text)
returns boolean language sql security definer stable set search_path = public as $$
  select exists (
    select 1 from public.admin_settings
    where key = 'admin_password_hash'
      and value = extensions.crypt(password, value)
  );
$$;

create or replace function public.get_admin_submissions(password text)
returns jsonb language plpgsql security definer set search_path = public as $$
declare is_valid boolean;
begin
  select public.is_admin_password(password) into is_valid;
  if not is_valid then raise exception 'Invalid admin password.'; end if;
  return jsonb_build_object(
    'market_insights',          coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.market_insights t), '[]'::jsonb),
    'service_provider_ratings', coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.service_provider_ratings t), '[]'::jsonb),
    'intro_requests',           coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.intro_requests t), '[]'::jsonb),
    'pack_ratings',             coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.pack_ratings t), '[]'::jsonb)
  );
end; $$;

-- ═══════════════════════════════════════════════════════════════
-- REVOKE / GRANT — minimal privilege model
-- ═══════════════════════════════════════════════════════════════

revoke all on table public.market_insights          from anon, authenticated;
revoke all on table public.service_provider_ratings from anon, authenticated;
revoke all on table public.intro_requests           from anon, authenticated;
revoke all on table public.pack_ratings             from anon, authenticated;
revoke all on table public.admin_settings           from anon, authenticated;
revoke execute on function public.set_admin_password(text)    from public, anon, authenticated;
revoke execute on function public.is_admin_password(text)     from public, anon, authenticated;
revoke execute on function public.get_admin_submissions(text) from public, anon, authenticated;

grant insert on table public.market_insights          to anon;
grant insert on table public.service_provider_ratings to anon;
grant insert on table public.intro_requests           to anon;
grant insert on table public.pack_ratings             to anon;
grant execute on function public.is_admin_password(text)     to anon;
grant execute on function public.get_admin_submissions(text) to anon;

-- ═══════════════════════════════════════════════════════════════
-- PACK CONTENT — editable text blocks for index.html
-- ═══════════════════════════════════════════════════════════════

create table if not exists public.pack_content (
  id         text        primary key,
  content    text        not null,
  updated_at timestamptz not null default now(),
  updated_by text
);

alter table public.pack_content enable row level security;

drop policy if exists "Allow public content reads" on public.pack_content;
create policy "Allow public content reads"
on public.pack_content for select to anon using (true);

revoke insert, update, delete on table public.pack_content from anon, authenticated;
grant select on table public.pack_content to anon;

create or replace function public.update_pack_content(
  password    text,
  content_id  text,
  new_content text
) returns void language plpgsql security definer set search_path = public as $$
declare is_valid boolean;
begin
  select public.is_admin_password(password) into is_valid;
  if not is_valid then raise exception 'Invalid admin password.'; end if;
  insert into public.pack_content (id, content, updated_at, updated_by)
  values (content_id, new_content, now(), 'admin')
  on conflict (id) do update
  set content = excluded.content, updated_at = excluded.updated_at, updated_by = excluded.updated_by;
end; $$;

revoke execute on function public.update_pack_content(text, text, text) from public, anon, authenticated;
grant  execute on function public.update_pack_content(text, text, text) to anon;

-- ═══════════════════════════════════════════════════════════════
-- SEED CONTENT — Uganda-specific defaults
-- (ON CONFLICT DO NOTHING — won't overwrite admin edits)
-- ═══════════════════════════════════════════════════════════════

insert into public.pack_content (id, content) values
  -- Front matter
  ('front-eyebrow',    '2026 Edition — East Africa Series'),
  ('front-title',      'Uganda\nMarket Entry Pack'),
  ('front-sub',        'Institutional-Grade Market Intelligence for Strategic Entry. For founders, operators, and investors entering East Africa''s most entrepreneur-dense economy.'),
  ('front-how-title',  'How to use this pack'),
  ('front-how1-label', 'Orient fast'),
  ('front-how1-desc',  'Use the Country Snapshot and Scorecard to assess whether Uganda fits your risk-return profile. Check the macro trajectory, political environment, and digital infrastructure readiness before reading further.'),
  ('front-how2-label', 'Match your sector'),
  ('front-how2-desc',  'Jump to Section 3 and read only the sector(s) relevant to your business — Fintech, Agritech, Healthtech, or Mobility and Climate Tech. Each includes a competitive landscape, regulatory environment, and case studies.'),
  ('front-how3-label', 'Structure your entry'),
  ('front-how3-desc',  'Use Section 2''s decision matrix to select your entry vehicle, then follow the URSB registration checklist. Know your UIA capital requirements and sector licensing obligations before committing capital.'),
  ('front-how4-label', 'Share and improve'),
  ('front-how4-desc',  'Add your on-the-ground insights via the Feedback tab. Rate agencies, flag regulations that have changed, and request introductions to investors, operators, or regulators active in the Ugandan ecosystem.'),
  ('front-fit-title',  'Who belongs here — and who doesn''t'),
  ('front-analyst-note', 'Uganda in 2026 is an underweighted opportunity. GDP growth projected at 6.0%, inflation moderated to approximately 3%, Bank of Uganda CBR easing at 9.75%, and oil production coming online from 2025–2026. The agricultural finance gap — 72% of the workforce in farming with less than 3% formal credit access — is the single largest structural fintech opportunity in East Africa. Founders entering with cooperative-channel distribution, mobile-money-based credit scoring, and DFI-aligned capital will find a market with significantly lower competitive density than Nairobi or Lagos at comparable upside.'),

  -- Section 1
  ('s1-title',              'Strategic Country Overview'),
  ('s1-intro',              'Uganda is a landlocked East African nation of approximately 50 million people with one of Africa''s most dynamic startup ecosystems. Despite governance risk, the country has maintained consistent GDP growth, deep mobile money infrastructure, and an agricultural economy that represents the continent''s largest underserved fintech opportunity.'),
  ('s1-gdp-value',          '$52B'),
  ('s1-gdp-sub',            '$147B PPP-adjusted (IMF 2025)'),
  ('s1-growth-value',       '6.0% / 6.3%'),
  ('s1-growth-sub',         'IMF / World Bank forecast'),
  ('s1-inflation-value',    '3.0%'),
  ('s1-inflation-sub',      'Down from 10.7% peak (2022)'),
  ('s1-population-value',   '50M+'),
  ('s1-population-sub',     '78% under age 30 (UBOS 2024)'),
  ('s1-fx-reserves-value',  '9.75%'),
  ('s1-fx-reserves-sub',    'Central Bank Rate — easing cycle'),
  ('s1-fdi-value',          '$1.5B+'),
  ('s1-fdi-sub',            'FDI inflows 2024 (UIA)'),

  -- Section 2
  ('s2-title',          'Market Entry Framework'),
  ('s2-intro',          'Foreign investors entering Uganda must navigate two principal registration regimes: company incorporation under the Companies Act 2012 via URSB, and investment registration under the Uganda Investment Authority (UIA). This section covers registration mechanics, entry vehicle options, regulatory risk, and FX considerations.'),
  ('s2-fx-usd-rate',    '~3,700'),
  ('s2-fx-usd-trend',   'UGX: moderate depreciation trend'),
  ('s2-fx-gbp-rate',    '~4,700'),
  ('s2-fx-gbp-trend',   'Monitor quarterly for repatriation'),
  ('s2-fx-eur-rate',    '~4,100'),
  ('s2-fx-eur-trend',   'EU fundraising: EUR exposure risk'),

  -- Section 3
  ('s3-title', 'Sector Deep Dives'),
  ('s3-intro', 'Four sectors with the strongest entry dynamics in Uganda right now. Select a sector tab to explore market sizing, regulatory environment, competitive landscape, and case studies from companies operating on the ground.'),

  -- Fintech stats
  ('s3-fintech-unbanked-value',  '37M+'),
  ('s3-fintech-unbanked-sub',    'Registered mobile money accounts (2024)'),
  ('s3-fintech-momo-value',      'UGX 104T'),
  ('s3-fintech-momo-sub',        'Annual MM transaction value'),
  ('s3-fintech-cos-value',       '~63%'),
  ('s3-fintech-cos-sub',         'Adults formally unbanked'),
  ('s3-fintech-sandbox-value',   '~62%'),
  ('s3-fintech-sandbox-sub',     'MTN MoMo market share (2024)'),

  -- Agritech stats
  ('s3-agritech-gdp-value',      '24%'),
  ('s3-agritech-gdp-sub',        'Agriculture share of GDP'),
  ('s3-agritech-workforce-value','72%'),
  ('s3-agritech-workforce-sub',  'Workforce in agriculture'),
  ('s3-agritech-cocoa-value',    '<3%'),
  ('s3-agritech-cocoa-sub',      'Formal credit reaching farmers'),
  ('s3-agritech-feed-value',     '25–40%'),
  ('s3-agritech-feed-sub',       'Post-harvest loss rate'),

  -- Healthtech stats
  ('s3-healthtech-doctors-value','0.05'),
  ('s3-healthtech-doctors-sub',  'Doctors per 1,000 (WHO benchmark: 1.0)'),
  ('s3-healthtech-nhis-value',   '39%'),
  ('s3-healthtech-nhis-sub',     'Out-of-pocket health expenditure'),
  ('s3-healthtech-oop-value',    '7.2%'),
  ('s3-healthtech-oop-sub',      'Public health share of national budget'),
  ('s3-healthtech-cos-value',    '60+'),
  ('s3-healthtech-cos-sub',      'Active healthtech companies in Uganda'),

  -- Section 4 / Funding
  ('s5-title', 'Funding Landscape'),
  ('s5-intro', 'A structured directory of capital allocators active in Uganda — from local ecosystem funds to pan-African DFIs. Each entry includes instrument type, typical ticket size, and a direct link to engage.'),

  -- Section 5 / Directory
  ('s6-title', 'Operational Readiness Toolkit'),
  ('s6-intro', 'A curated reference of the service providers, government institutions, innovation ecosystem actors, and universities you need to engage to execute a successful Uganda market entry.'),
  ('s6-redflag-power',    '<strong>Power infrastructure risk:</strong> Uganda''s national grid covers only 26% of the population; even Kampala experiences periodic load shedding during dry seasons. Any operation with hardware dependencies must have solar-plus-battery or generator backup from Day 1.'),
  ('s6-redflag-fx',       '<strong>FX depreciation compounding:</strong> The Uganda Shilling has depreciated approximately 4–7% annually against the USD over the past decade. Companies with hard-currency cost structures and UGX revenues face compounding margin pressure. Maintain a USD float and model explicit FX stress scenarios.'),
  ('s6-redflag-data',     '<strong>Internet shutdown and OTT tax risk:</strong> Uganda''s 2021 election saw 10 days of social media blocking and 4 days of mobile money suspension. Design all mission-critical workflows to function via SMS or USSD fallback. Maintain 2 weeks of operational cash in bank accounts.'),
  ('s6-redflag-political','<strong>PDPO data protection enforcement:</strong> The Personal Data Protection Office is increasing enforcement under the Data Protection and Privacy Act 2019. Register with PDPO before commercial launch. Penalty: UGX 250M or 2% of annual turnover. Do not defer this registration.'),

  -- Feedback
  ('feedback-title', 'Help improve this pack'),
  ('feedback-intro', 'This pack is only as good as the collective knowledge behind it. Share what you''ve learned on the ground in Uganda, rate service providers, flag regulations that have changed, or request introductions to key ecosystem contacts.')

on conflict (id) do nothing;

-- ═══════════════════════════════════════════════════════════════
-- SUPABASE AUTH + ROLE-BASED ACCESS CONTROL
-- Run this block AFTER the initial schema above has been applied.
-- ═══════════════════════════════════════════════════════════════

create table if not exists public.profiles (
  id         uuid primary key references auth.users(id) on delete cascade,
  email      text not null,
  role       text not null default 'admin' check (role in ('admin', 'super_admin')),
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;

drop policy if exists "Users can read own profile" on public.profiles;
create policy "Users can read own profile"
on public.profiles for select to authenticated using (auth.uid() = id);

create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, email, role)
  values (new.id, new.email, 'admin')
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();

-- Auth-based RPC — validates via JWT session (no password argument needed)

create or replace function public.get_admin_submissions_auth()
returns jsonb language plpgsql security definer set search_path = public as $$
declare is_admin boolean;
begin
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role in ('admin', 'super_admin')
  ) into is_admin;
  if not is_admin then raise exception 'Unauthorized: admin access required.'; end if;
  return jsonb_build_object(
    'market_insights',          coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.market_insights t), '[]'::jsonb),
    'service_provider_ratings', coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.service_provider_ratings t), '[]'::jsonb),
    'intro_requests',           coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.intro_requests t), '[]'::jsonb),
    'pack_ratings',             coalesce((select jsonb_agg(to_jsonb(t) order by t.created_at desc) from public.pack_ratings t), '[]'::jsonb)
  );
end; $$;

revoke execute on function public.get_admin_submissions_auth() from public, anon;
grant  execute on function public.get_admin_submissions_auth() to authenticated;

create or replace function public.update_pack_content_auth(
  content_id  text,
  new_content text
) returns void language plpgsql security definer set search_path = public as $$
declare
  is_admin     boolean;
  editor_email text;
begin
  select exists(
    select 1 from public.profiles
    where id = auth.uid() and role in ('admin', 'super_admin')
  ) into is_admin;
  if not is_admin then raise exception 'Unauthorized: admin access required.'; end if;
  select email from public.profiles where id = auth.uid() into editor_email;
  insert into public.pack_content (id, content, updated_at, updated_by)
  values (content_id, new_content, now(), editor_email)
  on conflict (id) do update
  set content = excluded.content, updated_at = excluded.updated_at, updated_by = excluded.updated_by;
end; $$;

revoke execute on function public.update_pack_content_auth(text, text) from public, anon;
grant  execute on function public.update_pack_content_auth(text, text) to authenticated;

-- ═══════════════════════════════════════════════════════════════
-- SUPABASE STORAGE — Media bucket for image uploads
-- ═══════════════════════════════════════════════════════════════

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values (
  'media', 'media', true, 10485760,
  array['image/jpeg', 'image/png', 'image/gif', 'image/webp', 'image/svg+xml']
) on conflict (id) do nothing;

drop policy if exists "Admin upload to media"  on storage.objects;
create policy "Admin upload to media"
on storage.objects for insert to authenticated with check (bucket_id = 'media');

drop policy if exists "Admin update media"     on storage.objects;
create policy "Admin update media"
on storage.objects for update to authenticated using (bucket_id = 'media');

drop policy if exists "Admin delete media"     on storage.objects;
create policy "Admin delete media"
on storage.objects for delete to authenticated using (bucket_id = 'media');

drop policy if exists "Public read media"      on storage.objects;
create policy "Public read media"
on storage.objects for select to anon using (bucket_id = 'media');
