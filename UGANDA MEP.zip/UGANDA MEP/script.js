/* ═══════════════════════════════════════════════════════════════
   Uganda Market Entry Pack — script.js
   Mirrors Rwanda MEP architecture exactly; Uganda-specific content
   ═══════════════════════════════════════════════════════════════ */

const SUPABASE_URL      = 'YOUR_SUPABASE_URL';
const SUPABASE_ANON_KEY = 'YOUR_SUPABASE_ANON_KEY';

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_SUPABASE_URL') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const db = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

/* ── Dark mode: initialise before paint to avoid FOUC ── */
let darkModeEnabled = localStorage.getItem('mep-darkmode-ug') === '1';
if (darkModeEnabled) document.body.classList.add('dark');

/* ══════════════════════════════════════════════════════════════
   NAVIGATION
   ══════════════════════════════════════════════════════════════ */

const SECTION_ORDER = ['front','s1','s2','s3','s4','s5','feedback','glossary'];

function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx   = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(b => b.classList.remove('active'));

  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');

  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
  window.scrollTo({ top: 0, behavior: 'smooth' });
}

function showSector(id) {
  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.sector-tab').forEach(t => t.classList.remove('active'));
  document.getElementById('sector-' + id)?.classList.add('active');
  document.querySelector(`.sector-tab[data-sector="${id}"]`)?.classList.add('active');
}

/* ══════════════════════════════════════════════════════════════
   DARK MODE  ← Rwanda-pattern implementation
   ══════════════════════════════════════════════════════════════ */

function hydrateDarkMode() {
  darkModeEnabled = localStorage.getItem('mep-darkmode-ug') === '1';
  document.body.classList.toggle('dark', darkModeEnabled);
  updateDarkToggleLabel();
}

function updateDarkToggleLabel() {
  const btn = document.getElementById('darkmode-toggle');
  if (!btn) return;
  btn.textContent = darkModeEnabled ? '☀️' : '🌙';
  btn.title = darkModeEnabled ? 'Switch to light mode' : 'Switch to dark mode';
}

function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode-ug', darkModeEnabled ? '1' : '0');
  updateDarkToggleLabel();
}

/* ══════════════════════════════════════════════════════════════
   PROGRESS BAR & VISITED TRACKING
   ══════════════════════════════════════════════════════════════ */

let visitedSections = new Set();

function persistVisited() {
  localStorage.setItem('mep-visited-ug', JSON.stringify([...visitedSections]));
}

function hydrateVisited() {
  const raw = localStorage.getItem('mep-visited-ug');
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (Array.isArray(list)) { visitedSections = new Set(list); updateVisitedChecks(); }
  } catch { visitedSections = new Set(); }
}

function updateVisitedChecks() {
  visitedSections.forEach(id => {
    const btn = document.querySelector(`.nav-btn[data-panel="${id}"]`);
    if (!btn || btn.querySelector('.nav-check')) return;
    const mark = document.createElement('span');
    mark.className = 'nav-check';
    mark.textContent = '✓';
    btn.appendChild(mark);
  });
}

function markVisited(id) {
  if (visitedSections.has(id)) return;
  visitedSections.add(id);
  persistVisited();
  updateVisitedChecks();
}

function updateProgressBar(index) {
  const fill = document.querySelector('.pack-progress-fill');
  if (fill) fill.style.width = `${Math.round(((index + 1) / SECTION_ORDER.length) * 100)}%`;
}

/* ══════════════════════════════════════════════════════════════
   BOOKMARKS
   ══════════════════════════════════════════════════════════════ */

let bookmarkedSection = null;

function hydrateBookmark() {
  bookmarkedSection = localStorage.getItem('mep-bookmark-ug') || null;
  updateBookmarkIndicators();
}

function setBookmark(panelId) {
  if (panelId === bookmarkedSection) {
    bookmarkedSection = null;
    localStorage.removeItem('mep-bookmark-ug');
  } else {
    bookmarkedSection = panelId;
    localStorage.setItem('mep-bookmark-ug', panelId);
  }
  updateBookmarkIndicators();
}

function updateBookmarkIndicators() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const isBookmarked = btn.dataset.panel === bookmarkedSection;
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (isBookmarked) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.title = 'Bookmarked';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else if (indicator) { indicator.remove(); }
  });
  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.style.opacity = btn.dataset.panel === bookmarkedSection ? '1' : '0.35';
  });
}

/* ══════════════════════════════════════════════════════════════
   SUPABASE HELPERS
   ══════════════════════════════════════════════════════════════ */

async function insertRow(table, payload) {
  if (!db) return { ok: false, message: 'Supabase not configured — add your URL and anon key in script.js.' };
  const { error } = await db.from(table).insert(payload);
  if (error) return { ok: false, message: error.message || 'Submission failed. Please try again.' };
  return { ok: true };
}

/* ══════════════════════════════════════════════════════════════
   CONTENT LOADING FROM SUPABASE
   ══════════════════════════════════════════════════════════════ */

async function loadPackContent() {
  if (!db) return;
  try {
    const { data, error } = await db.from('pack_content').select('id, content');
    if (error || !data || data.length === 0) return;
    for (const row of data) {
      const els = document.querySelectorAll(`[data-content-id="${row.id}"]`);
      if (!els.length) continue;
      const isHtml = /^\s*</.test(row.content);
      for (const el of els) {
        if (isHtml) {
          el.innerHTML = row.content;
          el.querySelectorAll('a').forEach(a => {
            if (!a.getAttribute('target')) a.setAttribute('target', '_blank');
            a.setAttribute('rel', 'noopener noreferrer');
          });
        } else { el.textContent = row.content; }
      }
    }
  } catch { /* fall back to hardcoded HTML */ }
}

/* ══════════════════════════════════════════════════════════════
   PROSE CARD COLLAPSIBLES
   ══════════════════════════════════════════════════════════════ */

function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) { const next = node.nextSibling; body.appendChild(node); node = next; }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
}

/* ══════════════════════════════════════════════════════════════
   SEARCH
   ══════════════════════════════════════════════════════════════ */

function onSearchInput(event) {
  clearSearchHighlights();
  const query = event.target.value.trim();
  if (query) highlightSearch(query);
}

function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;
  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip,.pack-progress-bar,.mep-tooltip,abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);
  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text  = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index, end = start + match[0].length;
      if (start > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
  }
  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) showPanel(panel.id.replace('panel-', ''));
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

/* ══════════════════════════════════════════════════════════════
   ACRONYM TOOLTIPS
   ══════════════════════════════════════════════════════════════ */

const ACRONYMS = {
  UIA:'Uganda Investment Authority', URSB:'Uganda Registration Services Bureau',
  URA:'Uganda Revenue Authority', BoU:'Bank of Uganda', UCC:'Uganda Communications Commission',
  'NITA-U':'National Information Technology Authority — Uganda',
  NSSF:'National Social Security Fund', MAAIF:'Ministry of Agriculture, Animal Industry and Fisheries',
  UCDA:'Uganda Coffee Development Authority', NDA:'National Drug Authority',
  PDPO:'Personal Data Protection Office', EAC:'East African Community',
  AfCFTA:'African Continental Free Trade Area', KCCA:'Kampala Capital City Authority',
  UBOS:'Uganda Bureau of Statistics', DFI:'Development Finance Institution',
  PSP:'Payment Service Provider', PSO:'Payment System Operator',
  SACCO:'Savings and Credit Cooperative Organisation', MDI:'Microfinance Deposit-Taking Institution',
  KYC:'Know Your Customer', AML:'Anti-Money Laundering',
  USSD:'Unstructured Supplementary Service Data', OTT:'Over-The-Top (digital services)',
  EACOP:'East African Crude Oil Pipeline', VHT:'Village Health Team',
  NAADS:'National Agricultural Advisory Services', ACF:'Agriculture Credit Facility',
  ESG:'Environmental, Social, and Governance', FDI:'Foreign Direct Investment',
  VAT:'Value Added Tax', CIT:'Corporate Income Tax', CBR:'Central Bank Rate',
  TIN:'Tax Identification Number', PAYE:'Pay As You Earn',
  EIA:'Environmental Impact Assessment', IMTO:'International Money Transfer Organisation',
  YC:'Y Combinator', EUDR:'EU Deforestation Regulation',
  EUDR:'European Union Deforestation Regulation', UMDPC:'Uganda Medical and Dental Practitioners Council',
  HSDP:'Health Sector Development Plan', MoH:'Ministry of Health',
  ERA:'Electricity Regulatory Authority', UEGCL:'Uganda Electricity Generation Company',
  UNRA:'Uganda National Roads Authority', UFZA:'Uganda Free Zones Authority'
};

let tooltipEl = null;

function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.createElement('div');
  tooltipEl.id = 'mep-tooltip';
  tooltipEl.className = 'mep-tooltip';
  document.body.appendChild(tooltipEl);
  const root = document.querySelector('.pack-root');
  if (!root) return;
  root.addEventListener('pointerover', e => {
    const t = e.target.closest('.mep-abbr');
    if (t) showAcronymTooltip(t);
  });
  root.addEventListener('pointerout', e => {
    if (e.target.closest('.mep-abbr')) hideAcronymTooltip();
  });
}

function showAcronymTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  tooltipEl.style.top  = `${rect.bottom + 10}px`;
  tooltipEl.style.left = `${Math.min(window.innerWidth - 240, Math.max(8, rect.left))}px`;
}

function hideAcronymTooltip() {
  if (tooltipEl) tooltipEl.style.opacity = '0';
}

function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;
  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip,script,.mep-abbr,.search-highlight')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);
  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    acronymRegex.lastIndex = 0;
    if (acronymRegex.test(node.nodeValue)) replacements.push(node);
  }
  replacements.forEach(node => {
    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    acronymRegex.lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index, end = start + match[0].length;
      if (start > lastIndex) fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.title = ACRONYMS[match[0]] || '';
      abbr.tabIndex = 0;
      abbr.textContent = match[0];
      fragment.appendChild(abbr);
      lastIndex = end;
    }
    if (lastIndex < text.length) fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    node.parentNode.replaceChild(fragment, node);
  });
}

/* ══════════════════════════════════════════════════════════════
   HOW-CARDS NAVIGATION
   ══════════════════════════════════════════════════════════════ */

function bindHowCards() {
  document.querySelectorAll('.how-card-link').forEach(card => {
    const handler = () => {
      const panel = card.dataset.navPanel;
      if (!panel) return;
      showPanel(panel);
      const anchor = card.dataset.navAnchor;
      if (anchor) {
        setTimeout(() => {
          document.getElementById(anchor)?.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      }
    };
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); } });
  });
}

/* ══════════════════════════════════════════════════════════════
   PRINT / PDF
   ══════════════════════════════════════════════════════════════ */

function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  window.setTimeout(() => document.body.classList.remove('print-mode'), 100);
}

/* ══════════════════════════════════════════════════════════════
   INTERACTION BINDING
   ══════════════════════════════════════════════════════════════ */

function bindInteractions() {
  /* nav buttons */
  document.querySelectorAll('[data-panel]').forEach(btn => {
    if (btn.classList.contains('bookmark-btn')) return;
    btn.addEventListener('click', () => showPanel(btn.dataset.panel));
  });
  /* bookmarks */
  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.addEventListener('click', () => setBookmark(btn.dataset.panel));
  });
  /* sector tabs */
  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });
  /* dark mode */
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);
  /* search */
  document.getElementById('pack-search')?.addEventListener('input', onSearchInput);
  /* print */
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);

  /* prose card toggles & funding accordions — event delegation */
  document.querySelector('.pack-root')?.addEventListener('click', event => {
    const proseToggle = event.target.closest('.prose-toggle');
    if (proseToggle) {
      event.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;
      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', String(!expanded));
      proseToggle.textContent = expanded ? '▸' : '▾';
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
      return;
    }
    const fundingToggle = event.target.closest('.funding-toggle');
    if (fundingToggle) {
      event.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;
      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', String(!expanded));
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight + 'px'}`;
    }
  });
}

/* ══════════════════════════════════════════════════════════════
   FUNDING ACCORDION — default open
   ══════════════════════════════════════════════════════════════ */

function initFundingAccordions() {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    if (!btn.hasAttribute('aria-expanded')) btn.setAttribute('aria-expanded', 'true');
    body.style.overflow  = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = btn.getAttribute('aria-expanded') === 'true'
      ? `${body.scrollHeight}px`
      : '0';
  });
}

/* ══════════════════════════════════════════════════════════════
   initFeatures — called after content load
   ══════════════════════════════════════════════════════════════ */

function initFeatures() {
  hydrateVisited();
  hydrateBookmark();
  hydrateDarkMode();           /* ← Rwanda pattern: called here, not in DOMContentLoaded */
  initializeProseCards();
  wrapAcronyms();
  createTooltip();
  initFundingAccordions();

  /* Sticky nav shadow */
  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => nav.classList.toggle('scrolled', window.scrollY > 10), { passive: true });
  }

  if (bookmarkedSection) showPanel(bookmarkedSection);
  else showPanel(SECTION_ORDER[0]);
}

/* ══════════════════════════════════════════════════════════════
   DOMContentLoaded bootstrap
   ══════════════════════════════════════════════════════════════ */

document.addEventListener('DOMContentLoaded', () => {
  bindInteractions();
  bindHowCards();
  loadPackContent().finally(initFeatures);
});
