const SUPABASE_URL = 'https://uauzozmlzgpgmurngqxu.supabase.co';
const SUPABASE_ANON_KEY = 'sb_publishable_Octlx2Juh2XMWMVvCUTdJQ_GV9E8U89';

const isSupabaseConfigured =
  SUPABASE_URL.startsWith('https://') &&
  !SUPABASE_URL.includes('YOUR_PROJECT_REF') &&
  SUPABASE_ANON_KEY.length > 40 &&
  !SUPABASE_ANON_KEY.includes('YOUR_SUPABASE_ANON_KEY');

const db = isSupabaseConfigured && window.supabase
  ? window.supabase.createClient(SUPABASE_URL, SUPABASE_ANON_KEY)
  : null;

let currentRating = 0;
let packRating = 0;

function showPanel(id) {
  const panel = document.getElementById('panel-' + id);
  const idx = SECTION_ORDER.indexOf(id);
  if (!panel || idx < 0) return;

  document.querySelectorAll('.panel').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-btn').forEach(b => b.classList.remove('active'));
  document.querySelectorAll('.mobile-nav-item').forEach(item => item.classList.remove('active'));

  panel.classList.add('active');
  document.querySelector(`.nav-btn[data-panel="${id}"]`)?.classList.add('active');
  document.querySelector(`.mobile-nav-item[data-panel="${id}"]`)?.classList.add('active');

  markVisited(id);
  updateProgressBar(idx);
  updateBookmarkIndicators();
}

function showSector(id) {
  const panel = document.getElementById('sector-' + id);
  const order = ['fintech', 'agritech', 'healthtech', 'edtech'];
  const idx = order.indexOf(id);
  const tabs = document.querySelectorAll('.sector-tab');
  if (!panel || idx < 0 || !tabs[idx]) return;

  document.querySelectorAll('.sector-panel').forEach(p => p.classList.remove('active'));
  tabs.forEach(t => t.classList.remove('active'));
  panel.classList.add('active');
  tabs[idx].classList.add('active');
}

function setRating(n) {
  currentRating = n;
  document.querySelectorAll('#stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });
}

async function setPackRating(n) {
  packRating = n;
  document.querySelectorAll('#pack-stars .star').forEach((s, i) => {
    s.classList.toggle('on', i < n);
  });

  const result = await insertRow('pack_ratings', {
    rating: packRating,
    page_url: window.location.href,
    user_agent: navigator.userAgent
  });

  if (result.ok) {
    showThanks('pack-rating-thanks');
  } else {
    showFormMessage('pack-stars', result.message, 'error');
  }
}

function getValue(id) {
  return document.getElementById(id)?.value.trim() || '';
}

function showThanks(id) {
  const el = document.getElementById(id);
  if (el) el.style.display = 'block';
}

function setBusy(button, isBusy) {
  if (!button) return;
  button.disabled = isBusy;
  button.dataset.originalText ||= button.textContent;
  button.textContent = isBusy ? 'Submitting' : button.dataset.originalText;
  button.classList.toggle('btn-loading', isBusy);
  button.setAttribute('aria-label', isBusy ? 'Submitting…' : button.dataset.originalText);
}

function showFormMessage(anchorId, message, type = 'error') {
  const anchor = document.getElementById(anchorId);
  if (!anchor) return;

  const existing = anchor.parentElement.querySelector('.form-message');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = `form-message ${type}`;
  note.textContent = message;
  anchor.insertAdjacentElement('afterend', note);
}

function clearFormMessage(anchorId) {
  const anchor = document.getElementById(anchorId);
  const existing = anchor?.parentElement.querySelector('.form-message');
  if (existing) existing.remove();
}

function showTemporaryFormError(button, message) {
  if (!button?.parentElement) return;

  const existing = button.parentElement.querySelector('.form-error');
  if (existing) existing.remove();

  const note = document.createElement('div');
  note.className = 'form-error';
  note.textContent = message;
  button.insertAdjacentElement('afterend', note);

  window.setTimeout(() => {
    if (note.isConnected) note.remove();
  }, 5000);
}

async function insertRow(table, payload) {
  if (!db) {
    return {
      ok: false,
      message: 'Supabase is not configured yet. Add your project URL and anon key in script.js.'
    };
  }

  const { error } = await db.from(table).insert(payload);
  if (error) {
    const rawMessage = error.message || 'Submission failed. Please try again.';
    if (rawMessage.includes(`Could not find the table 'public.${table}'`)) {
      return {
        ok: false,
        message: 'This form backend is not live yet. The Supabase schema still needs to be run for this project.'
      };
    }

    return { ok: false, message: error.message || 'Submission failed. Please try again.' };
  }

  return { ok: true };
}

async function submitInsight(event) {
  const button = event?.currentTarget;
  const text = getValue('insight-text');
  clearFormMessage('insight-form');

  if (!text) {
    showFormMessage('insight-form', 'Please add your insight before submitting.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('market_insights', {
      sector: getValue('insight-sector') || null,
      insight_text: text,
      contributor_name: getValue('insight-name') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _if = document.getElementById('insight-form'); if (_if) _if.style.display = 'none';
    showThanks('insight-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitRating(event) {
  const button = event?.currentTarget;
  const agencyName = getValue('agency-name');
  clearFormMessage('rating-form');

  if (!agencyName || currentRating === 0) {
    showFormMessage('rating-form', 'Please add a provider name and choose a star rating.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('service_provider_ratings', {
      provider_name: agencyName,
      rating: currentRating,
      comment: getValue('agency-comment') || null,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _rf = document.getElementById('rating-form'); if (_rf) _rf.style.display = 'none';
    showThanks('rating-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

async function submitIntro(event) {
  const button = event?.currentTarget;
  const lookingFor = getValue('intro-looking');
  const context = getValue('intro-context');
  const email = getValue('intro-email');
  clearFormMessage('intro-form');

  if (!lookingFor || !context || !email) {
    showFormMessage('intro-form', 'Please fill out all intro request fields.');
    return;
  }

  setBusy(button, true);
  try {
    const result = await insertRow('intro_requests', {
      looking_for: lookingFor,
      company_context: context,
      email,
      page_url: window.location.href,
      user_agent: navigator.userAgent
    });

    if (!result.ok) {
      showTemporaryFormError(button, 'Submission failed — please try again.');
      return;
    }

    const _intf = document.getElementById('intro-form'); if (_intf) _intf.style.display = 'none';
    showThanks('intro-thanks');
  } catch {
    showTemporaryFormError(button, 'Submission failed — please try again.');
  } finally {
    setBusy(button, false);
  }
}

function bindInteractions() {
  document.querySelectorAll('[data-panel]').forEach(button => {
    if (button.classList.contains('bookmark-btn')) return;
    button.addEventListener('click', () => showPanel(button.dataset.panel));
  });

  document.querySelectorAll('.bookmark-btn').forEach(button => {
    button.addEventListener('click', () => setBookmark(button.dataset.panel));
  });

  document.querySelectorAll('[data-sector]').forEach(tab => {
    tab.addEventListener('click', () => showSector(tab.dataset.sector));
  });

  document.querySelectorAll('[data-rating]').forEach(star => {
    star.addEventListener('click', () => setRating(Number(star.dataset.rating)));
  });

  document.querySelectorAll('[data-pack-rating]').forEach(star => {
    star.addEventListener('click', () => setPackRating(Number(star.dataset.packRating)));
  });

  document.querySelector('[data-action="submit-insight"]')?.addEventListener('click', submitInsight);
  document.querySelector('[data-action="submit-rating"]')?.addEventListener('click', submitRating);
  document.querySelector('[data-action="submit-intro"]')?.addEventListener('click', submitIntro);
}

document.addEventListener('DOMContentLoaded', () => {
  bindInteractions();
  loadPackContent().finally(initFeatures);

  // Sticky nav shadow on scroll
  const nav = document.querySelector('.nav-strip');
  if (nav) {
    window.addEventListener('scroll', () => {
      nav.classList.toggle('scrolled', window.scrollY > 10);
    }, { passive: true });
  }
});

/**
 * Load editable content from the pack_content table (anon SELECT).
 * Falls back to hardcoded HTML if Supabase is not configured or the table is empty.
 */
async function loadPackContent() {
  if (!db) return;

  try {
    const { data, error } = await db.from('pack_content').select('id, content');
    if (error || !data || data.length === 0) return;

    for (const row of data) {
      const els = document.querySelectorAll(`[data-content-id="${row.id}"]`);
      if (!els.length) continue;

      // Auto-detect HTML: if stored content starts with an HTML tag, render
      // as innerHTML (supports rich text written via the Quill editor in admin).
      // All other values are set as textContent for safety.
      const isHtml = /^\s*</.test(row.content);
      for (const el of els) {
        if (isHtml) {
          el.innerHTML = row.content;
          // Ensure all embedded links open in new tab
          el.querySelectorAll('a').forEach(a => {
            if (!a.getAttribute('target')) a.setAttribute('target', '_blank');
            a.setAttribute('rel', 'noopener noreferrer');
          });
        } else {
          el.textContent = row.content;
        }
      }
    }
  } catch {
    // Supabase not available or table doesn't exist — keep hardcoded content
  }
}

// ── FEATURE ADDITIONS ──

const SECTION_ORDER = ['front', 's1', 's2', 's3', 's4', 's5', 'feedback', 'glossary'];
const ACRONYMS = {
  'CBK':    'Central Bank of Kenya — primary financial services regulator; issues fintech licences via FinTech Regulatory Sandbox',
  'CMA':    'Capital Markets Authority — regulates capital markets, digital asset offerings, and investment platforms in Kenya',
  'IRA':    'Insurance Regulatory Authority — licenses insurance and InsurTech companies in Kenya',
  'KRA':    'Kenya Revenue Authority — national tax authority (income tax, VAT, customs, excise)',
  'KEBS':   'Kenya Bureau of Standards — product standards and conformity assessment; required for hardware/agri-input imports',
  'KENIA':  'Kenya Information & Communications Authority — telecoms and digital services regulator',
  'CA':     'Communications Authority of Kenya — regulates telecoms, spectrum, mobile money agent networks',
  'KIRDI':  'Kenya Industrial Research and Development Institute — R&D and manufacturing support',
  'KNBS':   'Kenya National Bureau of Statistics — official data source for macro and sector statistics',
  'PPB':    'Pharmacy and Poisons Board — regulates pharmaceutical products, medical devices, and health commodities in Kenya',
  'MOH':    'Ministry of Health Kenya — health sector policy and implementation',
  'MOICT':  'Ministry of ICT, Innovation and Youth Affairs — digital economy, startup ecosystem, and ICT policy',
  'MAFAP':  'Ministry of Agriculture, Livestock, Fisheries and Cooperatives — agricultural sector policy',
  'NHIF':   'National Hospital Insurance Fund — Kenya\'s public health insurance scheme (under reform → SHIF)',
  'SHIF':   'Social Health Insurance Fund — replacing NHIF from October 2023; mandatory contributions from formal sector',
  'SHA':    'Social Health Authority — administers SHIF from 2024',
  'NEMA':   'National Environment Management Authority — environmental compliance and EIA approvals in Kenya',
  'EPRA':   'Energy and Petroleum Regulatory Authority — regulates energy generation, distribution, petroleum, and EV charging',
  'REREC':  'Rural Electrification and Renewable Energy Corporation — off-grid solar and mini-grid deployment mandate',
  'NTSA':   'National Transport and Safety Authority — vehicle registration and roadworthiness; relevant for EV fleet operators',
  'KSh':    'Kenyan Shilling — official currency; ~KSh 128–135 per USD (mid-2025); relatively stable vs EAC peers',
  'EAC':    'East African Community — regional bloc of 7 member states (~670M people); Kenya is the largest economy',
  'AfCFTA': 'African Continental Free Trade Area — Kenya is a signatory; preferential access architecture across Africa',
  'COMESA': 'Common Market for Eastern and Southern Africa — 21-country bloc; Kenya is a key member',
  'NSP':    'National Startup Policy — Kenya\'s policy framework for the startup ecosystem (2023)',
  'DFI':    'Development Finance Institution — active Kenya DFIs: IFC, BII, Proparco, USAID, OPIC/DFC, AfDB',
  'KIFC':   'Not applicable for Kenya — see KIFC for Rwanda. Kenya equivalent is Nairobi International Financial Centre (NIFC)',
  'NIFC':   'Nairobi International Financial Centre — Kenya\'s financial hub initiative; preferential rates for qualifying financial firms',
  'M-PESA': 'Mobile money platform operated by Safaricom; 30M+ active users in Kenya; ~87% of Kenyan adults use mobile money',
  'GSMA':   'Global System for Mobile Communications Association — industry body; publishes East Africa mobile money data',
  'KCB':    'KCB Group — Kenya\'s largest bank by assets; active SME and agricultural lending',
  'NCBA':   'NCBA Group — major Kenyan bank; co-owns M-Shwari with Safaricom/M-PESA',
  'CIT':    'Corporate Income Tax — Kenya standard rate 30%; SMEs (turnover <KSh 100M): 15% Turnover Tax option; startups: 3-year exemption for qualifying registered tech startups',
  'VAT':    'Value Added Tax — 16% standard rate in Kenya; registration threshold KSh 5M annual turnover',
  'DPIT':   'Digital Service Tax — 1.5% on gross transaction value for digital marketplace operators in Kenya (Finance Act 2021)',
  'RBA':    'Retirement Benefits Authority — regulates pension funds and retirement benefits in Kenya',
  'FKE':    'Federation of Kenya Employers — employer representative body; consult on labour relations',
  'EABL':   'East African Breweries Limited — example of a Kenya-headquartered EAC-scale consumer company',
  'NSSF':   'National Social Security Fund — mandatory employer/employee contributions: KSh 200/month (under reform)',
  'NHIF':   'National Hospital Insurance Fund — being replaced by SHIF/SHA from 2023–2024',
  'GDP':    'Gross Domestic Product — Kenya ~USD 120B nominal (2025); ~8th largest economy in Africa',
  'FDI':    'Foreign Direct Investment — Kenya received ~USD 830M in 2024 (UNCTAD); top EAC destination',
  'PAYD':   'Pay-As-You-Drive — asset financing model; Ampersand uses per-km equivalent for e-motos',
  'BNPL':   'Buy Now Pay Later — embedded credit product; active in Kenya via fintech players',
  'KYC':    'Know Your Customer — mandatory identity verification; Kenya uses Huduma Namba (national ID)',
  'AML':    'Anti-Money Laundering — enforced by Financial Reporting Centre (FRC) in Kenya',
  'FRC':    'Financial Reporting Centre — Kenya\'s anti-money laundering intelligence unit',
  'EHR':    'Electronic Health Record — Kenya executing national digitisation via MOH digital health strategy',
  'CHW':    'Community Health Promoter — Kenya\'s 100,000+ community health workers rebranded CPH under 2023 reforms',
  'COTU':   'Central Organisation of Trade Unions — Kenya\'s primary labour federation',
  'SEZ':    'Special Economic Zone — Naivasha SEZ (flagship), Mombasa, Lamu (LAPSSET corridor)',
  'EPZ':    'Export Processing Zone — zones for export-oriented manufacturing with tax exemptions',
  'PPP':    'Public-Private Partnership — framework for government co-investment in infrastructure and social projects',
  'SLA':    'Service Level Agreement — contractual performance metrics; critical for B2G healthcare/logistics contracts',
  'B2G':    'Business-to-Government — sales model where government is primary customer',
  'B2B':    'Business-to-Business — dominant model for Kenya market entry in tech and agri sectors',
  'SME':    'Small and Medium Enterprise — Kenya has ~7.4M SMEs; contribute ~34% of GDP; underserved by formal finance',
  'MSME':   'Micro, Small and Medium Enterprise — broader classification used in Kenya policy frameworks',
  'VC':     'Venture Capital — Kenya received ~USD 780M in VC funding in 2024; largest VC market in East Africa',
};

let visitedSections = new Set();
let bookmarkedSection = null;
let darkModeEnabled = false;
let tooltipEl = null;

const initialDarkMode = localStorage.getItem('mep-darkmode-ke') === '1';
if (initialDarkMode) {
  document.body.classList.add('dark');
  darkModeEnabled = true;
}

function persistVisited() {
  localStorage.setItem('mep-visited-ke', JSON.stringify([...visitedSections]));
}

function hydrateVisited() {
  const raw = localStorage.getItem('mep-visited-ke');
  if (!raw) return;
  try {
    const list = JSON.parse(raw);
    if (Array.isArray(list)) {
      visitedSections = new Set(list);
      updateVisitedChecks();
    }
  } catch {
    visitedSections = new Set();
  }
}

function updateVisitedChecks() {
  visitedSections.forEach(id => {
    const button = document.querySelector(`.nav-btn[data-panel="${id}"]`);
    if (!button || button.querySelector('.nav-check')) return;
    const mark = document.createElement('span');
    mark.className = 'nav-check';
    mark.textContent = '✓';
    button.appendChild(mark);
  });
}

function markVisited(id) {
  if (visitedSections.has(id)) return;
  visitedSections.add(id);
  persistVisited();
  updateVisitedChecks();
}

function updateProgressBar(index) {
  const fill = document.querySelector('.pack-progress-fill');
  if (!fill) return;
  fill.style.width = `${Math.round(((index + 1) / SECTION_ORDER.length) * 100)}%`;
}

function hydrateBookmark() {
  const raw = localStorage.getItem('mep-bookmark-ke');
  bookmarkedSection = raw || null;
  updateBookmarkIndicators();
}

function updateBookmarkIndicators() {
  document.querySelectorAll('.nav-btn').forEach(btn => {
    const isBookmarked = btn.dataset.panel === bookmarkedSection;
    let indicator = btn.querySelector('.nav-bookmark-indicator');
    if (isBookmarked) {
      if (!indicator) {
        indicator = document.createElement('span');
        indicator.className = 'nav-bookmark-indicator';
        indicator.title = 'Bookmarked';
        indicator.textContent = '🔖';
        btn.appendChild(indicator);
      }
    } else if (indicator) {
      indicator.remove();
    }
  });

  document.querySelectorAll('.bookmark-btn').forEach(btn => {
    btn.style.opacity = btn.dataset.panel === bookmarkedSection ? '1' : '0.35';
  });
}

function setBookmark(panelId) {
  if (panelId === bookmarkedSection) {
    bookmarkedSection = null;
    localStorage.removeItem('mep-bookmark-ke');
  } else {
    bookmarkedSection = panelId;
    localStorage.setItem('mep-bookmark-ke', panelId);
  }
  updateBookmarkIndicators();
}

function initFeatures() {
  hydrateVisited();
  hydrateBookmark();
  hydrateDarkMode();
  initializeProseCards();
  wrapAcronyms();
  createTooltip();
  document.getElementById('pack-search')?.addEventListener('input', onSearchInput);
  document.getElementById('print-btn')?.addEventListener('click', triggerPrint);
  document.getElementById('darkmode-toggle')?.addEventListener('click', toggleDarkMode);

  document.querySelector('.pack-root')?.addEventListener('click', event => {
    const proseToggle = event.target.closest('.prose-toggle');
    if (proseToggle) {
      event.preventDefault();
      const card = proseToggle.closest('.prose-card');
      if (!card) return;
      const body = card.querySelector('.prose-body');
      if (!body) return;

      const expanded = proseToggle.getAttribute('aria-expanded') === 'true';
      proseToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
      return;
    }

    const fundingToggle = event.target.closest('.funding-toggle');
    if (fundingToggle) {
      event.preventDefault();
      const section = fundingToggle.closest('.funding-section');
      if (!section) return;
      const body = section.querySelector('.funding-section-body');
      if (!body) return;

      const expanded = fundingToggle.getAttribute('aria-expanded') === 'true';
      fundingToggle.setAttribute('aria-expanded', expanded ? 'false' : 'true');
      body.style.maxHeight = expanded ? '0' : `${body.scrollHeight}px`;
    }
  });

  if (bookmarkedSection) {
    showPanel(bookmarkedSection);
  } else {
    const current = document.querySelector('.nav-btn.active')?.dataset.panel || SECTION_ORDER[0];
    showPanel(current);
  }
}

function hydrateDarkMode() {
  darkModeEnabled = localStorage.getItem('mep-darkmode-ke') === '1';
  document.body.classList.toggle('dark', darkModeEnabled);
  updateDarkToggleLabel();
}

function updateDarkToggleLabel() {
  const button = document.getElementById('darkmode-toggle');
  if (!button) return;
  button.textContent = darkModeEnabled ? '☀️' : '🌙';
}

function toggleDarkMode() {
  darkModeEnabled = !darkModeEnabled;
  document.body.classList.toggle('dark', darkModeEnabled);
  localStorage.setItem('mep-darkmode-ke', darkModeEnabled ? '1' : '0');
  updateDarkToggleLabel();
}

function triggerPrint() {
  document.body.classList.add('print-mode');
  window.print();
  window.setTimeout(() => {
    document.body.classList.remove('print-mode');
  }, 100);
}

function onSearchInput(event) {
  const query = event.target.value.trim();
  clearSearchHighlights();
  if (!query) return;
  highlightSearch(query);
}

function clearSearchHighlights() {
  document.querySelectorAll('.search-highlight').forEach(mark => {
    const parent = mark.parentNode;
    if (!parent) return;
    parent.replaceChild(document.createTextNode(mark.textContent), mark);
    parent.normalize();
  });
}

function highlightSearch(query) {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const regex = new RegExp(query.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'), 'gi');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, .pack-progress-bar, .mep-tooltip')) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('abbr')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  let firstMatch = null;
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    const matches = [...text.matchAll(regex)];
    if (!matches.length) continue;

    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    for (const match of matches) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const mark = document.createElement('mark');
      mark.className = 'search-highlight';
      mark.textContent = text.slice(start, end);
      fragment.appendChild(mark);
      if (!firstMatch) firstMatch = mark;
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  }

  if (firstMatch) {
    const panel = firstMatch.closest('.panel');
    if (panel) {
      const panelId = panel.id.replace('panel-', '');
      showPanel(panelId);
    }
    firstMatch.scrollIntoView({ behavior: 'smooth', block: 'center' });
  }
}

function initializeProseCards() {
  document.querySelectorAll('.prose-card').forEach(card => {
    if (card.querySelector('.prose-body')) return;
    const heading = card.querySelector('h4');
    if (!heading) return;
    const body = document.createElement('div');
    body.className = 'prose-body';
    let node = heading.nextSibling;
    while (node) {
      const next = node.nextSibling;
      body.appendChild(node);
      node = next;
    }
    card.appendChild(body);
    body.style.overflow = 'hidden';
    body.style.transition = 'max-height 0.3s ease';
    body.style.maxHeight = `${body.scrollHeight}px`;
  });
}

function createTooltip() {
  if (tooltipEl) return;
  tooltipEl = document.createElement('div');
  tooltipEl.id = 'mep-tooltip';
  tooltipEl.className = 'mep-tooltip';
  document.body.appendChild(tooltipEl);
  document.querySelector('.pack-root')?.addEventListener('pointerover', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('pointerout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
  document.querySelector('.pack-root')?.addEventListener('focusin', event => {
    const target = event.target.closest('.mep-abbr');
    if (!target) return;
    showTooltip(target);
  });
  document.querySelector('.pack-root')?.addEventListener('focusout', event => {
    if (event.target.closest('.mep-abbr')) hideTooltip();
  });
}

function showTooltip(target) {
  const key = Object.keys(ACRONYMS).find(k => k.toLowerCase() === target.textContent.toLowerCase());
  const def = ACRONYMS[key] || target.title || '';
  if (!def || !tooltipEl) return;
  tooltipEl.textContent = def;
  tooltipEl.style.opacity = '1';
  const rect = target.getBoundingClientRect();
  const left = Math.min(window.innerWidth - 240, Math.max(8, rect.left));
  const top = rect.bottom + 10;
  tooltipEl.style.top = `${top}px`;
  tooltipEl.style.left = `${left}px`;
}

function wrapAcronyms() {
  const root = document.querySelector('.pack-root');
  if (!root) return;

  const acronymRegex = new RegExp(`\\b(${Object.keys(ACRONYMS).join('|')})\\b`, 'g');
  const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
    acceptNode(node) {
      if (!node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
      if (node.parentElement.closest('.nav-strip, script, .mep-abbr, .search-highlight')) return NodeFilter.FILTER_REJECT;
      return NodeFilter.FILTER_ACCEPT;
    }
  }, false);

  const replacements = [];
  while (walker.nextNode()) {
    const node = walker.currentNode;
    const text = node.nodeValue;
    if (!acronymRegex.test(text)) continue;
    replacements.push(node);
  }

  replacements.forEach(node => {
    const text = node.nodeValue;
    const fragment = document.createDocumentFragment();
    let lastIndex = 0;
    acronymRegex.lastIndex = 0;
    let match;
    while ((match = acronymRegex.exec(text)) !== null) {
      const start = match.index;
      const end = start + match[0].length;
      if (start > lastIndex) {
        fragment.appendChild(document.createTextNode(text.slice(lastIndex, start)));
      }
      const abbr = document.createElement('abbr');
      abbr.className = 'mep-abbr';
      abbr.title = ACRONYMS[match[0]] || '';
      abbr.tabIndex = 0;
      abbr.textContent = match[0];
      fragment.appendChild(abbr);
      lastIndex = end;
    }
    if (lastIndex < text.length) {
      fragment.appendChild(document.createTextNode(text.slice(lastIndex)));
    }
    node.parentNode.replaceChild(fragment, node);
  });
}

function hideTooltip() {
  if (!tooltipEl) return;
  tooltipEl.style.opacity = '0';
}

/* ═══════════════════════════════════════════════════════════════
   TASK 2 — HOW-CARD NAVIGATION
   ═══════════════════════════════════════════════════════════════ */
function bindHowCards() {
  document.querySelectorAll('.how-card-link').forEach(card => {
    const handler = () => {
      const panel = card.dataset.navPanel;
      if (!panel) return;
      showPanel(panel);
      // Scroll to anchor if specified
      const anchor = card.dataset.navAnchor;
      if (anchor) {
        setTimeout(() => {
          const el = document.getElementById(anchor);
          if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
        }, 120);
      } else {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      }
    };
    card.addEventListener('click', handler);
    card.addEventListener('keydown', e => {
      if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); handler(); }
    });
  });
}

/* ═══════════════════════════════════════════════════════════════
   TASK 7 — INTERACTIVE SCORECARD (Kenya Entry Readiness)
   Slider mechanic matching Rwanda MEP. Kenya-specific dimensions.
   Lives in Section 5: Directory — not in Feedback.
   ═══════════════════════════════════════════════════════════════ */

const SCORECARD_DIMENSIONS = [
  {
    id: 'political',
    name: 'Political &amp; Macroeconomic Stability',
    section: 'Market Conditions',
    baseContext: 'Kenya has maintained democratic governance with periodic election-cycle volatility. GDP growth at 5–5.5% (2024), though weaker than recent highs due to fiscal tightening. IMF programme under Article IV with debt-to-GDP at ~70%. Finance Bill 2024 withdrawal following protests signals political risk to tax policy. One of Africa\'s most open but also most contested operating environments.',
    contextFn: null
  },
  {
    id: 'regulatory',
    name: 'Regulatory Ease',
    section: 'Market Conditions',
    baseContext: 'BRS company registration: 1–3 business days via eCitizen. KRA PIN same-day online. Kenya ranked consistently in top 3 African markets for ease of doing business. Rule of law is functional but enforcement is variable. Finance Acts have reversed multiple taxes — build regulatory monitoring into your compliance budget.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: CBK Regulatory Sandbox provides 3–4 month pathway for novel models. Payment Service Provider and EMI licences take 6–12 months outside sandbox. FRC AML registration required before launch. Daraja API integration is technically straightforward — regulatory burden is the bottleneck, not infrastructure.',
        agritech: 'Agritech: MAFAP/Agriculture Ministry engagement required for ASTGS alignment and subsidy access. County-level permits required for field operations. KEBS standards apply to agri-inputs and processed goods. Generally light regulatory burden for pure B2B digital agritech models.',
        healthtech: 'Healthtech: PPB registration for medical devices/pharma (6–12 months). ODPC registration mandatory for health data. SHA is actively seeking digital partners — B2G engagement is faster than in most African markets. IRA licence required for any insurance product component.',
        climate: 'Climate: EPRA issues EV charging and generation licences. NTSA type approval required for EV deployment (3–6 months under 2023 E-Mobility Policy, improved from 12+ months). Import duty relief for qualifying EV components. Regulatory environment is enabling but NTSA timelines remain a bottleneck.',
        saas: 'B2B SaaS: Lightest regulatory burden. ODPC registration required for any personal data processing. DST (1.5%) applicability must be confirmed with Kenya tax counsel — scope has been contested. No sector licence required for pure software. CMA sandbox available for capital markets-adjacent models.',
        other: 'Cross-sector: eCitizen handles company registration; KRA PIN same-day. Sector-specific licences vary widely — identify your primary regulator (CBK, IRA, PPB, EPRA, CMA) early and build 6–12 months into your compliance timeline.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'market_size',
    name: 'Market Size &amp; Growth Trajectory',
    section: 'Market Conditions',
    baseContext: 'Population: 56M. GDP ~USD 115B (2024). East Africa\'s largest economy — ~40% of EAC bloc GDP. Nairobi is the uncontested tech and financial hub for East and Central Africa. Urban middle class of 5–8M is the core addressable market for most tech products. Rural 56% of population is accessible via M-PESA and agent networks.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech: 30M+ M-PESA active users; ~87% mobile money penetration. USD 314B+ annual M-PESA transaction volume. NIFC is maturing — fund domiciliation and passporting in development. Largest fintech market in East Africa by volume and infrastructure depth.',
        agritech: 'Agritech: 70%+ of population has agricultural livelihood exposure. 5.5M smallholder farming households. Fresh produce market: USD 3B+ annually. Twiga Foods\' 50,000+ mama mboga customers are the B2B demand side — this market is proven, not experimental.',
        healthtech: 'Healthtech: 56M population, 25M+ SHIF-enrolled. SHA digitisation agenda creates largest B2G healthtech opportunity in East Africa. Private health insurance market underpenetrated — Turaco\'s embedded micro-insurance model targets the 40M+ with active M-PESA but no formal insurance.',
        climate: 'Climate: 800,000+ commercial boda boda riders = KSh 70B/yr fuel market for EV transition. 25% of Kenya without grid electricity = off-grid solar addressable market. REREC off-grid programme creates B2G procurement opportunities. E-mobility transition is at commercial inflection — Ampersand is the proof case.',
        saas: 'B2B SaaS: Nairobi hosts the largest concentration of enterprise software buyers in East Africa — multinationals, DFIs, NGOs, and Kenyan corporates. Government ICT procurement is significant. iHub and Nairobi Garage communities provide enterprise client pipeline.',
        other: 'General: Kenya\'s 56M population and USD 115B GDP make it East Africa\'s largest standalone market. The EAC launchpad positioning is equally compelling — a Kenya proof-of-concept validates the model for Uganda, Tanzania, Rwanda, and beyond.'
      };
      return map[sector] || null;
    }
  },
  {
    id: 'mpesa_infra',
    name: 'M-PESA &amp; Digital Infrastructure',
    section: 'Operational Readiness',
    baseContext: '4G coverage: 96%+ populated areas. M-PESA Daraja API: 200,000+ registered developers. STK Push achieves >90% payment completion rates. National broadband penetration at 48%+. Nairobi\'s fibre infrastructure is among Africa\'s best. The Daraja API is Kenya\'s most important business infrastructure asset — not just a payment rail.',
    contextFn: null
  },
  {
    id: 'talent',
    name: 'Talent Availability',
    section: 'Operational Readiness',
    baseContext: 'Nairobi has East Africa\'s deepest talent pool. University of Nairobi, Strathmore, USIU, and KCA University produce strong tech and business graduates. iHub alumni network includes M-KOPA, Ushahidi, Sanergy. Kenya is more expensive than Rwanda but offers 3–5x the talent depth. Boda boda rider base of 800,000+ provides instant field workforce for logistics models.',
    contextFn: (sector, talent) => {
      const map = {
        tech: 'Tech/Engineering: Nairobi has the deepest software engineering pool in East Africa — 50,000+ registered developers. iHub, Nairobi Garage, and Andela alumni are prime recruitment pipelines. Senior ML/AI talent is scarce and expensive; mid-level full-stack engineers are plentiful at competitive rates.',
        commercial: 'Commercial/Sales: Kenya has sophisticated B2B sales culture — especially in financial services and enterprise software. M-KOPA, Safaricom, and equity bank alumni are top commercial talent. Government relationship management is a distinct, hireable skill in Nairobi.',
        finance: 'Finance/Legal: Big 4 all present (PwC, KPMG, EY, Deloitte). Strong pool of CFA-qualified and ICPA-K-qualified finance professionals. Kenya-qualified lawyers available via LSK. Deep DFI transaction experience in Nairobi.',
        agri: 'Agricultural/Field: Strong field extension worker base via MAFAP, county governments, and cooperative networks. Swahili-speaking field staff available nationally. SACCO and cooperative network relationships are essential for smallholder access — hire staff with existing cooperative relationships.',
        health: 'Healthcare/Clinical: Better doctor-to-population ratio than Rwanda (0.2 per 1,000). Clinical officer cadre is Kenya\'s real healthcare workforce infrastructure. SHA and county health departments are primary B2G engagement channels. CHW networks provide last-mile health access.'
      };
      return map[talent] || null;
    }
  },
  {
    id: 'capital',
    name: 'Capital Access',
    section: 'Funding &amp; Growth',
    baseContext: 'DFI ecosystem: IFC Nairobi Office, BII, Proparco, AfDB, USAID Kenya, KfW. VC: Partech Africa, Norrsken22, Founders Factory Africa, Antler East Africa, 4DX Ventures active in Nairobi. Non-dilutive: Google for Startups (USD 200K equity-free), USAID Kenya grants, UNDP Kenya.',
    contextFn: (sector, talent, stage) => {
      const map = {
        explore: 'Exploring: Google for Startups Accelerator Africa (USD 200K equity-free credits) and USAID Kenya programme grants are the most accessible non-dilutive pathways. iHub and Nairobi Garage demo days are the top deal-flow channels for angel funding. Plan 6–12 months before first equity raise.',
        pilot: 'Piloting: Partech Africa, 4DX Ventures, and Founders Factory Africa are the primary Nairobi-present equity targets at seed/pre-Series A. Antler East Africa runs Kenya cohorts. Warm intros through iHub and Nairobi Garage community are the most reliable deal-flow pathway.',
        scale: 'Scaling: IFC Nairobi Office, BII, and Proparco are the primary DFI channels. NIFC structure improves fundability for financial services companies. DEG and FMO are active on climate and agritech debt facilities. Gender lens and climate alignment are significant unlock factors for concessional debt terms.'
      };
      return map[stage] || null;
    }
  },
  {
    id: 'eac_position',
    name: 'EAC Gateway &amp; Regional Positioning',
    section: 'Strategic Upside',
    baseContext: 'Kenya is the EAC\'s largest economy (~40% of bloc GDP) and the dominant regional HQ destination for multinationals and DFIs operating across East Africa. Nairobi hosts the UN Environment Programme, UN-Habitat, and 120+ multinational HQs. EAC Common Market Protocol enables free movement of capital and qualified professionals across member states.',
    contextFn: null
  },
  {
    id: 'execution_risk',
    name: 'Execution Risk (lower = better score)',
    section: 'Risk Assessment',
    baseContext: 'Key risks: Finance Act volatility (tax policy changes annually), KSh depreciation risk (historically 3–8%/yr vs USD), competitive market density (more incumbents than Rwanda), regulatory timeline variance (CBK 6–12 months), and election-cycle disruption (2027). Kenya requires more capital and patience than Rwanda but offers 3–4x the market size.',
    contextFn: (sector) => {
      const map = {
        fintech: 'Fintech execution risk: MEDIUM-HIGH. CBK licence processing takes 6–12 months outside sandbox. FRC AML non-compliance has resulted in enforcement penalties for fintechs. Competitive intensity is high — M-KOPA, Safaricom (M-PESA), Equity (Finserve), and KCB (KCB M-PESA) are incumbents with distribution advantages.',
        agritech: 'Agritech execution risk: HIGH. Smallholder adoption is slow; SACCO gatekeeping is real; logistics last-mile in upcountry Kenya is operationally hard. Twiga Foods has demonstrated the model but also the capital intensity. Working capital requirements are high for agri-distribution models.',
        healthtech: 'Healthtech execution risk: MEDIUM. SHA B2G procurement cycle is 12–24 months. PPB registration adds 6–12 months before commercial launch. NHIF-to-SHIF transition has created uncertainty in the public health funding stack. However, SHA\'s digital agenda creates genuine partnership opportunity for well-positioned companies.',
        climate: 'Climate execution risk: MEDIUM. NTSA type approval has improved (3–6 months vs 12+ previously) but remains a bottleneck. Import duty relief is policy-dependent. E-motorcycle market is more competitive than Rwanda (multiple players including Ampersand, Roam, Zembo). Hardware logistics and maintenance at scale are capital-intensive.',
        saas: 'B2B SaaS execution risk: LOW-MEDIUM. Lightest regulatory burden. Key risks are DST scope uncertainty, enterprise sales cycles (6–18 months for large organisations), and competition from global SaaS incumbents with Kenya presence. Government procurement has improved but still requires 12–24 month relationship investment.',
        other: 'General execution risk: MEDIUM. Finance Act annual changes require ongoing tax counsel engagement. KSh FX exposure requires active management for USD-cost companies. Political risk around elections (2027) creates 6-month planning windows to avoid. Competition is higher than most African markets — budget for longer customer acquisition timelines.'
      };
      return map[sector] || null;
    }
  }
];

const scorecardState = {};

function getScorecardContextText(dim, sector, talent, stage) {
  if (dim.contextFn) {
    const ctx = dim.contextFn(sector, talent, stage);
    if (ctx) return ctx;
  }
  return dim.baseContext;
}

function getScoreClass(score) {
  if (score === 0) return '';
  if (score >= 7) return 'score-high';
  if (score >= 5) return 'score-mid';
  return 'score-low';
}

function calcTotal() {
  const ids = SCORECARD_DIMENSIONS.map(d => d.id);
  const scored = ids.filter(id => scorecardState[id] != null);
  if (scored.length === 0) return null;
  const sum = scored.reduce((acc, id) => acc + scorecardState[id], 0);
  return (sum / scored.length).toFixed(1);
}

function updateScorecardResult() {
  const total = calcTotal();
  const scoreEl = document.getElementById('sc-total-score');
  const labelEl = document.getElementById('sc-result-label');
  const signalEl = document.getElementById('sc-result-signal');
  if (!scoreEl || !labelEl || !signalEl) return;

  if (total === null) {
    scoreEl.textContent = '—';
    labelEl.textContent = 'Rate each dimension to generate your entry signal.';
    signalEl.textContent = '';
    signalEl.className = 'scorecard-result-signal';
    return;
  }

  const t = parseFloat(total);
  scoreEl.textContent = `${total}/10`;

  if (t >= 7) {
    labelEl.textContent = 'Strong entry window for your profile. Kenya\'s market depth, M-PESA infrastructure, and EAC hub positioning make this a compelling commitment for well-capitalised, regulatory-ready operators.';
    signalEl.textContent = 'Strong Entry Window';
    signalEl.className = 'scorecard-result-signal signal-strong';
  } else if (t >= 5) {
    labelEl.textContent = 'Promising but context-dependent. Address your red-flag dimensions — particularly regulatory timelines and execution capital requirements — before committing. M-PESA integration strategy is non-negotiable.';
    signalEl.textContent = 'Promising — Address Red Flags';
    signalEl.className = 'scorecard-result-signal signal-promising';
  } else {
    labelEl.textContent = 'Significant barriers identified. Consider Rwanda as a lower-competition proof-of-concept market first, or address the lowest-scoring dimensions before committing Kenya entry capital. Regulatory and execution timelines require patient capital.';
    signalEl.textContent = 'Caution — Revisit Strategy';
    signalEl.className = 'scorecard-result-signal signal-caution';
  }
}

function renderScorecardRows() {
  const container = document.getElementById('scorecard-rows');
  if (!container) return;
  const sector = document.getElementById('sc-sector')?.value || 'other';
  const talent = document.getElementById('sc-talent')?.value || 'tech';
  const stage  = document.getElementById('sc-stage')?.value  || 'explore';

  let html = '';
  let lastSection = '';

  for (const dim of SCORECARD_DIMENSIONS) {
    if (dim.section !== lastSection) {
      html += `<div class="scorecard-section-heading">${dim.section}</div>`;
      lastSection = dim.section;
    }
    const score = scorecardState[dim.id] || 0;
    const scoreClass = getScoreClass(score);
    const ctx = getScorecardContextText(dim, sector, talent, stage);
    const valDisplay = score === 0 ? '—' : `${score}/10`;

    html += `
      <div class="scorecard-dim" id="sc-dim-${dim.id}">
        <div class="scorecard-dim-header">
          <div class="scorecard-dim-name">${dim.name}</div>
          <div class="scorecard-dim-val ${scoreClass} ${score > 0 ? 'scored' : ''}" id="sc-val-${dim.id}">${valDisplay}</div>
        </div>
        <div class="scorecard-dim-context">${ctx}</div>
        <div class="scorecard-slider-wrap">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">0</span>
          <input type="range" class="scorecard-slider" id="sc-slider-${dim.id}"
            min="0" max="10" step="0.5" value="${score}"
            data-dim-id="${dim.id}" aria-label="${dim.name} score">
          <span style="font-size:10px;color:var(--color-text-tertiary);min-width:16px">10</span>
        </div>
      </div>`;
  }

  container.innerHTML = html;

  container.querySelectorAll('.scorecard-slider').forEach(slider => {
    slider.addEventListener('input', () => {
      const id = slider.dataset.dimId;
      const val = parseFloat(slider.value);
      scorecardState[id] = val;
      const valEl = document.getElementById(`sc-val-${id}`);
      if (valEl) {
        valEl.textContent = val === 0 ? '—' : `${val}/10`;
        valEl.className = `scorecard-dim-val ${val > 0 ? 'scored' : ''} ${getScoreClass(val)}`;
      }
      updateScorecardResult();
    });
  });
}

function initInteractiveScorecard() {
  const container = document.getElementById('interactive-scorecard');
  if (!container) return;

  renderScorecardRows();
  updateScorecardResult();

  ['sc-sector', 'sc-talent', 'sc-stage'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', () => {
      renderScorecardRows();
    });
  });

  document.getElementById('sc-reset-btn')?.addEventListener('click', () => {
    SCORECARD_DIMENSIONS.forEach(d => { scorecardState[d.id] = 0; });
    renderScorecardRows();
    updateScorecardResult();
  });
}

// Patch initFeatures to include how-card binding + scorecard init
const _origInitFeatures = initFeatures;
document.addEventListener('DOMContentLoaded', () => {
  bindHowCards();
  setTimeout(initInteractiveScorecard, 300);
});

/* ═══════════════════════════════════════════════════════════════
   MONOCLE 2026 — FEATURE ADDITIONS
   Appended below original handlers — nothing above is modified.
   ═══════════════════════════════════════════════════════════════ */

// ── 1. STICKY NAV SCROLL STATE ──
// (already handled in original DOMContentLoaded block above)

// ── 2. DARK MODE ──
// Wired in initFeatures() above via document.getElementById('darkmode-toggle').addEventListener('click', toggleDarkMode)
// No duplicate listener here — double-wiring caused each click to toggle twice (on then immediately off).

// ── 3. READING PROGRESS BAR ──
// Already wired through updateProgressBar called inside showPanel.

// ── 4. PRINT TRIGGER ──
// Already implemented above as triggerPrint.

// ── 5. VISITED / BOOKMARK STATE ──
// Already implemented above.

// ── 6. SEARCH ──
// Already implemented above (onSearchInput / highlightSearch).

// ── 7. ACRONYM TOOLTIPS ──
// Already implemented above (wrapAcronyms / createTooltip).

// ── 8. PROSE + FUNDING ACCORDIONS ──
// Already implemented above (initializeProseCards + delegated click).

// ── 9. SMOOTH SCROLL TO TOP ON PANEL CHANGE ──
// Patch showPanel to also smooth-scroll to top of content.
(function patchShowPanelScroll() {
  const _orig = window.showPanel;
  if (!_orig) return;
  window.showPanel = function(id) {
    _orig(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };
})();

// ── 10. STAGGERED CARD ENTRANCE ANIMATION TRIGGER ──
// Ensures CSS animation re-triggers on panel switch by
// force-reflowing newly active panels.
(function patchShowPanelReflow() {
  const _prev = window.showPanel;
  if (!_prev) return;
  window.showPanel = function(id) {
    _prev(id);
    const panel = document.getElementById('panel-' + id);
    if (panel) {
      // Force reflow so CSS animations replay
      panel.querySelectorAll('.stat-card, .how-card, .how-card-link').forEach(el => {
        el.style.animation = 'none';
        void el.offsetHeight; // trigger reflow
        el.style.animation = '';
      });
    }
  };
})();

// ── 11. DYNAMIC DARKMODE TOGGLE LABEL ON LOAD ──
(function initDarkLabelOnLoad() {
  const apply = () => {
    const btn = document.getElementById('darkmode-toggle');
    if (!btn) return;
    const isDark = document.body.classList.contains('dark');
    btn.textContent = isDark ? '☀️' : '🌙';
    btn.title = isDark ? 'Switch to light mode' : 'Switch to dark mode';
  };
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', apply);
  } else {
    apply();
  }
})();

// ── 12. FUNDING SECTION ACCORDION — ensure default open ──
document.addEventListener('DOMContentLoaded', () => {
  document.querySelectorAll('.funding-toggle').forEach(btn => {
    const section = btn.closest('.funding-section');
    if (!section) return;
    const body = section.querySelector('.funding-section-body');
    if (!body) return;
    // Default: expanded
    if (!btn.hasAttribute('aria-expanded')) {
      btn.setAttribute('aria-expanded', 'true');
    }
    if (btn.getAttribute('aria-expanded') === 'true') {
      body.style.maxHeight = body.scrollHeight + 'px';
    } else {
      body.style.maxHeight = '0';
    }
  });
});
