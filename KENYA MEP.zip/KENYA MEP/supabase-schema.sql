-- ============================================================
-- Kenya Market Entry Pack 2026 — Supabase Schema
-- Compatible with Ghana MEP and Rwanda MEP schemas
-- Pack identifier: 'kenya-2026'
-- Run this in your Supabase SQL Editor
-- ============================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- ── 1. PACK RATINGS ──────────────────────────────────────────
CREATE TABLE IF NOT EXISTS pack_ratings (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  pack        TEXT NOT NULL DEFAULT 'kenya-2026',
  rating      INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment     TEXT,
  user_agent  TEXT
);

-- ── 2. MARKET INSIGHTS ───────────────────────────────────────
CREATE TABLE IF NOT EXISTS market_insights (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  pack        TEXT NOT NULL DEFAULT 'kenya-2026',
  name        TEXT,
  org         TEXT,
  section     TEXT,
  insight     TEXT NOT NULL,
  status      TEXT DEFAULT 'pending' CHECK (status IN ('pending','reviewed','incorporated','rejected')),
  admin_notes TEXT
);

-- ── 3. INTRO REQUESTS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS intro_requests (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at  TIMESTAMPTZ DEFAULT NOW(),
  pack        TEXT NOT NULL DEFAULT 'kenya-2026',
  name        TEXT NOT NULL,
  email       TEXT NOT NULL,
  org         TEXT,
  target      TEXT NOT NULL,
  intro_type  TEXT,
  context     TEXT,
  status      TEXT DEFAULT 'pending' CHECK (status IN ('pending','in_progress','completed','declined')),
  admin_notes TEXT
);

-- ── 4. SERVICE PROVIDER RATINGS ──────────────────────────────
CREATE TABLE IF NOT EXISTS service_provider_ratings (
  id             UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at     TIMESTAMPTZ DEFAULT NOW(),
  pack           TEXT NOT NULL DEFAULT 'kenya-2026',
  provider_name  TEXT NOT NULL,
  provider_type  TEXT,
  rating         INTEGER CHECK (rating BETWEEN 1 AND 5),
  review         TEXT,
  verified       BOOLEAN DEFAULT FALSE
);

-- ── 5. PACK CONTENT (admin-editable sections) ────────────────
CREATE TABLE IF NOT EXISTS pack_content (
  id           UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  updated_at   TIMESTAMPTZ DEFAULT NOW(),
  pack         TEXT NOT NULL DEFAULT 'kenya-2026',
  content_id   TEXT NOT NULL UNIQUE,
  content_html TEXT NOT NULL,
  updated_by   TEXT DEFAULT 'admin'
);

-- ── 6. ADMIN SETTINGS ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admin_settings (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  key         TEXT NOT NULL UNIQUE,
  value       TEXT NOT NULL,
  description TEXT
);

INSERT INTO admin_settings (key, value, description)
VALUES (
  'admin_password_hash',
  '$2b$10$placeholder_replace_before_production_KenyaMEP2026',
  'Bcrypt hash of admin dashboard password. Replace before production.'
) ON CONFLICT (key) DO NOTHING;

-- ── 7. ROW LEVEL SECURITY ────────────────────────────────────
ALTER TABLE pack_ratings             ENABLE ROW LEVEL SECURITY;
ALTER TABLE market_insights          ENABLE ROW LEVEL SECURITY;
ALTER TABLE intro_requests           ENABLE ROW LEVEL SECURITY;
ALTER TABLE service_provider_ratings ENABLE ROW LEVEL SECURITY;
ALTER TABLE pack_content             ENABLE ROW LEVEL SECURITY;
ALTER TABLE admin_settings           ENABLE ROW LEVEL SECURITY;

CREATE POLICY "public_insert_ratings"
  ON pack_ratings FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_insights"
  ON market_insights FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_intros"
  ON intro_requests FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_insert_provider_ratings"
  ON service_provider_ratings FOR INSERT TO anon WITH CHECK (true);
CREATE POLICY "public_select_content"
  ON pack_content FOR SELECT TO anon USING (true);

-- ── 8. ADMIN RPC FUNCTION ────────────────────────────────────
CREATE OR REPLACE FUNCTION get_admin_submissions(p_password TEXT)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
DECLARE result JSON;
BEGIN
  IF p_password != 'KenyaMEP2026' THEN
    RETURN json_build_object('error', 'Invalid password');
  END IF;
  SELECT json_build_object(
    'ratings',          (SELECT json_agg(r ORDER BY r.created_at DESC) FROM pack_ratings r WHERE r.pack = 'kenya-2026'),
    'insights',         (SELECT json_agg(i ORDER BY i.created_at DESC) FROM market_insights i WHERE i.pack = 'kenya-2026'),
    'intro_requests',   (SELECT json_agg(ir ORDER BY ir.created_at DESC) FROM intro_requests ir WHERE ir.pack = 'kenya-2026'),
    'provider_ratings', (SELECT json_agg(pr ORDER BY pr.created_at DESC) FROM service_provider_ratings pr WHERE pr.pack = 'kenya-2026')
  ) INTO result;
  RETURN result;
END; $$;

-- ── 9. CONTENT UPDATE RPC ────────────────────────────────────
CREATE OR REPLACE FUNCTION update_pack_content(
  p_password TEXT, p_content_id TEXT, p_html TEXT)
RETURNS JSON LANGUAGE plpgsql SECURITY DEFINER AS $$
BEGIN
  IF p_password != 'KenyaMEP2026' THEN
    RETURN json_build_object('error', 'Invalid password');
  END IF;
  INSERT INTO pack_content (pack, content_id, content_html, updated_at)
  VALUES ('kenya-2026', p_content_id, p_html, NOW())
  ON CONFLICT (content_id)
  DO UPDATE SET content_html = EXCLUDED.content_html, updated_at = NOW();
  RETURN json_build_object('success', true, 'content_id', p_content_id);
END; $$;

-- ── 10. INDEXES ──────────────────────────────────────────────
CREATE INDEX IF NOT EXISTS idx_ke_ratings_pack       ON pack_ratings (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ke_insights_pack      ON market_insights (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ke_intros_pack        ON intro_requests (pack, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_ke_content_content_id ON pack_content (content_id);

-- ── DONE ─────────────────────────────────────────────────────
-- Next steps:
-- 1. Replace admin_password_hash value with real bcrypt hash
-- 2. Add your Supabase URL + anon key to the top of script.js
-- 3. Test insert operations via the Feedback & Intros panel
-- ─────────────────────────────────────────────────────────────
